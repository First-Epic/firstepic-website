import numpy as np
from scipy.spatial.transform import Rotation

from transform import (
    AXIS_SWAP,
    PoseTransformer,
    transform_position_no_origin,
    inverse_transform_position_no_origin,
    transform_quaternion_wxyz_to_target,
    inverse_transform_quaternion_target_to_wxyz,
    transform_rotation_matrix,
)

RNG = np.random.default_rng(0)
N_TRIALS = 2000
TOL = 1e-9


def test_permutation_properties():
    assert np.isclose(np.linalg.det(AXIS_SWAP), -1.0)
    assert np.allclose(AXIS_SWAP, AXIS_SWAP.T)
    assert np.allclose(AXIS_SWAP @ AXIS_SWAP, np.eye(3))


def test_rotation_matrices_stay_orthonormal_det_plus1():
    for _ in range(N_TRIALS):
        r_s = Rotation.random(random_state=RNG).as_matrix()
        r_t = transform_rotation_matrix(r_s)
        assert np.allclose(r_t @ r_t.T, np.eye(3), atol=TOL)
        assert abs(np.linalg.det(r_t) - 1.0) < TOL


def test_quaternion_matches_matrix_conjugation():
    """Closed-form quaternion path must agree with direct matrix conjugation
    to within 1e-9, per the Phase 1 review requirement."""
    for _ in range(N_TRIALS):
        r_s = Rotation.random(random_state=RNG)
        q_wxyz = r_s.as_quat()[[3, 0, 1, 2]]

        r_t_matrix = transform_rotation_matrix(r_s.as_matrix())
        q_t = transform_quaternion_wxyz_to_target(q_wxyz)
        r_t_from_quat = Rotation.from_quat(q_t).as_matrix()

        assert np.max(np.abs(r_t_from_quat - r_t_matrix)) < TOL


def test_position_roundtrip_no_origin():
    for _ in range(N_TRIALS):
        pos_m = RNG.uniform(-100, 100, size=3)
        pos_cm = transform_position_no_origin(pos_m)
        pos_m_back = inverse_transform_position_no_origin(pos_cm)
        assert np.allclose(pos_m, pos_m_back, atol=TOL)


def test_quaternion_roundtrip():
    for _ in range(N_TRIALS):
        q_wxyz = Rotation.random(random_state=RNG).as_quat()[[3, 0, 1, 2]]
        q_t = transform_quaternion_wxyz_to_target(q_wxyz)
        q_back = inverse_transform_quaternion_target_to_wxyz(q_t)
        # quaternions double-cover SO(3): q and -q are the same rotation
        assert np.allclose(q_wxyz, q_back, atol=TOL) or np.allclose(q_wxyz, -q_back, atol=TOL)


def test_posetransformer_roundtrip_with_origin():
    origin_m = np.array([12.3, -4.5, 1.6])
    xf = PoseTransformer(origin_m)
    for _ in range(N_TRIALS):
        pos_m = RNG.uniform(-50, 50, size=3)
        pos_cm = xf.transform_position(pos_m)
        pos_m_back = xf.inverse_transform_position(pos_cm)
        assert np.allclose(pos_m, pos_m_back, atol=TOL)


def test_posetransformer_origin_is_zero_at_t0():
    origin_m = np.array([5.0, -2.0, 3.0])
    xf = PoseTransformer(origin_m)
    pos_cm = xf.transform_position(origin_m)
    assert np.allclose(pos_cm, np.zeros(3), atol=TOL)


def test_known_axis_mapping():
    # East stays East, scaled m->cm
    assert np.allclose(transform_position_no_origin([1, 0, 0]), [100, 0, 0], atol=TOL)
    # source North (Y) -> target Z
    assert np.allclose(transform_position_no_origin([0, 1, 0]), [0, 0, 100], atol=TOL)
    # source Up (Z) -> target Y
    assert np.allclose(transform_position_no_origin([0, 0, 1]), [0, 100, 0], atol=TOL)


def test_identity_rotation_maps_to_identity():
    q_wxyz_identity = [1.0, 0.0, 0.0, 0.0]
    q_t = transform_quaternion_wxyz_to_target(q_wxyz_identity)
    r_t = Rotation.from_quat(q_t).as_matrix()
    assert np.allclose(r_t, np.eye(3), atol=TOL)
