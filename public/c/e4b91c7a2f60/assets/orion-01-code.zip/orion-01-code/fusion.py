"""Phase 2 fusion core.

Orientation: pose_source's quaternion is exact against dev-log truth (Phase 0
finding) - no correction filter, direct pass-through. During a dropout,
attitude is bridged by gyro integration only.

Position: pose_source is smooth/low-noise but carries a slow bias/drift;
RTK is unbiased but noisy. bias_hat is a low-bandwidth (single-pole EMA)
estimate of that drift, driven by RTK updates, and is subtracted from
pose_source position to get the fused position while pose_source is present.
During a dropout, position coasts at a smoothed pre-dropout velocity with
an exponential decay (see NOTES.md for why plain hold, naive-velocity
coast, and accelerometer double-integration were all tried and rejected).

All gains live in fusion_config.yaml - nothing here is a magic number.
"""

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import yaml
from scipy.spatial.transform import Rotation


@dataclass
class FusionConfig:
    bias_tau_s: float
    velocity_window_s: float
    decay_tau_s: float
    causal_tolerance_s: float
    output_rate_hz: float
    degraded_after_s: float
    lost_after_s: float
    startup_warmup_s: float

    @classmethod
    def load(cls, path) -> "FusionConfig":
        raw = yaml.safe_load(Path(path).read_text())
        return cls(
            bias_tau_s=raw["bias_filter"]["tau_s"],
            velocity_window_s=raw["velocity_smoothing"]["window_s"],
            decay_tau_s=raw["dropout_position"]["decay_tau_s"],
            causal_tolerance_s=raw["pose_source_match"]["causal_tolerance_s"],
            output_rate_hz=raw["output"]["rate_hz"],
            degraded_after_s=raw["state_thresholds"]["degraded_after_s"],
            lost_after_s=raw["state_thresholds"]["lost_after_s"],
            startup_warmup_s=raw["confidence"]["startup_warmup_s"],
        )


class BiasEstimator:
    """Single-pole low-pass on (pose_source_position - rtk_position), updated
    at each RTK sample against the causally-matched pose_source sample.
    Frozen (not updated) when no such pose_source sample exists - i.e.
    through a dropout.

    bias_hat starts at zero, not the first raw residual: a single RTK sample
    is dominated by RTK's own measurement noise, and seeding the filter from
    one noisy observation defeats the point of low-bandwidth averaging (see
    NOTES.md "warm start" for the discarded alternative and why it failed
    the self-check p95 band). The first update() call has no prior timestamp
    to derive a rate from, so it only establishes the reference time; the
    second call is the first one that actually moves bias_hat, and it
    converges normally from there.
    """

    def __init__(self, tau_s: float):
        self.tau_s = tau_s
        self.bias_hat = np.zeros(3)
        self._t_prev = None

    def update(self, t_rtk: float, pos_source_m, rtk_pos_m) -> None:
        raw_error = np.asarray(pos_source_m, dtype=float) - np.asarray(rtk_pos_m, dtype=float)
        if self._t_prev is not None:
            dt = t_rtk - self._t_prev
            alpha = 1.0 - np.exp(-dt / self.tau_s)
            self.bias_hat = self.bias_hat + alpha * (raw_error - self.bias_hat)
        self._t_prev = t_rtk


class VelocityEstimator:
    """Velocity from a short sliding window of recent bias-corrected
    pose_source positions, to avoid the noise of a single-sample finite
    difference."""

    def __init__(self, window_s: float):
        self.window_s = window_s
        self._buffer: list[tuple[float, np.ndarray]] = []

    def push(self, t: float, pos_corrected) -> None:
        self._buffer.append((t, np.asarray(pos_corrected, dtype=float)))
        cutoff = t - self.window_s
        self._buffer = [(tt, pp) for tt, pp in self._buffer if tt >= cutoff]

    def estimate(self) -> np.ndarray:
        if len(self._buffer) < 2:
            return np.zeros(3)
        t0, p0 = self._buffer[0]
        t1, p1 = self._buffer[-1]
        dt = t1 - t0
        if dt <= 0:
            return np.zeros(3)
        return (p1 - p0) / dt

    def last(self):
        return self._buffer[-1] if self._buffer else (None, None)


def coast_position(p_last: np.ndarray, v_last: np.ndarray, dt_since_last: float, decay_tau_s: float) -> np.ndarray:
    """Position propagated forward at v_last, exponentially decayed toward
    zero contribution as dt_since_last grows, bounding the worst-case
    excursion instead of extrapolating indefinitely."""
    decay_factor = decay_tau_s * (1.0 - np.exp(-dt_since_last / decay_tau_s))
    return p_last + v_last * decay_factor


class AttitudePropagator:
    """Direct pass-through from pose_source when present; gyro-integrated
    dead reckoning otherwise."""

    def __init__(self):
        self.r = Rotation.identity()

    def set_from_pose_source(self, quat_wxyz) -> None:
        w, x, y, z = quat_wxyz
        self.r = Rotation.from_quat([x, y, z, w])

    def integrate_gyro(self, gyro_rad_s, dt: float) -> None:
        self.r = self.r * Rotation.from_rotvec(np.asarray(gyro_rad_s, dtype=float) * dt)

    def as_quat_wxyz(self) -> np.ndarray:
        x, y, z, w = self.r.as_quat()
        return np.array([w, x, y, z])
