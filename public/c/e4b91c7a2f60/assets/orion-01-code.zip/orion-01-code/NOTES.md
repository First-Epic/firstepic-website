# ORION pose-stream service — design notes

Running log of approaches tried, discarded, and corrected, with reasons. Updated per phase.

## Phase 0 — Reconnaissance

### Corrections from review (all independently re-verified against raw data before accepting)

1. **"Not just dropouts" was wrong.** Excluding the 3 injected/anomalous records
   (idx 201 exact dup of seq=200, idx 242 stray seq=3240, idx 902 stale-tag seq=500 whose
   payload duplicates idx 903's seq=900), the remaining 3240 records have `seq` running
   0..3239 with every integer present exactly once. `3243 total = 3240 legitimate + 3
   injected`. The entire shortfall against the naive "3600 expected at 120 Hz over 30 s"
   figure is explained by the two timestamp gaps (3.02 s missing). Verified by sorting the
   filtered seq list and comparing to `range(0, 3240)` — exact match.

2. **Dropouts are invisible in `seq`.** Across gap 1, `seq` goes 1319 → 1320 (consecutive,
   no skip) while `t_source` jumps 1010.992 → 1013.000. The producer's sequence counter
   does not stall or skip during a dropout — only the timestamp exposes the missing 2 s.
   **Design implication carried into Phase 3: dropout/staleness detection must be
   time-gap-based (`t_source` delta, or wall-clock time since last accepted sample),
   never sequence-based.** A seq-based "did we miss a seq number" check would silently
   pass through both dropouts and never transition to `degraded`/`lost`.

3. **Orientation error is exactly 0.000°, not "essentially zero."** Checked all 9
   dropout-unaffected self-check keyframes: `pose_source.quat_wxyz` equals the self-check
   truth quaternion component-for-component, exact floating-point list equality, at every
   one. My original report showed small nonzero angle values (0.01°–0.015°) — this was a
   numerical artifact of `2*acos(dot)` losing precision when `dot` is extremely close to
   1.0 (derivative of `acos` blows up near ±1), not a real discrepancy. Recomputing with
   direct component comparison instead of the acos angle formula gives an exact match.
   **Design implication carried into Phase 2: orientation needs no correction/fusion from
   RTK or a bias estimator — pose_source orientation is ground truth whenever pose_source
   is present. It only needs (a) the coordinate transform, and (b) gyro-integration
   propagation to bridge the two dropout windows where pose_source is absent entirely.**
   Do not build an orientation correction path that isn't needed — it would just add
   unfalsifiable complexity.

### Confirmed findings (unchanged from Phase 0 report)

- Position: pose_source drifts ~8.7 mm/s, unbounded over session length; RTK is flat/noisy,
  ~0.085 m median error, bounded but ~3x over the 0.03 m band on its own.
- Neither source alone meets the position band. Motivates: pass through pose_source
  orientation as-is, fuse position by estimating and subtracting pose_source's slow drift
  against RTK, propagate through IMU during dropouts.
- Two dropouts, 2.008 s and 1.008 s, matching "both dropouts" in the Phase 3 brief.

## Phase 1 — Coordinate transform

### Corrections from review

1. **Discarded: transforming both pose_source and self-check truth through the same
   `PoseTransformer` as a target-frame validation.** This is circular — a wrong transform
   applied identically to both signals cancels out, since the comparison is really just
   the pre-existing source-frame drift multiplied by a constant (100x, from the m->cm
   scale). It confirms internal consistency (no accidental sign flips or axis mislabels
   between the position and quaternion transform paths) but proves nothing about
   correctness against the actual target frame. Reason for discarding: no independent
   target-frame ground truth exists in the dev log — only the held-out eval reference
   could validate the target frame, and we don't have access to it and must not tune
   against the eval log regardless. **Target-frame correctness rests on construction from
   the contract (verified by unit tests: matrix-vs-closed-form agreement to 1e-9,
   det=+1 preservation, known-axis mapping) — not on empirical comparison.** This
   limitation is stated plainly in REPORT.md (Phase 5). Source-frame comparison against
   self-check bands remains the primary validation metric for fusion accuracy, since
   that's the frame the bands are defined in.

2. **Origin source corrected.** `PoseTransformer.__init__` already took `origin_pos_m` as
   an external parameter (never computed internally) — the Phase 1 validation script just
   passed the wrong value (`pose_source[seq=0]`, which carries ~2 cm of the same error
   documented in Phase 0). From Phase 2 onward, the origin passed in is the **fused**
   position estimate at t=0, not raw pose_source, so that ~2 cm offset isn't baked into
   every output position permanently.

## Phase 2 — Fusion core

### Correction from review: the dropout-strategy experiment was run on the wrong signal

The Phase 2 proposal compared hold / naive-FD-coast / smoothed-velocity-coast /
accelerometer-double-integration using **raw** pose_source position at the dropout
boundary. The service outputs bias-corrected position, and bias_hat is non-negligible
(≈10.6 cm at the first dropout boundary) — so the comparison had to be redone on the
signal the service actually emits. Corrected numbers (bias-corrected, at t=1012.0, the
one self-check keyframe that lands inside dropout 1, 1.008s in):

| Strategy | Error vs. truth |
|---|---|
| Hold (bias-corrected) | 0.280 m |
| Naive 1-sample finite-difference coast | 1.263 m |
| **Smoothed-velocity coast (0.1s window) + exponential decay (τ=1.0s)** | **0.162 m** |
| Accelerometer double-integration (gyro attitude + accel, literal "propagate on IMU") | 0.928 m |
| RTK at t=1012 (not used for output — see below) | 0.099 m |

Ranking is unchanged from the uncorrected experiment: smoothed-velocity coast with decay
remains the best of the four candidate *position-propagation* strategies, and
double-integrating the accelerometer remains clearly worse than doing nothing (hold).
Confirmed with `fusion.py`'s actual `BiasEstimator`/`VelocityEstimator`/`coast_position`,
not just a one-off script (`validate_fusion.py` reproduces 0.162 m directly).

### Considered and rejected: RTK-anchored dropout position

RTK continues at 5 Hz through both dropouts (only pose_source drops out) and is the most
accurate option available during a gap — 0.099 m at t=1012, roughly 3x better than hold
and ~1.6x better than the smoothed-velocity coast. **Not implemented.** The contract is
prescriptive here: during a dropout, publish `degraded`/`lost` with the last good pose
held or a disclosed decay — not a fresh observation from a different source presented as
current tracking. Switching the position source to RTK mid-dropout would be exactly that.
Recording this as a consciously-declined, more-accurate alternative: the fused-position
design optimizes accuracy within the fusion of pose_source+IMU+RTK-as-bias-reference; it
is not the most accurate thing that could technically be emitted, because the contract
defines what's allowed to be emitted as "current" state.

### Causality of the RTK residual (bias filter)

`BiasEstimator.update` needs a pose_source sample at each RTK timestamp. Two options:
linearly interpolate (needs a pose_source sample *after* the RTK timestamp — free in
replay, a real lookahead/latency cost in a live system) or use the most recent pose_source
sample at or before the RTK timestamp (causal, zero lookahead, at the cost of up to one
pose_source period of staleness, ≤8.3ms).

**Chose causal matching.** Measured the actual cost of doing so: compared causal-match vs.
interpolated pose_source position at all 133 non-dropout RTK timestamps in the dev log —
**mean and max discrepancy were both exactly 0.000 cm.** This isn't approximate: RTK's
0.2s period is exactly 24x pose_source's 1/120s period, so every RTK sample lands exactly
on the pose_source sampling grid in this dataset, and both methods resolve to the identical
sample. In general (asynchronous real sensors) causal matching would cost up to ~8ms of
staleness, worth roughly nothing against RTK's own 0.087m noise floor — so causal matching
is the right default even without this dataset's coincidental exact alignment, and it's
the only one that doesn't introduce a hidden lookahead into the latency budget reported in
Phase 4.

### bias_hat behavior during dropouts

Explicit: **frozen**. `BiasEstimator.update()` is simply never called for an RTK tick that
has no causally-valid pose_source sample within `causal_tolerance_s` (0.05s) — there is no
pose_source-vs-RTK residual to compute with no pose_source. This happens automatically as
a consequence of the caller's control flow (the RTK-tick loop skips the update call), not
as a special-cased branch inside `BiasEstimator`. Documented in `fusion_config.yaml` next
to `bias_filter.tau_s` since it's the behavior that config block governs, even though it
isn't itself a tunable (no alternative value is sensible: reusing a stale residual or
extrapolating bias_hat both assume information we don't have).

### Gain selection

**τ_bias (bias low-pass time constant).** Two independent lines of evidence, both landing
in the same place:
- Analytic: lag(τ) = drift_rate x τ (drift_rate = 8.7mm/s, Phase 0), noise(τ) ≈
  rtk_noise_std / sqrt(2 x rtk_rate x τ) (rtk_noise_std = 8.73cm RMS, measured by
  interpolating pose_source to every RTK timestamp and detrending the slow bias component
  with a degree-2 polyfit to isolate the noise floor). Minimizing sqrt(lag²+noise²) gives
  an optimum at τ≈1.71s, predicted total ≈2.6cm.
- Empirical sweep against the 9 dev self-check keyframes (using the corrected,
  zero-initialized `BiasEstimator` - see the warm-start entry below; this table
  supersedes an earlier version run before that fix, whose p95 column was constant
  across every τ because it was dominated by the same seeding bug regardless of τ):

  | τ (s) | position median (cm) | position p95 (cm) |
  |---|---|---|
  | 0.5 | 3.13 | 6.04 |
  | 1.0 | 2.11 | 3.83 |
  | 1.5 | 2.11 | 3.24 |
  | 1.71 | 2.11 | 2.94 |
  | 2.0 | 2.11 | 2.97 |
  | 2.5 | 2.24 | 3.30 |
  | 3.0 | 2.52 | 3.67 |
  | 4.0 | 2.91 | 4.42 |

  Flat optimum region 1.0-2.0s for both median and p95, all comfortably under band (3cm
  median / 8cm p95). **Chose τ_bias=1.5s** — a round number inside the flat optimum;
  1.71s edges it slightly on p95 (2.94cm vs 3.24cm) but the difference isn't worth the
  false precision of matching the analytic optimum exactly.

**τ_decay (dropout position decay).** Same t=1012 single-point check, sweeping τ_decay
with the smoothed velocity estimate: 0.181m (τ=0.5s), 0.155m (τ=1.0s), 0.151m (τ=1.5s),
0.151m (τ=2.0s) — flat above 1s. **Chose τ_decay=1.0s**, matching the observed dropout
timescale; the flatness above 1s means there's nothing to be gained from tuning tighter
than the one available validation point supports.

### Discarded: warm-starting bias_hat from the first raw RTK residual (the actual cause of the p95 failure)

An earlier draft of these notes attributed the p95 band failure (12.9cm vs. an 8cm band)
to an unavoidable cold-start transient. That was wrong — it was a bug. `BiasEstimator`
seeded `bias_hat` directly from the first raw `pose_source - RTK` residual at t=1000
(`bias_hat = raw_error.copy()`), instead of starting from zero. That residual is a single
5Hz RTK sample dominated by RTK's own ~8.7cm measurement noise (see the gain-selection
section above), injected straight into the fused output with zero averaging — exactly
what a low-bandwidth filter exists to prevent. A correctly zero-initialized filter does
not have this failure mode; there was no principled reason position accuracy had to be
bad at t=0.

Two independently-computed sets of numbers confirm both the diagnosis and the fix (the
small differences between "mine" and "reviewer-verified" come from how the very first RTK
tick, which has no prior timestamp to derive an EMA rate from, is handled — not from the
underlying conclusion, which both agree on):

| | t=1000 error | p95 (n=9) | vs. 8cm band |
|---|---|---|---|
| Warm start (bias_hat = first raw residual) — mine | 12.91 cm | 12.91 cm | fails |
| Warm start — reviewer-verified | 12.91 cm | 11.22 cm | fails |
| **Cold start (bias_hat = 0) — mine, shipped** | **2.11 cm** | **3.24 cm** | **passes** |
| Cold start — reviewer-verified | 2.92 cm | 7.25 cm | passes |

**Fix:** `bias_hat` initializes to zero. `BiasEstimator.update()`'s first call has no
`_t_prev` to compute a dt/alpha from, so it only records the reference timestamp and
applies no correction; the *second* call is the first one that actually moves `bias_hat`,
using a real measured dt, and converges normally (governed by `tau_s`) from there. Median
across all 9 reachable keyframes is now 2.11cm, p95 3.24cm — both comfortably inside band
with margin, not a narrow pass.

**Residual tension, disclosed rather than silently absorbed:** with `bias_hat=0` at t=0
by construction, the "fused" position at the very first instant is numerically identical
to raw pose_source at that instant (no correction has been applied yet) — so the
Phase-1-mandated "origin = fused position at t=0" and "origin = raw pose_source at t=0"
coincide here. This is not a bug to fix: there is no legitimate bias estimate before the
second RTK tick arrives, so the origin necessarily carries pose_source's own ~2cm t=0
error regardless of which of the two (equivalent, at t=0) values is used. Noted here so
it isn't mistaken for an unexamined regression of the Phase 1 origin fix.

## Phase 3 — Fault handling and contract conformance

### Output must run on a fixed clock, not on pose_source arrivals

pose_source stalls completely for up to 2.008s during a dropout. A service that only
emits when pose_source (or any single input) arrives would have zero output during that
window, violating the >=24Hz contract minimum outright, not just degrading accuracy. So
`service.py` runs an independent fixed-rate output clock (`output.rate_hz`, 30Hz - 25%
headroom over the 24Hz floor) and merges pose_source/imu/rtk events in time order to keep
internal state current as of each output tick, regardless of which input last arrived.

### One propagation mechanism, not two branches for "tracking" vs. "dropout"

Both attitude and position are anchored at the last accepted pose_source sample (a
"reset point") and propagated forward from there: gyro integration for attitude, decayed
smoothed-velocity coast for position (fusion.py, Phase 2). There is no separate
tracking/dropout branch in the propagation math itself. A reset happens automatically
every time a new pose_source sample is accepted - about every 8ms while tracking - so the
propagation horizon is tiny during normal operation (output is effectively pose_source
resampled onto the 30Hz clock) and only grows large during an actual dropout, where
resets stop happening. `state` and `confidence` are what change meaning as that horizon
grows; the position/attitude computation is the same formula throughout. This was a
deliberate simplification over having explicit tracking/degraded/lost code paths for
propagation - fewer states to keep consistent, one thing to verify correct.

### Reject taxonomy

Three distinct reasons, checked in order (physically-impossible timestamp first, since
it's the most specific and severe; then duplicate vs. stale sequence):

1. `capture_after_source` — `t_captured > t_source` (physically impossible)
2. `duplicate_sequence` — `seq` exactly equals the most recently accepted `seq`
3. `stale_sequence` — `seq` is less than the most recently accepted `seq` (but not equal)

Run against the dev log, this reproduces exactly the 3 anomalies identified in Phase 0,
with the specific reasons matching what Phase 0's manual inspection found: seq=200
(exact duplicate row) -> `duplicate_sequence`; seq=3240 (injected record, both an
out-of-range sequence number and an impossible capture time) -> `capture_after_source`
(caught by the timestamp check before the sequence check is even reached); seq=500
(stale-tagged copy of what should have been seq=900) -> `stale_sequence`.

### State thresholds and confidence

`degraded_after_s=0.1` (source_age_s beyond which output stops being a same-tick
pose_source pass-through and is disclosed as `degraded`) and `lost_after_s=1.0` (matches
`dropout_position.decay_tau_s` - by then the coasted position has mostly decayed and
isn't meaningfully "tracking-adjacent" anymore) - see `fusion_config.yaml` for full
reasoning. `confidence` combines two multiplicative factors: a dropout-depth ramp (1.0
while tracking, linearly down to 0.0 between `degraded_after_s` and `lost_after_s`) and a
one-time startup warmup ramp (0->1 over `confidence.startup_warmup_s`, addressing the
Phase 2 cold-start finding directly: bias_hat needs a few RTK updates to converge, so
early-session confidence is disclosed as lower even while pose_source itself is valid and
state=tracking).

### End-to-end validation (`validate_service.py`), full pipeline: reject -> fuse -> propagate -> transform

- Reject log matches Phase 0's 3 known anomalies exactly, with the reasons above.
- Output: 900 records over 29.967s = 30.03Hz achieved (>=24Hz), `seq` strictly
  increasing, `t_source` strictly increasing, fields match `output_stream_fields` exactly.
- Dropout 1 (2.008s): `state` transitions tracking->degraded->lost and back to tracking;
  `confidence` reaches exactly 0.000 once `lost_after_s` is exceeded.
- Dropout 2 (1.008s): `state` transitions tracking->degraded->tracking - it does **not**
  reach `lost`, even though the gap (1.008s) is *longer* than `lost_after_s` (1.0s). This
  is not because the gap is short relative to the threshold; it's a quantization effect of
  the 30Hz output clock (33.33ms tick period). The last output tick before pose_source
  resumes at t=1022.5 falls at t=1022.466667; `source_age_s` there is 0.987000s - about
  13ms *under* the 1.0s threshold, purely because no tick happens to land in that last
  13ms window before recovery. Verified directly against `PoseStreamService` output (not
  estimated): see the `t=1022.466667` row above `t=1022.5` in a full-resolution dump of
  that window.
  **Fragility this implies:** a 13ms margin against a 33ms tick period is
  phase-dependent - it depends on where the dropout's start/end timestamps happen to fall
  relative to the output clock's fixed grid, not on any property of the dropout itself or
  the `lost_after_s` threshold. A dropout of the same 1.008s duration at a different
  clock phase could legitimately tick past 1.0s and reach `lost`. This is expected,
  disclosed behavior, not something to correct by adjusting `lost_after_s` to force a
  particular outcome for this specific dev-log dropout - the threshold is justified on
  its own terms (matches `dropout_position.decay_tau_s`) independent of where any one
  dropout's boundaries happen to land on the clock. If the eval log's dropout boundaries
  sit at different clock offsets, dropout 2's state sequence there may legitimately
  differ from the dev log's (e.g. touching `lost`) without indicating a bug.
  `source_age_s` was independently verified monotonically non-decreasing throughout both
  gaps.
- Accuracy against self-check bands, comparing the service's actual `pos_target`/
  `quat_target` output (not a side-channel recomputation) against truth transformed
  through the same `PoseTransformer` instance the service built internally:
  - All 10 keyframes: position median 2.17cm / p95 16.21cm (band 3/8cm) - **p95 fails**.
  - The failure is a single point: t=1012.0, the one self-check keyframe that lands
    inside dropout 1. The service correctly reports `state=lost`, `confidence=0.000`
    there - this is the fault-handling contract working as intended (never present a
    dropout-degraded pose as trustworthy), not a fusion-accuracy defect. The self-check
    bands implicitly assume continuous tracking.
  - Restricted to `state=='tracking'` (n=9, excludes only that one disclosed-lost point):
    position median 2.16cm / p95 3.31cm, orientation median/p95 0.00°/0.00° - **both
    bands pass**, consistent with Phase 2's fusion-only validation.

## Phase 4 — Instrumentation and eval run

Latency instrumentation added directly inside `run_service`'s existing loop (`time.perf_counter`
around event-draining + `output_at` per tick) - same code path for dev and eval, so timing
adds a measurement without touching any output value. Dev log: p50/p95 stable in the
0.9-1.3ms / 1.8-2.9ms range across repeated runs, comfortably under the 33.33ms tick
budget; the run-to-run max varies in location and magnitude (24.9-31.1ms range observed),
consistent with OS/interpreter scheduling noise rather than an algorithmic hot spot -
confirmed by rerunning multiple times and observing the outlier land at a different `seq`
each time.

Eval run (`run_eval.py`, unchanged service/config): reject log and state distribution
came out **identical** to the dev log's. Investigated why rather than assuming coincidence:
the eval log's dropout gaps in accepted pose_source are at the exact same `t_source`
boundaries as the dev log's (1010.992-1013.000, 1021.492-1022.500), and the same 3 seq
numbers (200/3240/500) carry the same anomalies. The two fixtures share an identical
fault-injection pattern; only the underlying sensor values differ. Full writeup, including
the eval latency max (93.7ms, one outlier, kept as-observed rather than replaced with a
better-looking rerun) is in REPORT.md's Phase 4 section.

### Conformance check found a bug in the check, not the service

First version of `check_eval_conformance.py` verified `quat_target`'s `[x,y,z,w]` storage
order by independently recomputing each tracking-state record from the eval log's own raw
pose_source + `transform.py`, matched by rounding both sides' timestamps to 6 decimals and
looking up a dict. That reported 274/810 "mismatches." Investigated rather than dismissed
or silently loosened: the mismatches were all tiny (~3e-5 in quaternion components, <0.01°
of rotation), not scrambled/swapped values - the signature of a small residual gyro
propagation, not a wrong component order. Root cause: rounding a timestamp to 6 decimals
for the dict lookup can disagree with the service's actual comparison
(`events[evt_i][0] <= t`, using raw unrounded floats) right at exact grid-boundary
instants - so a handful of ticks got checked against a pose_source sample the service had
correctly not yet consumed (it arrives at the same rounded time but a few ULPs later in
raw form), making a real, correct, tiny gyro-propagated attitude look like a mismatch
against a naive assumption of zero propagation.

First fix attempt replaced the per-record re-derivation with (1) a fresh re-run of the
actual service diffed against the file (0/900 differ) plus (2) a structural argument that
`[x,y,z,w]` order is never reordered between `transform.py` and storage. This was flagged
on review as circular: diffing the file against a fresh run of the *same service* validates
the checker against the exact code it's supposed to catch bugs in - for a top-risk failure
mode (a wrong quaternion component order would silently corrupt every orientation in the
submission), that's not good enough.

**Final fix: `verify_quat_order.py`**, a fully standalone script - reads only
`orion-eval-output.jsonl`, `orion-dev-log.json`, `orion-dev-output.jsonl`, and the
contract, no import of `transform.py`/`service.py`/`fusion.py`, plain Python arithmetic
only. Three independent checks, all passing:
1. **Magnitude structure**: with a gentle camera move (source `w` near 0.98, `x/y/z`
   small), correct `[x,y,z,w]` storage means index 3 should be the largest-magnitude
   component on essentially every record - a wrong order fails this immediately and
   loudly. 0/900 violations.
2. **Hand-computed spot check**: applied the closed-form derivation
   (`q_t_wxyz = (-w, x, z, y)`, stored `[x, z, y, -w]`) by hand (pure component
   relabeling, no scipy/rotation-matrix machinery) to 3 raw dev-log pose_source records
   (t=1000.0, 1015.0, 1027.0) and compared to the corresponding lines of
   `orion-dev-output.jsonl`. All 3 matched **with every component negated** - expected,
   not a bug: quaternion double-cover means `q` and `-q` are the same rotation, and
   scipy's `Rotation.as_quat()` (used internally by the service, not by this script)
   picks its own canonical sign branch. Verified the sign flip was *consistent* across
   all three independent timestamps (not a mix of matched/flipped, which is what a
   genuine double-cover relationship looks like vs. a coincidental partial match).
3. **Norm check**: every eval `quat_target` unit-norm to 1e-9. 0/900 violations.

Recorded both fix attempts here because catching your own verification-tool bug (twice)
and being told the second fix was still not good enough is exactly the kind of judgment
call worth showing, not just the final "PASS."

### Timecode discrepancy (flagged, not invented)

The build brief's Phase 3 section mentions "a decoded timecode." `orion-pose-contract-v2.json`'s
`output_stream_fields` has no timecode field (confirmed: no match for "timecode" anywhere
in the contract file). Not implemented - inventing a field the authoritative contract
doesn't define would itself be a conformance violation. Flagging this explicitly per the
brief's own instruction rather than silently ignoring it or silently adding one.
