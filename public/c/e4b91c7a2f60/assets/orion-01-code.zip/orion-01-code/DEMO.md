# Recording rehearsal script

Practical reference for the live run. Not for the video itself — talk track is yours.

## Pre-flight (once, before rehearsing — not on camera)

Confirm you're at the repo root and the venv already exists:

```bash
cd "/mnt/e/epic assignment"
ls .venv/bin/python   # should exist — if not, see README.md "Setup"
```

If `.venv` doesn't exist, building it from scratch takes ~30–60s (`pip install numpy scipy
pytest pyyaml`) — do that before recording starts, not live.

---

## Cold-start command sequence

Every command below assumes a **fresh terminal** — venv not yet activated, nothing cached
in memory. Run `source .venv/bin/activate` first; you'll see `(.venv)` appear in the prompt.

| # | Command | Time | What confirms it worked |
|---|---|---|---|
| 1 | `source .venv/bin/activate` | instant | prompt shows `(.venv)` |
| 2 | `python -m pytest test_transform.py -v` | ~9s | `9 passed` |
| 3 | `python run_eval.py` | ~5s | see below |
| 4 | `python check_eval_conformance.py` | ~5s | `PASS` + 9x `[PASS]` |
| 5 | `python verify_quat_order.py` | <1s | `OVERALL: PASS` |
| 6 | `python part2_qualification_gate.py` | ~1s | `NOT QUALIFIED` (this is the correct, expected result — see note below) |

### 2. `python -m pytest test_transform.py -v`
Expect all 9 test names listed with `PASSED`, ending:
```
9 passed in 8.6s
```

### 3. `python run_eval.py`
Expect:
```
pose_source: 3240 accepted, 3 rejected
  {'seq': 200, 'reason': 'duplicate_sequence'}
  {'seq': 3240, 'reason': 'capture_after_source'}
  {'seq': 500, 'reason': 'stale_sequence'}

output: 900 records, 29.967s span, 30.000 Hz achieved
state distribution: {'tracking': 816, 'degraded': 54, 'lost': 30}
latency: p50=...us p95=...us max=...us
seq strictly increasing: True
t_source strictly increasing: True

wrote orion-eval-output.jsonl, orion-eval-rejected.jsonl, orion-eval-latency-trace.jsonl
```
**The three latency numbers will be different every time you run this** — that's expected
system timing noise, not a bug (REPORT.md's Phase 4 section explains why the max is kept
as-observed rather than tuned). Don't pause on them if they don't match REPORT.md exactly;
`state distribution` and `30.000 Hz` should match exactly every run.

### 4. `python check_eval_conformance.py`
Expect `PASS` on the first line, then 9 `[PASS]` lines (field set, seq, t_source,
confidence range, state enum, pos_target/quat_target element counts, unit-norm, file
fidelity). If anything shows `[FAIL]`, stop — that's a real problem, not noise.

### 5. `python verify_quat_order.py`
Three sections, each ending `RESULT: PASS`, then `=== OVERALL: PASS ===`. The
hand-computed spot check section will show three timestamps where the "actual" line is
the **negative** of the "hand-computed" line — that's expected (quaternion double cover,
explained in REPORT.md's Transform section), not a mismatch. The script itself labels it
`PASS (opposite sign - same rotation...)`.

### 6. `python part2_qualification_gate.py`
**This one is supposed to fail** — it's demonstrating that the gate correctly catches a
bad artifact. Expect three `[FAIL]` sections (metric scale, solve quality, provenance) and
a final line:
```
=== GATE VERDICT: NOT QUALIFIED - block splat training ===
(artifact's own stored value was qualified=True - DISAGREES: the stored flag was wrong)
```
The process exits with code 1 — if your terminal shows an exit-code indicator, it'll be
non-zero here. That's correct. If you want to show that explicitly: `echo $?` right after
prints `1`.

---

## Resetting to a genuine cold start between rehearsals

Only step 3 (`run_eval.py`) writes files. `orion-eval-output.jsonl` and
`orion-eval-rejected.jsonl` are **deterministic** — content is byte-identical every run, so
they won't show as changed. `orion-eval-latency-trace.jsonl` **will** differ every run (it's
a timing measurement, not an algorithm output) — `git status` will show it modified after
step 3.

To reset all three back to exactly the committed/submitted versions before your next
rehearsal:

```bash
git checkout -- orion-eval-output.jsonl orion-eval-rejected.jsonl orion-eval-latency-trace.jsonl
```

If you also ran the `orion-dev-output.jsonl` regeneration one-liner from REPORT.md's
Reproduction section, reset that too (it's also deterministic, so this is mostly cosmetic):

```bash
git checkout -- orion-dev-output.jsonl
```

`python -m pytest`, `check_eval_conformance.py`, `verify_quat_order.py`, and
`part2_qualification_gate.py` never write files — safe to rerun any number of times with
no reset needed. `.pytest_cache/` and `__pycache__/` get touched but are gitignored and
invisible to `git status`.

To fully verify you're at a clean cold state before recording for real:
```bash
git status --short   # should print nothing
```

---

## Files to have open, by section

Editor tabs, in the order you'll likely reference them. Line numbers are jump targets, not
required reading order.

**1. Transform derivation**
1. `transform.py` — the docstring at the top has the full derivation and the sign note.
2. `test_transform.py` — the 9 tests, especially `test_quaternion_matches_matrix_conjugation`.
3. `REPORT.md` → **Transform** section — the numbers (8.9e-16 max error, the double-cover
   sign note).

**2. The bias filter**
1. `fusion.py` — `BiasEstimator` class.
2. `fusion_config.yaml` — `bias_filter.tau_s`, read the comment block above it.
3. `REPORT.md` → **Fusion** section — the τ sweep table and self-check numbers.

**3. Fault handling**
1. `service.py` — `validate_pose_source` (reject taxonomy) and `PoseStreamService`
   (state/confidence/source_age_s logic).
2. `fusion_config.yaml` — `state_thresholds` / `confidence` sections.
3. `orion-eval-rejected.jsonl` — 3 lines, quick to show on screen.
4. `REPORT.md` → **Fault handling** section — the dropout-2 margin explanation.

**4. Mistakes in NOTES.md** — the file is long (~390 lines); jump by header rather than
scrolling top to bottom:
- Line 7 — Phase 0: three corrections (sequence completeness, dropout invisible in `seq`,
  orientation "exactly 0.000°" not "essentially zero").
- Line 50 — Phase 1: the circular self-check validation, discarded.
- Line 77 — Phase 2: dropout-strategy experiment redone on the bias-corrected signal.
- **Line 179** — Phase 2: the warm-start bug (the big one — bad number vs. fixed number,
  side-by-side table). Probably your strongest single example.
- Line 335 — Phase 4: the conformance-check bug found twice (rounding-lookup false
  positive, then the circular re-run check), before landing on the independent script.

**5. Part 2**
1. `orion-reconstruction-artifact.json` — the raw input; the smoking gun is
   `metric_scale.reported_scale_factor: 1.000` next to `rtk_baseline_check`.
2. `PART2_REPORT.md` — the defect writeup and verification method.
3. `part2_qualification_gate.yaml` — the thresholds, with reasoning in comments.
4. `part2_qualification_gate.py` — then run it live (command 6 above).

---

## What's on screen if you open the folder

See the chat response for the full deliverables-vs-working-files breakdown. Nothing in the
tracked files contains absolute paths, credentials, or secrets (checked). One thing to be
aware of, not a problem: `git log` shows your own commit author name/email
(`[name]161 <[email]>`) if you run it on camera — that's your real
info, not a leak, just flagging it's visible if you didn't intend to show it.
