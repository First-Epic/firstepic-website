"""Independent verification that quat_target is stored in [x, y, z, w] order.

Deliberately does NOT import transform.py, service.py, or fusion.py - the
prior conformance check was invalidated for exactly that reason (it diffed
against a fresh re-run of the service, which validates the checker against
the code it exists to verify - circular, for a top-risk failure mode). This
script reads only orion-eval-output.jsonl, orion-dev-log.json,
orion-dev-output.jsonl, and the contract, and does its own arithmetic with
plain Python (json, math) - no scipy, no numpy, no project modules.

Three independent checks:
  1. Magnitude structure: the camera move is gentle (source w stays near
     0.98, x/y/z stay small). In correct [x,y,z,w] storage, index 3 should
     be the near-unity, largest-magnitude component on essentially every
     record. A wrong storage order fails this immediately and loudly.
  2. Hand-computed spot check: apply the reviewer-supplied closed-form
     derivation (q_t_wxyz = (-w, x, z, y), stored [x, z, y, -w]) by hand to
     three raw pose_source records from orion-dev-log.json, and compare
     against the corresponding lines of orion-dev-output.jsonl - allowing
     for the quaternion double-cover sign ambiguity (q and -q are the same
     rotation), checked and reported explicitly, not silently absorbed.
  3. Norm check: every stored quaternion should be unit-norm to 1e-9.
"""

import json
import math


def load_jsonl(path):
    with open(path) as f:
        return [json.loads(line) for line in f]


def check_magnitude_structure(records):
    violations = []
    for r in records:
        q = r["quat_target"]
        max_idx = max(range(4), key=lambda i: abs(q[i]))
        if max_idx != 3:
            violations.append((r["seq"], r["t_source"], q, max_idx))
    return violations


def check_norm(records, tol=1e-9):
    violations = []
    for r in records:
        q = r["quat_target"]
        norm = math.sqrt(sum(c * c for c in q))
        if abs(norm - 1.0) > tol:
            violations.append((r["seq"], r["t_source"], norm))
    return violations


def hand_apply_derivation(quat_wxyz):
    """q_t_wxyz = (-w, x, z, y), stored [x, z, y, -w]. Pure component
    relabeling + sign flip - no rotation-matrix or scipy machinery."""
    w, x, y, z = quat_wxyz
    return [x, z, y, -w]


def close(a, b, tol=1e-6):
    return all(abs(ai - bi) < tol for ai, bi in zip(a, b))


def check_hand_spot(dev_log_path, dev_output_path, timestamps):
    with open(dev_log_path) as f:
        dev_log = json.load(f)
    ps_by_t = {}
    for r in dev_log["streams"]["pose_source"]:
        ps_by_t.setdefault(r["t_source"], r)  # first occurrence only; dev log's 3 known
        # anomalous records never land on these hand-picked, previously-validated timestamps

    dev_output = load_jsonl(dev_output_path)
    out_by_t = {r["t_source"]: r for r in dev_output}

    results = []
    for t in timestamps:
        src = ps_by_t.get(t)
        out = out_by_t.get(t)
        if src is None or out is None:
            results.append((t, None, None, None, "MISSING"))
            continue
        hand_computed = hand_apply_derivation(src["quat_wxyz"])
        actual = out["quat_target"]
        neg_hand = [-c for c in hand_computed]
        if close(actual, hand_computed):
            verdict = "PASS (exact sign match)"
        elif close(actual, neg_hand):
            verdict = "PASS (opposite sign - same rotation, quaternion double-cover)"
        else:
            verdict = "FAIL"
        results.append((t, src["quat_wxyz"], hand_computed, actual, verdict))
    return results


def main():
    eval_records = load_jsonl("orion-eval-output.jsonl")

    print("=== 1. Magnitude structure (index 3 should be near-unity / largest, every record) ===")
    mag_violations = check_magnitude_structure(eval_records)
    print(f"n={len(eval_records)}, violations={len(mag_violations)}")
    if mag_violations:
        for seq, t, q, idx in mag_violations[:10]:
            print(f"  seq={seq} t={t} quat_target={q} largest-magnitude index={idx} (expected 3)")
    print(f"RESULT: {'PASS' if not mag_violations else 'FAIL'}\n")

    print("=== 2. Hand-computed spot check (3 dev-log timestamps, no transform.py/service.py) ===")
    spot_timestamps = [1000.0, 1015.0, 1027.0]
    spot_results = check_hand_spot("orion-dev-log.json", "orion-dev-output.jsonl", spot_timestamps)
    all_pass = True
    for t, src_q, hand_q, actual_q, verdict in spot_results:
        print(f"  t={t}")
        if verdict == "MISSING":
            print("    MISSING data - cannot check")
            all_pass = False
            continue
        print(f"    source quat_wxyz   = {src_q}")
        print(f"    hand-computed [x,z,y,-w] = {[round(c,8) for c in hand_q]}")
        print(f"    actual quat_target = {[round(c,8) for c in actual_q]}")
        print(f"    {verdict}")
        if verdict == "FAIL":
            all_pass = False
    print(f"RESULT: {'PASS' if all_pass else 'FAIL'}\n")

    print("=== 3. Norm check (unit norm to 1e-9, every eval record) ===")
    norm_violations = check_norm(eval_records, tol=1e-9)
    print(f"n={len(eval_records)}, violations={len(norm_violations)}")
    if norm_violations:
        for seq, t, norm in norm_violations[:10]:
            print(f"  seq={seq} t={t} norm={norm:.12f}")
    print(f"RESULT: {'PASS' if not norm_violations else 'FAIL'}\n")

    overall = (not mag_violations) and all_pass and (not norm_violations)
    print(f"=== OVERALL: {'PASS' if overall else 'FAIL'} ===")


if __name__ == "__main__":
    main()
