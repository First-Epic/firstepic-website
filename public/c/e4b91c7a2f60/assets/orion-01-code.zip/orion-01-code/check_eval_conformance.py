"""Phase 4 conformance check: verify orion-eval-output.jsonl against
orion-pose-contract-v2.json's output_stream_fields literally, field by
field, reporting pass/fail rather than asserting it. Field names/set are
read from the contract file itself, not hardcoded, so a drift between the
contract and this script's assumptions would show up as a failure instead
of being silently missed.
"""

import json

import numpy as np

VALID_STATES = {"tracking", "degraded", "lost"}


def load_output(path):
    records = []
    with open(path) as f:
        for line in f:
            records.append(json.loads(line))
    return records


def main():
    with open("orion-pose-contract-v2.json") as f:
        contract = json.load(f)
    contract_fields = set(contract["output_stream_fields"].keys())

    records = load_output("orion-eval-output.jsonl")
    n = len(records)
    results = []

    def check(name, ok, detail=""):
        results.append((name, ok, detail))

    # --- field set: exact match against the contract, every record ---
    field_mismatches = []
    for i, r in enumerate(records):
        keys = set(r.keys())
        if keys != contract_fields:
            missing = contract_fields - keys
            extra = keys - contract_fields
            field_mismatches.append((i, missing, extra))
    check("field set matches output_stream_fields exactly (no missing, no extra)",
          len(field_mismatches) == 0,
          f"{len(field_mismatches)}/{n} records mismatched" if field_mismatches else f"contract fields: {sorted(contract_fields)}")

    # --- seq strictly increasing ---
    seqs = [r["seq"] for r in records]
    seq_ok = all(b > a for a, b in zip(seqs, seqs[1:]))
    check("seq strictly increasing", seq_ok, f"n={n}, first={seqs[0]}, last={seqs[-1]}")

    # --- t_source monotonic (contract says "monotonic", not "strictly increasing" - non-decreasing is sufficient) ---
    ts = [r["t_source"] for r in records]
    t_ok = all(b >= a for a, b in zip(ts, ts[1:]))
    check("t_source monotonic (non-decreasing)", t_ok, f"range=[{ts[0]}, {ts[-1]}]")

    # --- confidence within [0, 1] ---
    confs = [r["confidence"] for r in records]
    conf_ok = all(0.0 <= c <= 1.0 for c in confs)
    check("confidence within [0, 1] for every record", conf_ok,
          f"range=[{min(confs):.4f}, {max(confs):.4f}]")

    # --- state only ever tracking/degraded/lost ---
    states = set(r["state"] for r in records)
    state_ok = states <= VALID_STATES
    check("state only ever tracking/degraded/lost", state_ok, f"observed values: {sorted(states)}")

    # --- pos_target: exactly 3 numeric elements ---
    pos_len_ok = all(isinstance(r["pos_target"], list) and len(r["pos_target"]) == 3 for r in records)
    check("pos_target has exactly 3 elements, every record", pos_len_ok)

    # --- quat_target: exactly 4 numeric elements, unit norm ---
    quat_len_ok = all(isinstance(r["quat_target"], list) and len(r["quat_target"]) == 4 for r in records)
    check("quat_target has exactly 4 elements, every record", quat_len_ok)

    quat_norms = np.array([np.linalg.norm(r["quat_target"]) for r in records])
    quat_unit_ok = bool(np.all(np.abs(quat_norms - 1.0) < 1e-6))
    check("quat_target is unit-norm, every record", quat_unit_ok,
          f"max |norm-1| = {np.max(np.abs(quat_norms - 1.0)):.2e}")

    # --- file fidelity: re-run the real service fresh on the eval log and confirm the
    # file's records match the in-memory output exactly. (An earlier version of this
    # check instead tried to independently re-derive each record from a rounded-time
    # dict lookup into raw pose_source - that produced ~34% "mismatches" that were a
    # methodology artifact, not a real bug: rounding a timestamp to 6dp for the lookup
    # can disagree with the service's actual raw-float "<=" comparison at exact grid
    # boundaries, so a handful of ticks got checked against a sample the service had
    # correctly not yet consumed, showing up as a tiny [~1e-4 rad] gyro-propagation
    # difference that looked like a mismatch. Comparing against a fresh run of the real
    # code sidesteps that entirely - see NOTES.md Phase 4.)
    from fusion import FusionConfig
    from service import run_service

    with open("orion-eval-log.json") as f:
        eval_log = json.load(f)
    cfg = FusionConfig.load("fusion_config.yaml")
    fresh_outputs, _, _, _, _ = run_service(eval_log["streams"], cfg)

    fidelity_mismatches = 0
    for file_r, fresh_r in zip(records, fresh_outputs):
        if file_r["seq"] != fresh_r["seq"] or file_r["t_source"] != fresh_r["t_source"]:
            fidelity_mismatches += 1
            continue
        if not np.allclose(file_r["quat_target"], fresh_r["quat_target"], atol=1e-9):
            fidelity_mismatches += 1
    check("orion-eval-output.jsonl exactly reflects a fresh run of the current service (no write/read corruption)",
          fidelity_mismatches == 0, f"{fidelity_mismatches}/{n} records differ")

    # quat_target's [x,y,z,w] storage order is deliberately NOT checked here. An earlier
    # version of this script checked it via a fresh re-run of the service (this file's
    # "file fidelity" check above) and, before that, via source inspection of this same
    # codebase - both were flagged as circular: they validate against the code they exist
    # to verify, which isn't good enough for a top-risk failure mode. The authoritative
    # order check is verify_quat_order.py, which reads only this output file, the dev
    # log, and the contract - no import of transform.py/service.py/fusion.py. Run it
    # separately; see NOTES.md and REPORT.md for its three independent checks (magnitude
    # structure, hand-computed spot check, norm check), all passing.

    # --- report ---
    print(f"{'PASS' if all(ok for _, ok, _ in results) else 'FAIL (see below)'} - checked {n} records against the contract's own output_stream_fields\n")
    for name, ok, detail in results:
        status = "PASS" if ok else "FAIL"
        line = f"[{status}] {name}"
        if detail:
            line += f"  -  {detail}"
        print(line)


if __name__ == "__main__":
    main()
