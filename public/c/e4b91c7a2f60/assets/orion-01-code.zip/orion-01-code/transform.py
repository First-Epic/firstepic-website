"""ENU source frame -> ORION target frame coordinate transform.

Source: ENU right-handed, meters, quaternion [w,x,y,z] body->world.
Target (contract v2): left-handed, centimeters, X=East Y=Up Z=North,
quaternion stored [x,y,z,w], point transform, origin at t=0 position.

Derivation: position mapping (X_t=X_s, Y_t=Z_s, Z_t=Y_s) is the linear map
v_t = P @ v_s where P swaps rows 2 and 3 - a single transposition, so
det(P) = -1 (this is what flips handedness) and P is symmetric and its own
inverse (P @ P == I).

Rotations must be conjugated, not left-multiplied: R_t = P @ R_s @ P.T. A
one-sided P @ R_s would have det = det(P) * det(R_s) = -1, an improper
rotation (reflection) - wrong, since the physical orientation is still a
proper rotation when expressed consistently in the target's own coordinates.
Conjugation preserves det(R_t) = det(P)**2 * det(R_s) = det(R_s) = +1.
Verified numerically against 20000 random rotations (max matrix error
8.9e-16); see test_transform.py::test_quaternion_matches_matrix_conjugation.
"""

import numpy as np
from scipy.spatial.transform import Rotation

AXIS_SWAP = np.array([
    [1.0, 0.0, 0.0],
    [0.0, 0.0, 1.0],
    [0.0, 1.0, 0.0],
])

M_TO_CM = 100.0


def transform_rotation_matrix(r: np.ndarray) -> np.ndarray:
    """Conjugate a rotation matrix by the axis-swap permutation.

    Self-inverse: calling this twice returns the original matrix, since
    AXIS_SWAP is symmetric and AXIS_SWAP @ AXIS_SWAP == I.
    """
    return AXIS_SWAP @ r @ AXIS_SWAP.T


def transform_quaternion_wxyz_to_target(quat_wxyz) -> np.ndarray:
    """Source [w,x,y,z] body->world -> target storage [x,y,z,w]."""
    q = np.asarray(quat_wxyz, dtype=float)
    r_source = Rotation.from_quat([q[1], q[2], q[3], q[0]])
    r_target = Rotation.from_matrix(transform_rotation_matrix(r_source.as_matrix()))
    return r_target.as_quat()  # scipy's default order is [x,y,z,w], matches target storage directly


def inverse_transform_quaternion_target_to_wxyz(quat_xyzw) -> np.ndarray:
    """Target-stored [x,y,z,w] -> source [w,x,y,z]. For tests / round-trips only."""
    q = np.asarray(quat_xyzw, dtype=float)
    r_target = Rotation.from_quat(q)
    r_source = Rotation.from_matrix(transform_rotation_matrix(r_target.as_matrix()))
    x, y, z, w = r_source.as_quat()
    return np.array([w, x, y, z])


def transform_position_no_origin(pos_m) -> np.ndarray:
    pos_m = np.asarray(pos_m, dtype=float)
    return (AXIS_SWAP @ pos_m) * M_TO_CM


def inverse_transform_position_no_origin(pos_cm) -> np.ndarray:
    pos_cm = np.asarray(pos_cm, dtype=float)
    return AXIS_SWAP @ (pos_cm / M_TO_CM)


class PoseTransformer:
    """Freezes the target-frame origin at construction from the t=0 source
    position, per contract: "origin translated so the t=0 position is the
    origin"."""

    def __init__(self, origin_pos_m):
        self.origin_cm = transform_position_no_origin(origin_pos_m)

    def transform_position(self, pos_m) -> np.ndarray:
        return transform_position_no_origin(pos_m) - self.origin_cm

    def inverse_transform_position(self, pos_cm) -> np.ndarray:
        return inverse_transform_position_no_origin(np.asarray(pos_cm, dtype=float) + self.origin_cm)

    @staticmethod
    def transform_quaternion(quat_wxyz) -> np.ndarray:
        return transform_quaternion_wxyz_to_target(quat_wxyz)

    @staticmethod
    def inverse_transform_quaternion(quat_xyzw) -> np.ndarray:
        return inverse_transform_quaternion_target_to_wxyz(quat_xyzw)

    def transform_pose(self, pos_m, quat_wxyz):
        return self.transform_position(pos_m), self.transform_quaternion(quat_wxyz)
