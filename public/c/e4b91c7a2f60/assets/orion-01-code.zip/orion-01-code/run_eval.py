"""Phase 4: run the finished, unchanged service on orion-eval-log.json (raw,
no truth) and write the required submission artifacts:

  - orion-eval-output.jsonl   (one JSON object per line, output_stream_fields)
  - orion-eval-rejected.jsonl (one JSON object per line, {seq, reason})
  - orion-eval-latency-trace.jsonl (one JSON object per line, {seq, t_source, latency_s})

No tuning happens here or after seeing this output. fusion_config.yaml and
service.py are identical to what was validated against orion-dev-log.json
in Phases 2/3 - this script only loads, runs, and writes.
"""

import json

import numpy as np

from fusion import FusionConfig
from service import run_service


def main():
    with open("orion-eval-log.json") as f:
        eval_log = json.load(f)
    cfg = FusionConfig.load("fusion_config.yaml")

    outputs, rejected, n_accepted, svc, latency_trace = run_service(eval_log["streams"], cfg)

    with open("orion-eval-output.jsonl", "w") as f:
        for record in outputs:
            f.write(json.dumps(record) + "\n")

    with open("orion-eval-rejected.jsonl", "w") as f:
        for r in rejected:
            f.write(json.dumps(r) + "\n")

    with open("orion-eval-latency-trace.jsonl", "w") as f:
        for r in latency_trace:
            f.write(json.dumps(r) + "\n")

    ts = np.array([o["t_source"] for o in outputs])
    lat = np.array([r["latency_s"] for r in latency_trace])
    states = [o["state"] for o in outputs]
    from collections import Counter
    state_counts = Counter(states)

    print(f"pose_source: {n_accepted} accepted, {len(rejected)} rejected")
    for r in rejected:
        print(" ", r)
    print(f"\noutput: {len(outputs)} records, {ts[-1]-ts[0]:.3f}s span, "
          f"{(len(ts)-1)/(ts[-1]-ts[0]):.3f} Hz achieved")
    print(f"state distribution: {dict(state_counts)}")
    print(f"latency: p50={np.percentile(lat,50)*1e6:.1f}us p95={np.percentile(lat,95)*1e6:.1f}us "
          f"max={lat.max()*1e6:.1f}us")

    seqs = [o["seq"] for o in outputs]
    print(f"seq strictly increasing: {all(b>a for a,b in zip(seqs, seqs[1:]))}")
    print(f"t_source strictly increasing: {all(b>a for a,b in zip(ts, ts[1:]))}")

    print("\nwrote orion-eval-output.jsonl, orion-eval-rejected.jsonl, orion-eval-latency-trace.jsonl")


if __name__ == "__main__":
    main()
