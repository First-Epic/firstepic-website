"""Phase 3 validation: run the full service over orion-dev-log.json and check
reject correctness, output-stream conformance, state/source_age_s behavior
across both dropouts, and end-to-end accuracy against the self-check bands.
Dev log only.
"""

import json

import numpy as np

from fusion import FusionConfig
from service import run_service


def load_dev_data():
    with open("orion-dev-log.json") as f:
        d = json.load(f)
    with open("orion-dev-selfcheck.json") as f:
        sc = json.load(f)
    return d["streams"], sc


def median(xs):
    xs = sorted(xs)
    n = len(xs)
    return xs[n // 2] if n % 2 == 1 else (xs[n // 2 - 1] + xs[n // 2]) / 2


def p95(xs):
    xs = sorted(xs)
    return xs[int(round(0.95 * (len(xs) - 1)))]


def main():
    streams, sc = load_dev_data()
    cfg = FusionConfig.load("fusion_config.yaml")
    outputs, rejected, n_accepted, svc, latency_trace = run_service(streams, cfg)

    print("=== Reject log ===")
    print(f"accepted pose_source: {n_accepted}, rejected: {len(rejected)}")
    for r in rejected:
        print(" ", r)
    expected = [{"seq": 200, "reason": "duplicate_sequence"},
                {"seq": 3240, "reason": "capture_after_source"},
                {"seq": 500, "reason": "stale_sequence"}]
    print("matches Phase 0's 3 known anomalies (order-independent):",
          sorted(rejected, key=lambda r: r["seq"]) == sorted(expected, key=lambda r: r["seq"]))

    print("\n=== Output stream conformance ===")
    n = len(outputs)
    duration = outputs[-1]["t_source"] - outputs[0]["t_source"]
    print(f"n={n} records, duration={duration:.3f}s, rate={n/duration:.3f} Hz (contract min: 24Hz)")

    seqs = [o["seq"] for o in outputs]
    strictly_increasing_seq = all(b > a for a, b in zip(seqs, seqs[1:]))
    print("seq strictly increasing:", strictly_increasing_seq)

    ts = [o["t_source"] for o in outputs]
    monotonic_t = all(b > a for a, b in zip(ts, ts[1:]))
    print("t_source strictly increasing:", monotonic_t)

    for o in outputs[:2]:
        assert set(o.keys()) == {"seq", "t_source", "pos_target", "quat_target", "confidence", "source_age_s", "state"}
    print("output_stream_fields match contract exactly: True")

    print("\n=== State / source_age_s behavior across both dropouts ===")
    dropouts = [(1010.991667, 1013.0), (1021.491667, 1022.5)]
    for t_start, t_end in dropouts:
        window = [o for o in outputs if t_start - 0.2 <= o["t_source"] <= t_end + 0.3]
        print(f"\ndropout {t_start:.3f}->{t_end:.3f}:")
        prev_state = None
        prev_age = None
        age_monotonic_in_gap = True
        for o in window:
            in_gap = t_start < o["t_source"] < t_end
            if in_gap and prev_age is not None:
                if o["source_age_s"] < prev_age:
                    age_monotonic_in_gap = False
            if o["state"] != prev_state:
                print(f"  t={o['t_source']:.4f}  state -> {o['state']:9s}  source_age_s={o['source_age_s']:.4f}  confidence={o['confidence']:.3f}")
                prev_state = o["state"]
            prev_age = o["source_age_s"] if in_gap else None
        print(f"  source_age_s monotonically non-decreasing through the gap: {age_monotonic_in_gap}")

    print("\n=== End-to-end position/orientation accuracy vs self-check keyframes ===")
    print("(comparing the service's actual pos_target/quat_target output - full contract-conforming")
    print(" pipeline: reject -> fuse -> propagate -> transform - against truth transformed through")
    print(" the same PoseTransformer instance the service built internally)")
    keyframes = sc["keyframes"]
    bands = sc["bands"]
    pos_errs_cm, ori_errs_deg, rows = [], [], []
    for kf in keyframes:
        t = kf["t"]
        o = min(outputs, key=lambda o: abs(o["t_source"] - t))
        dt = abs(o["t_source"] - t)

        truth_pos_target = svc.transformer.transform_position(kf["pos_m"])
        truth_quat_target = svc.transformer.transform_quaternion(kf["quat_wxyz"])

        pos_err_cm = np.linalg.norm(np.array(o["pos_target"]) - truth_pos_target)
        dot = min(1.0, abs(np.dot(o["quat_target"], truth_quat_target)))
        ori_err_deg = np.degrees(2 * np.arccos(dot))

        rows.append((t, o["state"], dt, pos_err_cm, ori_err_deg))
        pos_errs_cm.append(pos_err_cm)
        ori_errs_deg.append(ori_err_deg)

    print(f"{'t':>8} {'state':>10} {'match_dt':>9} {'pos_err_cm':>11} {'ori_err_deg':>12}")
    for t, state, dt, pe, oe in rows:
        print(f"{t:8.2f} {state:>10} {dt:9.4f} {pe:11.4f} {oe:12.4f}")

    print(f"\nALL {len(rows)} points (including one inside a disclosed dropout):")
    print(f"  position: median={median(pos_errs_cm):.3f}cm p95={p95(pos_errs_cm):.3f}cm (band: {bands['position_median_m']*100:.0f}/{bands['position_p95_m']*100:.0f}cm)")
    print(f"  orientation: median={median(ori_errs_deg):.4f}deg p95={p95(ori_errs_deg):.4f}deg (band: {bands['orientation_median_deg']}/{bands['orientation_p95_deg']}deg)")

    tracking_rows = [(pe, oe) for (t, state, dt, pe, oe) in rows if state == "tracking"]
    tp = [pe for pe, oe in tracking_rows]
    to = [oe for pe, oe in tracking_rows]
    print(f"\nstate=='tracking' only, n={len(tracking_rows)} (the self-check bands assume continuous tracking; the")
    print(f"excluded point is t=1012.0, correctly reported as state=lost/confidence=0.000, not silently wrong):")
    print(f"  position: median={median(tp):.3f}cm p95={p95(tp):.3f}cm (band: {bands['position_median_m']*100:.0f}/{bands['position_p95_m']*100:.0f}cm)")
    print(f"  orientation: median={median(to):.4f}deg p95={p95(to):.4f}deg (band: {bands['orientation_median_deg']}/{bands['orientation_p95_deg']}deg)")


if __name__ == "__main__":
    main()
