# ORION pose-stream service — report

## Transform

Source: ENU right-handed, meters, quaternion `[w,x,y,z]` body->world.
Target (contract v2): left-handed, centimeters, X=East Y=Up Z=North, quaternion stored
`[x,y,z,w]`, point transform, origin at t=0 position.

**Position**: `v_t = P @ v_s`, where `P` swaps rows 2 and 3 (`X_t=X_s, Y_t=Z_s, Z_t=Y_s`),
then scale by 100 (m->cm), then subtract the origin. `P` is a single transposition, so
`det(P) = -1` (this is what flips handedness), and `P` is symmetric and its own inverse
(`P @ P = I`).

**Rotation**: conjugate, `R_t = P @ R_s @ P.T`, not a one-sided `P @ R_s`. A one-sided
product would have `det = det(P) * det(R_s) = -1` - an improper rotation (reflection) in
target coordinates, which is wrong: the physical orientation is still a proper rotation
when expressed consistently in the target's own coordinates. Conjugation preserves
`det(R_t) = det(P)^2 * det(R_s) = det(R_s) = +1`.

**Quaternion closed form**: `q_t_wxyz = (-w, x, z, y)`, stored `[x, z, y, -w]`. Verified
independently against the matrix form across 20,000 random rotations
(`scipy.spatial.transform.Rotation`): max discrepancy 8.9e-16, against a 1e-9 bar.

**Sign note**: the derivation above yields `[x, z, y, -w]`. The service's actual output
emits the globally negated branch of that (every component flipped). Both represent the
identical rotation under quaternion double cover - `q` and `-q` are the same rotation, and
scipy's `Rotation.as_quat()` (used internally) picks its own canonical sign, which need
not match a hand-applied formula's literal sign. The sign is a free choice; stated here so
a reviewer diffing against a reference implementation does not read a global sign flip as
an error.

**Validation, and its limit**: unit tests (`test_transform.py`, 9/9 passing) confirm
matrix-vs-closed-form agreement (above), determinant/orthonormality preservation, position
and quaternion round-trip to identity, and known-axis mapping (East->East,
North(Y_s)->Z_t, Up(Z_s)->Y_t). Orientation accuracy against the dev self-check truth is
exact (0.000° at every reachable keyframe) - but that truth is stated in the *source*
frame, so it validates the source-side interpretation (quaternion order `[w,x,y,z]`,
meters, body-to-world) and the fusion result, not the target transform. **Target-frame
correctness rests on construction from the contract plus the unit tests above - nothing
available to us (dev or eval) can empirically validate it, since no ground truth exists in
target-frame units.** An earlier attempt to validate it by transforming both the
observation and the truth through the same `PoseTransformer` was discarded as circular: a
wrong transform applied identically to both sides would cancel out and still show zero
error.

## Fusion

**Why neither source alone passes the bands** (dev self-check: 3cm median / 8cm p95
position, 0.8° median / 2.5° p95 orientation): pose_source position drifts at ~8.7mm/s,
unbounded - median error 14.9cm, growing over the session, ~5x over band. RTK position is
unbiased but noisy - measured std 8.7cm RMS (3D), median error ~8.5cm, ~3x over band, and
bounded but not zero. RTK also has no orientation channel and runs at 5Hz, below the 24Hz
minimum on its own. Orientation, in contrast, needs no correction at all: pose_source's
quaternion matches self-check truth to exact floating-point equality at every reachable
keyframe - fusion there is direct pass-through plus gyro-bridging across dropouts, not a
filter.

**Position fusion**: `bias_hat`, a single-pole low-pass (EMA) on
`(pose_source_position - RTK_position)`, updated at each RTK tick against the
causally-matched (not interpolated) pose_source sample, subtracted from pose_source
position. Causal matching costs exactly 0.000cm in this dataset (RTK's 0.2s period is an
exact 24x multiple of pose_source's 1/120s period, so causal and interpolated matching
resolve to the identical sample) and bounds the lookahead to zero, relevant for the
latency budget below.

`tau_bias` chosen from an analytic lag/noise trade-off (`lag = drift_rate * tau`,
`noise ≈ rtk_std / sqrt(2 * rtk_rate * tau)`; minimized at tau≈1.71s, predicted ≈2.6cm),
confirmed by an empirical sweep against the self-check bands:

| tau (s) | position median (cm) | position p95 (cm) |
|---|---|---|
| 0.5 | 3.13 | 6.04 |
| 1.0 | 2.11 | 3.83 |
| **1.5 (chosen)** | **2.11** | **3.24** |
| 1.71 | 2.11 | 2.94 |
| 2.0 | 2.11 | 2.97 |
| 3.0 | 2.52 | 3.67 |
| 4.0 | 2.91 | 4.42 |

Flat optimum 1.0-2.0s; 1.5s chosen as a round value inside it. **A bug found during
review**: `bias_hat` was initially seeded from the first raw RTK residual - a single
noisy 5Hz sample - producing t=1000 error 12.91cm and p95 12.91cm (fails the 8cm band).
Fixed by initializing `bias_hat` to zero and letting the first EMA update apply normally
from the second RTK tick onward: t=1000 error 2.11cm, p95 3.24cm (passes). Self-check
result at the chosen config: **position median 2.11cm / p95 3.24cm** (band 3/8cm),
**orientation median 0.000° / p95 0.015°** (band 0.8°/2.5°) - both pass.

**Dropout position propagation**, validated at the one ground-truth point available inside
a dropout (t=1012.0, 1.008s into a 2.008s gap), bias-corrected (not raw) since that's what
the service actually outputs:

| Strategy | Error vs. truth |
|---|---|
| Hold last good position | 0.280m |
| Naive 1-sample finite-difference velocity coast | 1.263m |
| **Smoothed-velocity (0.1s window) coast + exponential decay (chosen)** | **0.162m** |
| Accelerometer double-integration (literal "propagate on IMU") | 0.928m |
| RTK (available, not used - see below) | 0.099m |

Accelerometer double-integration is worse than doing nothing (hold) - accel bias/noise
compounds quadratically over the gap. The chosen strategy anchors both position (decayed
velocity coast) and attitude (gyro integration) at the last accepted pose_source sample
and propagates forward with no separate tracking/dropout branch in the math itself -
resets happen every ~8ms while tracking, so the propagation horizon only grows large
during an actual dropout. `tau_decay=1.0s`, matching the observed dropout timescale (flat
0.151-0.155m between tau=1.0-2.0s at the one validation point).

**RTK during a dropout**: more accurate than the chosen strategy (0.099m vs. 0.162m) but
not implemented - the contract requires the last good pose held or decayed during a
dropout, not a fresh observation from a different source presented as current. See "What
I did not reach."

**Attitude bridging** (gyro integration only, no filter/gain): 1.14° error at dropout 1's
resume (2.008s gap), 0.61° at dropout 2's resume (1.008s gap) - both well inside the 2.5°
p95 band.

## Fault handling

**Rejects** (identical in dev and eval logs - same seq, same reasons):

| seq | reason |
|---|---|
| 200 | `duplicate_sequence` (exact repeat of the immediately preceding accepted seq) |
| 3240 | `capture_after_source` (`t_captured > t_source`, physically impossible; checked first, most specific) |
| 500 | `stale_sequence` (seq less than the most recently accepted seq) |

**The check order is load-bearing, not stylistic.** The seq=3240 record sits between two
legitimate ones in the raw stream: `..., seq=240, seq=3240, seq=241, ...`. If
`capture_after_source` weren't checked first - if the sequence checks ran before the
timestamp check, or the timestamp check didn't exist - seq=3240 would be accepted (its
sequence number alone looks fine: 3240 > 240). `last_accepted_seq` would then become 3240,
and the very next record, the legitimate seq=241, would satisfy `seq < last_accepted_seq`
and get flagged `stale_sequence` - a real observation wrongly rejected. Worse, it would
never recover: the dev log's real `seq` values top out at 3239 (Phase 0), so every
legitimate record for the rest of the 30s session would keep failing the same
`seq < 3240` test and get rejected as stale, all the way to the end. One bad record,
checked in the wrong order, would silently discard nearly the entire session's pose_source
data instead of just itself. Checking the most specific, physically-grounded rule first
prevents a single malformed record from corrupting the sequence state every later
accept/reject decision depends on.

**Output clock**: fixed 30Hz, decoupled from input arrival - pose_source stalls
completely for up to 2.008s during a dropout, so an input-driven loop would produce zero
output during that window, an outright >=24Hz violation, not just an accuracy hit.

**Both dropouts** (byte-identical boundaries in dev and eval): 1010.992s->1013.000s
(2.008s) and 1021.492s->1022.500s (1.008s).

- Dropout 1: `state` transitions tracking -> degraded (age > 0.1s) -> lost (age > 1.0s) ->
  tracking on resume; `confidence` reaches exactly 0.000 once lost.
- Dropout 2: `state` transitions tracking -> degraded -> tracking - it does **not** reach
  `lost`, even though the gap (1.008s) is *longer* than `lost_after_s` (1.0s). This is not
  because the gap is short relative to the threshold. It's 30Hz clock quantization: the
  last output tick before pose_source resumes at t=1022.5 lands at t=1022.466667, where
  `source_age_s = 0.987000s` - **13ms under** the 1.0s threshold, verified directly
  against the service's own output. No tick lands in the remaining 13ms window before
  recovery. **This is phase-dependent, not a property of the gap duration**: a 13ms
  margin against a 33.33ms tick period depends on where the dropout's boundaries happen to
  fall relative to the fixed output clock. A gap of the same or even shorter duration at a
  different clock phase could legitimately reach `lost`; a longer one could stay under.
  `lost_after_s` was not tuned to force either outcome - it's justified independently
  (matches `dropout_position.decay_tau_s`). The eval log's dropout 2 sits at the identical
  phase as the dev log's, so it reproduced the same result - a fixture coincidence, not
  evidence the margin is safe in general.

`source_age_s = t_now - t_captured` of the last accepted pose_source sample (using
`t_captured`, matching the contract's own definition, not `t_source`). Verified
monotonically non-decreasing through both gaps, both logs. `seq` is an independent
output-side counter (`self._out_seq`, starting at 0, incrementing every tick) - it never
reads pose_source's own `seq`, which is what keeps it strictly increasing through
dropouts when no input `seq` is advancing at all.

`confidence` combines two multiplicative factors: a dropout-depth ramp (1.0 while
tracking, linear to 0.0 between `degraded_after_s` and `lost_after_s`) and a one-time
startup warmup ramp (0->1 over 3.0s, ~2x `tau_bias`) addressing the bias-filter cold-start
finding directly - low confidence at session start even while pose_source itself is valid
and `state=tracking`, since `bias_hat` hasn't converged yet.

**Timecode**: the brief mentions a decoded timecode; contract v2 has no such field
(confirmed: no match for "timecode" anywhere in the contract). Not implemented -
inventing an undefined field would itself be a conformance violation.

## Rate and latency

**Rate**: exactly 30.000Hz achieved, overall and in 1s windows centered on each dropout,
both dev and eval logs - by construction, since the output clock is fixed and decoupled
from input arrival. `seq` strictly increasing, `t_source` strictly increasing (stronger
than the contract's "monotonic" requirement).

**Processing latency** (timed via `time.perf_counter` around each tick's event-draining +
output computation, inside the actual service loop - same code path for dev and eval):
dev p50 ≈0.9-1.3ms, p95 ≈1.8-2.9ms across repeated runs. Eval (submitted trace):
**p50=1166.6us, p95=3689.1us, max=93,665.7us**. The max is a non-reproducible single-tick
system-noise outlier - repeat runs (latency-only, output values are deterministic and
bit-identical across reruns) put it anywhere from 3.6ms to 31.1ms, at a different `seq`
each time, never tied to the dropout windows or any specific input record. **Kept as
observed in the submitted trace, not replaced with a better-looking rerun** - doing so
would be exactly the after-the-fact adjustment this build was told not to make.

**Total pose-age decomposition** (not just processing latency - the number a consumer of
this stream actually experiences):

| Contributor | Typical | Worst case |
|---|---|---|
| Capture-to-source delay (`t_source - t_captured`, measured) | 12.000ms | 12.000ms |
| Output clock quantization (up to one 33.3ms tick @ 30Hz) | ~16.667ms (half tick) | 33.333ms |
| Processing latency (measured, eval trace) | 1.167ms (p50) | 3.689ms (p95) / 93.666ms (max outlier) |
| **Total** | **~29.8ms** | **~49.0ms (p95) / ~139.0ms (incl. max outlier)** |

Capture-to-source delay is exactly 12.000ms with zero variance in both logs (median=p95)
- a fixed upstream constant, not something this service can reduce. Output clock
quantization is directly reducible by raising `output.rate_hz` (e.g. 60Hz would roughly
halve it) - **not changed here**: 30Hz already satisfies the 24Hz contract minimum, and
adjusting it after seeing the eval run would be exactly the kind of post-eval tuning this
phase was told not to do. It's recorded as an available lever for a future iteration.
Processing latency's sustained cost (p50/p95) is already small; its tail (the observed
outliers up to ~94ms, exceeding one tick period) is what a genuinely real-time deployment
would need to bound via a dedicated thread/process with a stricter OS scheduling class -
this offline batch-replay implementation makes no attempt to guarantee that bound.

## Reproduction

```bash
cd Workflow_Challenge   # this repository, after cloning
python3 -m venv .venv
source .venv/bin/activate
pip install numpy scipy pytest pyyaml

# unit tests
python -m pytest test_transform.py -v          # 9 passed

# fusion core against the dev log + self-check bands
python validate_fusion.py

# full service against the dev log + self-check bands
python validate_service.py

# eval run (unchanged service/config) - writes the submission artifacts
python run_eval.py
#   -> orion-eval-output.jsonl, orion-eval-rejected.jsonl, orion-eval-latency-trace.jsonl

# literal field-by-field contract conformance check
python check_eval_conformance.py

# independent quaternion-order verification (no import of transform.py/service.py/fusion.py)
python -c "
import json
from fusion import FusionConfig
from service import run_service
outputs = run_service(json.load(open('orion-dev-log.json'))['streams'], FusionConfig.load('fusion_config.yaml'))[0]
with open('orion-dev-output.jsonl', 'w') as f:
    for r in outputs: f.write(json.dumps(r) + '\n')
"
python verify_quat_order.py
```

The fusion/service pipeline is fully deterministic given `fusion_config.yaml` and the
input log - no randomness anywhere in `fusion.py`/`service.py` - so rerunning
`run_eval.py` reproduces `orion-eval-output.jsonl` and `orion-eval-rejected.jsonl`
byte-for-byte. Only `orion-eval-latency-trace.jsonl` will differ run to run (it's a
measurement of wall-clock system timing, not part of the algorithm); the p50/p95 figures
should reproduce within the ranges reported above, the single-tick max will vary.

## What I did not reach

- **RTK-anchored dropout position, consciously declined.** RTK is more accurate during a
  dropout than the implemented strategy (0.099m vs. 0.162m at the one validated point) but
  isn't used, because the contract requires the last good pose held or decayed during a
  dropout, not a fresh observation from a different source presented as current tracking.
  A more accurate service was available and not built, on conformance grounds.
- **Absent timecode field.** The brief mentions a decoded timecode; contract v2 defines no
  such field. Flagged, not invented.
- **The dropout-strategy comparison rests on one ground-truth point.** Hold vs. coast vs.
  accelerometer-integration, and the `tau_decay` choice, were validated at a single
  self-check keyframe (t=1012.0, 1.008s into dropout 1) - the only place truth exists
  inside a dropout in the dev log. The ranking (coast beats hold beats accel-integration)
  is directionally strong given the accel-integration result is 5x worse than the chosen
  strategy, but the specific `tau_decay` value is not tuned tighter than n=1 supports. More
  truth coverage inside dropout windows would be the highest-value addition to firm this
  up.
- **The dev self-check p95 is effectively max-of-9, not a robust percentile.** With only 9
  reachable keyframes, "p95" in the self-check comparisons is the largest of 9 points, not
  a statistically meaningful tail estimate. The bands were still met, but a larger truth
  set would give more confidence in the margin.
- **No accelerometer bias calibration attempted.** Dropout position propagation uses
  velocity coast, not accelerometer integration, specifically because a naive
  double-integration was measurably worse (see Fusion). A calibrated accel-bias estimate
  might change that conclusion, but building and validating one wasn't justified by the
  time available or the single-point evidence to tune it against.
- **No real-time scheduling hardening.** This is an offline batch-replay implementation;
  the observed processing-latency tail (up to ~94ms on one tick) is not bounded by any
  scheduling guarantee. A genuinely real-time deployment would need a dedicated
  thread/process and a stricter OS scheduling class to bound it below one tick period.
  Not attempted here.
- **`confidence`'s specific values are a reasoned heuristic, not calibrated.** The
  dropout-depth ramp and startup warmup behave sensibly (0 at full loss, 1 once
  converged and tracking) but there is no ground truth against which to check whether the
  intermediate values are well-calibrated probabilities of anything in particular.
- **Only one clock phase was tested for the dropout-2 margin.** The 13ms margin's
  phase-dependence is explained and flagged (Fault handling), but I did not sweep
  synthetic dropout boundaries across different clock phases to characterize how often a
  comparable gap would flip to `lost`. Worth doing with more time, since the eval log
  happening to share the dev log's exact dropout timing means this build has not actually
  observed the alternative outcome, only reasoned about it.
