"""Part 2: the qualification gate that should have run before
riverside-plaza-capture-07's solve was allowed into splat training.

Never trusts the artifact's own stored qualification.qualified flag -
recomputes every check from the underlying metrics. Run against the
delivered artifact, this correctly fails it (see PART2_REPORT.md for the
defect this catches and why).
"""

import json
import statistics
import sys

import yaml


def load(path):
    with open(path) as f:
        return json.load(f)


def check_metric_scale(solve, cfg):
    scale = solve["metric_scale"]
    reported_factor = scale["reported_scale_factor"]
    pairs = scale["rtk_baseline_check"]["measured_vs_reference_m"]

    findings = []
    errors_pct = []
    ratios = []
    for p in pairs:
        ref = p["reference_m"]
        recon = p["reconstructed_m"]
        corrected = recon * reported_factor
        error_pct = abs(corrected - ref) / ref * 100
        ratio = recon / ref
        errors_pct.append(error_pct)
        ratios.append(ratio)
        findings.append(
            f"  {p['pair']}: reference={ref}m reconstructed={recon}m "
            f"reported_scale_factor={reported_factor} -> corrected={corrected:.3f}m "
            f"error={error_pct:.2f}% (limit {cfg['max_baseline_error_pct']}%)"
        )

    max_error = max(errors_pct)
    scale_ok = max_error <= cfg["max_baseline_error_pct"]

    ratio_spread_pct = (max(ratios) - min(ratios)) / statistics.mean(ratios) * 100
    spread_ok = ratio_spread_pct <= cfg["max_ratio_relative_spread_pct"]

    implied_correction = statistics.mean(1 / r for r in ratios)
    findings.append(
        f"  per-pair ratio spread: {ratio_spread_pct:.3f}% (limit {cfg['max_ratio_relative_spread_pct']}%) "
        f"- tight spread means one consistent global scale error, not per-pair noise"
    )
    findings.append(
        f"  implied correction factor from the data itself: {implied_correction:.4f} "
        f"(vs. reported_scale_factor={reported_factor})"
    )

    return scale_ok and spread_ok, findings


def check_solve_quality(solve, cfg):
    findings = []
    ok = True

    retention = solve.get("registration_retention")
    if retention is not None:
        passed = retention >= cfg["min_registration_retention"]
        ok &= passed
        findings.append(f"  registration_retention={retention} (min {cfg['min_registration_retention']}) "
                         f"{'OK' if passed else 'FAIL'}")

    inlier = solve.get("inlier_ratio")
    if inlier is not None:
        passed = inlier >= cfg["min_inlier_ratio"]
        ok &= passed
        findings.append(f"  inlier_ratio={inlier} (min {cfg['min_inlier_ratio']}) {'OK' if passed else 'FAIL'}")

    reproj = solve.get("reprojection_error_px", {})
    median = reproj.get("median")
    if median is not None:
        passed = median <= cfg["max_reprojection_error_median_px"]
        ok &= passed
        findings.append(f"  reprojection_error_px.median={median} "
                         f"(max {cfg['max_reprojection_error_median_px']}) {'OK' if passed else 'FAIL'}")
    p95 = reproj.get("p95")
    if p95 is not None:
        passed = p95 <= cfg["max_reprojection_error_p95_px"]
        ok &= passed
        findings.append(f"  reprojection_error_px.p95={p95} "
                         f"(max {cfg['max_reprojection_error_p95_px']}) {'OK' if passed else 'FAIL'}")

    track_len = solve.get("mean_track_length")
    if track_len is not None:
        passed = track_len >= cfg["min_mean_track_length"]
        ok &= passed
        findings.append(f"  mean_track_length={track_len} "
                         f"(min {cfg['min_mean_track_length']}) {'OK' if passed else 'FAIL'}")

    return ok, findings


def check_provenance(solve, cfg):
    qual = solve.get("qualification", {})
    gate_version = qual.get("gate_version")
    reviewed_by = qual.get("reviewed_by")
    named = bool(gate_version) and gate_version != "none"
    findings = [
        f"  stored qualification: qualified={qual.get('qualified')} "
        f"gate_version={gate_version!r} reviewed_by={reviewed_by!r}",
        f"  named, versioned gate required: {cfg['require_named_gate_version']} -> "
        f"{'a real gate_version is present' if named else 'NO real gate_version - stored qualified flag is not trusted'}",
    ]
    ok = named if cfg["require_named_gate_version"] else True
    return ok, findings


def run_gate(artifact_path, config_path):
    artifact = load(artifact_path)
    with open(config_path) as f:
        cfg = yaml.safe_load(f)
    solve = artifact["sfm_solve"]

    sections = [
        ("Metric scale", check_metric_scale(solve, cfg["metric_scale"])),
        ("Solve quality", check_solve_quality(solve, cfg["solve_quality"])),
        ("Provenance of prior qualification", check_provenance(solve, cfg["provenance"])),
    ]

    overall_ok = True
    print(f"Qualification gate v{cfg['version']} - {artifact['capture']['name']}\n")
    for name, (ok, findings) in sections:
        overall_ok &= ok
        print(f"[{'PASS' if ok else 'FAIL'}] {name}")
        for line in findings:
            print(line)
        print()

    print(f"=== GATE VERDICT: {'QUALIFIED' if overall_ok else 'NOT QUALIFIED - block splat training'} ===")
    print(f"(artifact's own stored value was qualified={solve['qualification']['qualified']} - "
          f"{'agrees' if overall_ok == solve['qualification']['qualified'] else 'DISAGREES: the stored flag was wrong'})")
    return overall_ok


if __name__ == "__main__":
    ok = run_gate("orion-reconstruction-artifact.json", "part2_qualification_gate.yaml")
    sys.exit(0 if ok else 1)
