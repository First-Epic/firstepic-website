"""Phase 2 validation: run the fusion core over orion-dev-log.json and score
against orion-dev-selfcheck.json's bands. Dev-log only - never run against
the eval log for tuning.

The accept/reject filter here is provisional (seq <= last_accepted, or
t_captured > t_source) - a minimal stand-in reproducing exactly the 3 known
anomalies from Phase 0, so fusion accuracy is validated on the same clean
signal the real service will see. Full reject-with-reason logging is Phase 3.
"""

import json

import numpy as np

from fusion import FusionConfig, BiasEstimator, VelocityEstimator, AttitudePropagator, coast_position
from transform import PoseTransformer


def load_dev_data():
    with open("orion-dev-log.json") as f:
        d = json.load(f)
    with open("orion-dev-selfcheck.json") as f:
        sc = json.load(f)
    return d["streams"], sc


def filter_valid_pose_source(records):
    last_seq = -1
    valid = []
    for r in records:
        if r["seq"] <= last_seq or r["t_captured"] > r["t_source"]:
            continue
        last_seq = r["seq"]
        valid.append(r)
    return valid


def median(xs):
    xs = sorted(xs)
    n = len(xs)
    return xs[n // 2] if n % 2 == 1 else (xs[n // 2 - 1] + xs[n // 2]) / 2


def p95(xs):
    xs = sorted(xs)
    return xs[int(round(0.95 * (len(xs) - 1)))]


def main():
    streams, sc = load_dev_data()
    cfg = FusionConfig.load("fusion_config.yaml")

    ps = filter_valid_pose_source(streams["pose_source"])
    rtk = streams["rtk"]
    imu = streams["imu"]
    keyframes = sc["keyframes"]
    bands = sc["bands"]

    ps_t = np.array([r["t_source"] for r in ps])
    ps_pos = np.array([r["pos_m"] for r in ps])
    ps_quat = np.array([r["quat_wxyz"] for r in ps])

    def causal_pose_source(t):
        idx = np.searchsorted(ps_t, t, side="right") - 1
        if idx < 0 or t - ps_t[idx] > cfg.causal_tolerance_s:
            return None
        return idx

    # --- run bias estimator over the whole session, driven by RTK ticks ---
    bias_est = BiasEstimator(cfg.bias_tau_s)
    bias_trace = []  # (t, bias_hat) at each RTK tick where pose_source was available
    for r in rtk:
        idx = causal_pose_source(r["t"])
        if idx is None:
            continue  # dropout: bias_hat frozen, no update
        bias_est.update(r["t"], ps_pos[idx], r["enu_m"])
        bias_trace.append((r["t"], bias_est.bias_hat.copy()))

    def bias_at(t):
        b = bias_trace[0][1]
        for t_b, bb in bias_trace:
            if t_b <= t:
                b = bb
            else:
                break
        return b

    # --- fused position/orientation at every reachable self-check keyframe (tracking state) ---
    pos_errs_cm, ori_errs_deg = [], []
    for kf in keyframes:
        idx = causal_pose_source(kf["t"])
        if idx is None:
            continue  # inside a dropout - handled separately below
        t_ps = ps_t[idx]
        b = bias_at(t_ps)
        p_fused = ps_pos[idx] - b
        pos_err = np.linalg.norm(p_fused - np.array(kf["pos_m"]))
        pos_errs_cm.append(pos_err * 100)

        q_fused = ps_quat[idx]  # direct pass-through
        dot = min(1.0, abs(np.dot(q_fused, kf["quat_wxyz"])))
        ori_err_deg = np.degrees(2 * np.arccos(dot))
        ori_errs_deg.append(ori_err_deg)

    print("=== Fused position/orientation vs self-check keyframes (tracking state) ===")
    print(f"n = {len(pos_errs_cm)}")
    print(f"position median = {median(pos_errs_cm):.3f} cm (band: {bands['position_median_m']*100:.0f} cm)")
    print(f"position p95    = {p95(pos_errs_cm):.3f} cm (band: {bands['position_p95_m']*100:.0f} cm)")
    print(f"orientation median = {median(ori_errs_deg):.6f} deg (band: {bands['orientation_median_deg']} deg)")
    print(f"orientation p95    = {p95(ori_errs_deg):.6f} deg (band: {bands['orientation_p95_deg']} deg)")
    print("(n=9: p95 here is effectively the max of 9 points, not a statistically robust p95 - see NOTES.md)")

    # --- dropout position propagation, validated at the one truth point available inside a dropout ---
    print("\n=== Dropout position propagation (t=1012.0, 1.008s into dropout 1) ===")
    kf_1012 = next(k for k in keyframes if k["t"] == 1012.0)
    p_truth = np.array(kf_1012["pos_m"])

    t_last = 1010.991667
    idx_last = int(np.searchsorted(ps_t, t_last, side="right") - 1)
    assert abs(ps_t[idx_last] - t_last) < 1e-6
    b_boundary = bias_at(t_last)
    p_last_corrected = ps_pos[idx_last] - b_boundary

    vel_est = VelocityEstimator(cfg.velocity_window_s)
    window_start_idx = idx_last
    while window_start_idx > 0 and t_last - ps_t[window_start_idx] < cfg.velocity_window_s:
        window_start_idx -= 1
    for i in range(window_start_idx, idx_last + 1):
        vel_est.push(ps_t[i], ps_pos[i] - b_boundary)
    v_smooth = vel_est.estimate()

    dt_gap = 1012.0 - t_last
    p_coast = coast_position(p_last_corrected, v_smooth, dt_gap, cfg.decay_tau_s)
    err_hold = np.linalg.norm(p_last_corrected - p_truth)
    err_coast = np.linalg.norm(p_coast - p_truth)
    rtk_at_1012 = min(rtk, key=lambda r: abs(r["t"] - 1012.0))
    err_rtk = np.linalg.norm(np.array(rtk_at_1012["enu_m"]) - p_truth)

    print(f"bias_hat at dropout boundary: {b_boundary}, |bias_hat| = {np.linalg.norm(b_boundary)*100:.2f} cm")
    print(f"hold error   = {err_hold:.4f} m")
    print(f"coast error  = {err_coast:.4f} m  (decay_tau_s={cfg.decay_tau_s}, window_s={cfg.velocity_window_s})")
    print(f"RTK error    = {err_rtk:.4f} m  (considered + rejected alternative - see NOTES.md)")

    # --- attitude bridging across both dropouts, via gyro integration ---
    print("\n=== Attitude bridging across both dropouts (gyro integration) ===")
    dropouts = [(1010.991667, 1013.0), (1021.491667, 1022.5)]
    for t_start, t_end in dropouts:
        idx_start = int(np.searchsorted(ps_t, t_start, side="right") - 1)
        att = AttitudePropagator()
        att.set_from_pose_source(ps_quat[idx_start])
        gyro_samples = [s for s in imu if t_start < s["t"] <= t_end]
        t_prev = t_start
        for s in gyro_samples:
            dt = s["t"] - t_prev
            att.integrate_gyro(s["gyro_rad_s"], dt)
            t_prev = s["t"]
        idx_resume = int(np.searchsorted(ps_t, t_end, side="left"))
        q_true_at_resume = ps_quat[idx_resume]
        q_propagated = att.as_quat_wxyz()
        dot = min(1.0, abs(np.dot(q_propagated, q_true_at_resume)))
        err_deg = np.degrees(2 * np.arccos(dot))
        print(f"dropout {t_start:.3f}->{t_end:.3f} ({t_end-t_start:.3f}s, {len(gyro_samples)} gyro samples): "
              f"gyro-propagated attitude vs pose_source at resume, error = {err_deg:.4f} deg")

    # --- origin for PoseTransformer: fused position at t=0, not raw pose_source ---
    t0 = ps_t[0]
    b0 = bias_at(t0)
    fused_origin_m = ps_pos[0] - b0
    print(f"\nfused t=0 position (for PoseTransformer origin): {fused_origin_m}")
    xf = PoseTransformer(fused_origin_m)
    print(f"origin in target frame (should be [0,0,0]): {xf.transform_position(fused_origin_m)}")


if __name__ == "__main__":
    main()
