# ORION pose-stream service

Fuses a biased/drifting 120 Hz visual pose source, a noisy 5 Hz RTK position fix, and a
200 Hz IMU into a single ≥24 Hz pose stream conforming to `orion-pose-contract-v2.json`.

## Status

Complete. Built phase by phase against `orion-dev-log.json` / `orion-dev-selfcheck.json`
(coordinate transform, fusion core, fault handling and contract conformance,
instrumentation), then run once, unchanged, on `orion-eval-log.json`. `NOTES.md` is the
design log (approaches tried and discarded, with reasons); `REPORT.md` is the submission
report - transform derivation, fusion design and results, fault handling, rate/latency,
exact reproduction steps, and what wasn't reached. `PART2_REPORT.md` covers the separate
reconstruction-artifact review and qualification gate.

The commands below cover the full pipeline: unit tests, dev-log validation, the eval run,
and both conformance checks.

## Setup

Requires Python 3.10+.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install numpy scipy pytest pyyaml
```

## Running the tests

```bash
source .venv/bin/activate
python -m pytest test_transform.py -v
```

Expect `9 passed`. These tests independently verify the coordinate transform derivation
(matrix conjugation vs. closed-form quaternion agree to 1e-9 across 2000 random
rotations), orthonormality/determinant preservation, round-trip identity, and known-axis
mapping.

## Validating fusion accuracy against the dev log

```bash
source .venv/bin/activate
python validate_fusion.py
```

Runs `fusion.py`'s `BiasEstimator`/`VelocityEstimator`/`AttitudePropagator` over
`orion-dev-log.json` and scores the result against `orion-dev-selfcheck.json`'s bands.
Expect position median ≈2.1cm (band 3cm), p95 ≈3.2cm (band 8cm), orientation median/p95
≈0.00°/0.01° (band 0.8°/2.5°), plus a breakdown of the dropout-position propagation and
gyro-bridged-attitude accuracy at both dropouts. All tunables (`tau_s`, `window_s`,
`decay_tau_s`, `causal_tolerance_s`) live in `fusion_config.yaml`; see `NOTES.md` for how
each was chosen.

## Validating the full service against the dev log

```bash
source .venv/bin/activate
python validate_service.py
```

Runs `service.py`'s `PoseStreamService` (reject/accept, fixed-rate output clock, fault
handling) over `orion-dev-log.json` end-to-end and reports: the reject log (expect 3
rejections matching Phase 0's known anomalies), output-stream conformance (≥24Hz, strictly
increasing `seq`/`t_source`, exact `output_stream_fields`), `state`/`source_age_s`
behavior across both dropouts, and position/orientation accuracy against the self-check
bands - both including and excluding the one keyframe that lands inside a dropout (see
`NOTES.md` Phase 3 for why that split matters). Expect: 900 records at ~30Hz, both bands
passing when restricted to `state=='tracking'` (position median ≈2.16cm/p95 ≈3.31cm,
orientation ≈0.00°/0.00°, against a 3cm/8cm/0.8°/2.5° band).

## Running the eval log

```bash
source .venv/bin/activate
python run_eval.py
```

Runs the same, unchanged `service.py`/`fusion_config.yaml` against
`orion-eval-log.json` (raw, no truth - never used for tuning) and writes:

- `orion-eval-output.jsonl` — one JSON object per line, `output_stream_fields`
- `orion-eval-rejected.jsonl` — one JSON object per line, `{seq, reason}`
- `orion-eval-latency-trace.jsonl` — one JSON object per line, `{seq, t_source, latency_s}`

See `REPORT.md`'s Phase 4 section for the resulting numbers and observations (the eval
log's reject log and state distribution turned out identical to the dev log's — both
fixtures share the same fault-injection pattern).

## Checking eval output conformance

```bash
source .venv/bin/activate
python check_eval_conformance.py
```

Checks `orion-eval-output.jsonl` against `output_stream_fields` as read directly from
`orion-pose-contract-v2.json` (not hardcoded) — field names, `seq`/`t_source`
monotonicity, `confidence` range, `state` enum, and element counts. Reports pass/fail per
check. Expect all 9 checks to pass. `quat_target`'s `[x,y,z,w]` storage order is
deliberately *not* checked here (a version that did was circular — see below); it's
verified independently instead.

## Verifying quaternion storage order independently

```bash
source .venv/bin/activate
python -c "
import json
from fusion import FusionConfig
from service import run_service
outputs = run_service(json.load(open('orion-dev-log.json'))['streams'], FusionConfig.load('fusion_config.yaml'))[0]
with open('orion-dev-output.jsonl', 'w') as f:
    for r in outputs: f.write(json.dumps(r) + '\n')
"
python verify_quat_order.py
```

(The first command regenerates `orion-dev-output.jsonl`, the fixture `verify_quat_order.py`
checks against — it's a plain run of the already-validated Phase 3 service, not part of
the independent verification itself.) `verify_quat_order.py` then reads only
`orion-eval-output.jsonl`, `orion-dev-log.json`, `orion-dev-output.jsonl`, and the
contract — no import of `transform.py`, `service.py`, or `fusion.py` — and runs three
checks with plain Python arithmetic: magnitude structure (index 3 should be the
near-unity component on every record, given the gentle camera move), a hand-computed spot
check against the closed-form derivation at 3 dev-log timestamps, and a unit-norm check.
Expect all 3 to pass. See `NOTES.md`/`REPORT.md` for why the two earlier, code-importing
versions of this check were rejected as circular.

## Repository layout

- `transform.py` — source ENU (m, `[w,x,y,z]`, body->world) to target frame (cm, left-
  handed, `[x,y,z,w]`) coordinate transform, per `orion-pose-contract-v2.json`.
- `test_transform.py` — unit tests for the transform.
- `fusion.py` — bias estimation, velocity smoothing, dropout position coasting, and
  gyro-bridged attitude propagation.
- `fusion_config.yaml` — versioned fusion + service tunables.
- `validate_fusion.py` — runs the fusion core (position/orientation only) against the dev
  log and self-check bands.
- `service.py` — the full streaming service: reject/accept with reasons, fixed-rate
  output clock, `state`/`confidence`/`source_age_s`, contract-conforming output records.
- `validate_service.py` — runs the full service against the dev log and self-check bands.
- `run_eval.py` — runs the unchanged service against the eval log, writes submission
  artifacts.
- `check_eval_conformance.py` — checks the eval output literally against the contract's
  `output_stream_fields` (excluding quaternion order — see below).
- `verify_quat_order.py` — standalone, independent verification of `quat_target`'s
  `[x,y,z,w]` storage order (no import of `transform.py`/`service.py`/`fusion.py`).
- `orion-dev-output.jsonl` — dev-log output, generated so `verify_quat_order.py` has a
  fixture to hand-check against.
- `NOTES.md` — approaches tried and discarded, with reasons; updated per phase.
- `REPORT.md` — the submission report.
- `orion-pose-contract-v2.json`, `orion-dev-log.json`, `orion-dev-selfcheck.json`,
  `orion-eval-log.json` — inputs, provided.
- `orion-eval-output.jsonl`, `orion-eval-rejected.jsonl`, `orion-eval-latency-trace.jsonl`
  — eval run outputs (Phase 4).
- `PART2_REPORT.md`, `part2_qualification_gate.py`, `part2_qualification_gate.yaml` —
  separate task: reconstruction artifact defect review and qualification gate, run against
  `orion-reconstruction-artifact.json`.
