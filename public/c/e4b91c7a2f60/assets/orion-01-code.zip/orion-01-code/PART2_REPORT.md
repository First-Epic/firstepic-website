# Part 2 — reconstruction artifact review

`orion-reconstruction-artifact.json`: a structure-from-motion solve (pycolmap) plus the
Gaussian-splat training config that consumed it, for capture `riverside-plaza-capture-07`.
Reviewed as delivered - no solver run, human-readable analysis only, per the task.

## (a) The defect

**The delivered scene is uniformly ~14.3% undersized.** `metric_scale.reported_scale_factor`
is `1.000`, but the RTK baseline check sitting three lines below it in the same JSON object
shows the reconstruction consistently falls short of the surveyed reference distances:

| pair | reference (m) | reconstructed (m) | ratio |
|---|---|---|---|
| b1 | 12.40 | 10.63 | 0.8573 |
| b2 | 8.10 | 6.94 | 0.8568 |
| b3 | 20.05 | 17.19 | 0.8574 |

All three ratios cluster at 0.857 with a relative spread of 0.07% - this is not per-baseline
survey noise (which would scatter the three pairs differently); it is one consistent global
scale error. Applying the reported scale factor of 1.000 does nothing to correct it, so
every distance in the delivered scene - the neutral master and both creative derivatives -
is wrong by the same ~14.3%. Anything downstream that assumes metric scale (measurement
overlays, physics, placement against other real-world-scaled assets, the RTK reference
itself) will be wrong in a way that isn't visually obvious - the geometry is internally
consistent, just uniformly the wrong size. That's what makes it dangerous: nothing in the
render looks broken.

The data also shows *what the correct value should have been*: `mean(reference/reconstructed)
= 1.1667` across the three pairs - i.e. `reported_scale_factor` should have been ~1.167, not
1.000. The fact that this number is sitting right there, unused, next to a hardcoded-looking
`1.000`, points at a scale-estimation step that either failed silently and defaulted to
identity, or was computed and never wired back into `reported_scale_factor` before the
qualification record was written.

Secondary, supporting evidence that this solve should never have been called "qualified":
`registration_retention=0.752` (only 611/812 images registered), `inlier_ratio=0.61`,
`mean_track_length=3.1` (short tracks, weak triangulation), and
`reprojection_error_px={median: 2.94, p95: 11.7, max: 41.2}` (well outside normal SfM
tolerances). None of this caused the scale error, but it's consistent with a solve that was
never actually scrutinized - which is exactly what `"qualification": {"qualified": true,
"gate_version": "none", "reviewed_by": "auto"}` says outright: nothing versioned evaluated
this before it was marked qualified.

## Verification (no solver required)

1. **Recompute the ratio for each baseline pair** (`reconstructed / reference`) directly
   from the artifact's own `rtk_baseline_check` data - three arithmetic divisions, no
   external tooling. Confirms both the ~14% error and its consistency across pairs (a tight
   cluster means a fixable global scale bug, not a bad individual correspondence or a
   mis-surveyed point - those would show up as one outlier pair, not all three agreeing).
2. **Cross-check `reported_scale_factor` against the data**: does
   `reconstructed_m * reported_scale_factor ≈ reference_m`? Here it doesn't, by ~14%, for
   every pair. This is the single highest-value check - it's cheap, requires no domain
   judgment about acceptable reprojection error, and catches this exact defect regardless of
   *why* the scale is wrong.
3. **Field verification, if available**: measure the distance between two known survey
   markers directly in the delivered splat/mesh and compare to the RTK survey record - an
   independent check outside the pipeline's own reported numbers, for cases where the
   pipeline's self-reported baseline check itself might be the thing that's wrong.

## (b) The qualification gate

`part2_qualification_gate.py` / `part2_qualification_gate.yaml` - a versioned, config-driven
gate (thresholds explained in the config, nothing hardcoded) with three sections, run against
the artifact:

```
Qualification gate v1 - riverside-plaza-capture-07

[FAIL] Metric scale
  b1: error=14.27% (limit 2.0%)   b2: error=14.32% (limit 2.0%)   b3: error=14.26% (limit 2.0%)
  per-pair ratio spread: 0.066% (limit 1.0%) - one consistent global scale error, not noise
  implied correction factor from the data itself: 1.1667 (vs. reported_scale_factor=1.0)

[FAIL] Solve quality
  registration_retention=0.752 (min 0.85) FAIL
  inlier_ratio=0.61 (min 0.7) FAIL
  reprojection_error_px.median=2.94 (max 1.5) FAIL
  reprojection_error_px.p95=11.7 (max 5.0) FAIL
  mean_track_length=3.1 (min 4.0) FAIL

[FAIL] Provenance of prior qualification
  stored qualification: qualified=True gate_version='none' reviewed_by='auto'
  NO real gate_version - stored qualified flag is not trusted

=== GATE VERDICT: NOT QUALIFIED - block splat training ===
(artifact's own stored value was qualified=True - DISAGREES: the stored flag was wrong)
```

**Design choices, briefly:**
- The scale check verifies `reconstructed * reported_scale_factor ≈ reference` per pair
  (catches a wrong factor, however it went wrong), not just "is reported_scale_factor near
  1.0" (which would miss a genuinely-needed non-1.0 scale that was simply never applied
  correctly elsewhere).
- The ratio-spread check is separate from the error-magnitude check on purpose: a solve
  that fails on magnitude but passes on spread (like this one) has a single fixable global
  bug; a solve that fails on spread has a structural problem (bad correspondences, a
  mis-surveyed baseline) that recalibrating a single scale factor won't fix. Different
  failure, different fix - worth distinguishing even though both block the gate.
- **The gate never trusts a stored `qualified` flag - it always recomputes from the
  underlying metrics.** `gate_version: "none"` is treated as an automatic fail (fail closed,
  not open), independent of what `qualified` says. This directly targets the structural
  failure visible in the artifact: a boolean got set to `true` with no named, versioned,
  auditable check behind it, and `splat_training.input_gate` (`"solve.qualification.qualified
  == true"`) trusted that boolean instead of re-verifying anything itself.
- Solve-quality thresholds (retention/inlier/reprojection/track-length) are illustrative,
  domain-configurable values in `part2_qualification_gate.yaml`, not derived from this
  dataset - they'd need tuning against whatever quality bar the actual delivery use case
  requires. The scale check's tolerance (2%) is set relative to typical RTK survey precision
  on baselines of this length, not backed out from the defect itself.

Run: `python part2_qualification_gate.py` (exit code 1 on failure, CI-usable).
