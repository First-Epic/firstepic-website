"""Phase 3: streaming pose service - reject/accept, fixed-rate output clock,
fault handling, and contract-conforming output records.

Output cannot be driven by pose_source arrivals: pose_source stalls
completely during a dropout, and the contract requires >=24Hz continuously.
So this runs a fixed-rate output clock (config: output.rate_hz), decoupled
from input arrival, and merges pose_source/imu/rtk events in time order to
keep internal state current as of each output tick.

Attitude and position propagation share one mechanism: both are anchored at
the last accepted pose_source sample ("reset point") and are propagated
forward from there - gyro integration for attitude, decayed-velocity coast
for position (fusion.py). There is no separate branch for "tracking" vs
"dropout" in the propagation math; a reset happens naturally every time a
new pose_source sample is accepted (about every 8ms while tracking), so the
propagation horizon is tiny during normal operation and only grows large
during an actual dropout. state/confidence are what actually change meaning
as that horizon grows - the position/attitude math is uniform.
"""

from dataclasses import dataclass, field

import numpy as np

from fusion import BiasEstimator, VelocityEstimator, AttitudePropagator, coast_position
from transform import PoseTransformer

STATE_TRACKING = "tracking"
STATE_DEGRADED = "degraded"
STATE_LOST = "lost"

REJECT_CAPTURE_AFTER_SOURCE = "capture_after_source"
REJECT_DUPLICATE_SEQUENCE = "duplicate_sequence"
REJECT_STALE_SEQUENCE = "stale_sequence"


def validate_pose_source(records):
    """Split raw pose_source records into (accepted, rejected). Order of
    checks matters: a physically-impossible timestamp is checked first
    (most specific), then duplicate vs. stale sequence numbers.
    rejected entries are {"seq": ..., "reason": ...}.
    """
    accepted, rejected = [], []
    last_seq = -1
    for r in records:
        if r["t_captured"] > r["t_source"]:
            rejected.append({"seq": r["seq"], "reason": REJECT_CAPTURE_AFTER_SOURCE})
            continue
        if r["seq"] == last_seq:
            rejected.append({"seq": r["seq"], "reason": REJECT_DUPLICATE_SEQUENCE})
            continue
        if r["seq"] < last_seq:
            rejected.append({"seq": r["seq"], "reason": REJECT_STALE_SEQUENCE})
            continue
        last_seq = r["seq"]
        accepted.append(r)
    return accepted, rejected


@dataclass
class _ResetPoint:
    t_source: float
    t_captured: float
    pos_corrected: np.ndarray
    confidence: float


class PoseStreamService:
    def __init__(self, cfg):
        self.cfg = cfg
        self.bias_est = BiasEstimator(cfg.bias_tau_s)
        self.vel_est = VelocityEstimator(cfg.velocity_window_s)
        self.attitude = AttitudePropagator()
        self.transformer: PoseTransformer | None = None

        self._reset: _ResetPoint | None = None
        self._gyro_cursor_t: float | None = None
        self._session_start_t: float | None = None
        self._out_seq = 0

    def _on_pose_source(self, r):
        pos_corrected = np.asarray(r["pos_m"], dtype=float) - self.bias_est.bias_hat
        self.vel_est.push(r["t_source"], pos_corrected)
        self._reset = _ResetPoint(
            t_source=r["t_source"],
            t_captured=r["t_captured"],
            pos_corrected=pos_corrected,
            confidence=r["confidence"],
        )
        self.attitude.set_from_pose_source(r["quat_wxyz"])
        self._gyro_cursor_t = r["t_source"]

        if self.transformer is None:
            self._session_start_t = r["t_source"]
            self.transformer = PoseTransformer(pos_corrected)

    def _on_rtk(self, r):
        if self._reset is None:
            return
        if r["t"] - self._reset.t_source > self.cfg.causal_tolerance_s:
            return  # no current pose_source sample to match against - dropout, bias_hat frozen
        raw_pos_at_reset = self._reset.pos_corrected + self.bias_est.bias_hat  # undo correction to get raw
        self.bias_est.update(r["t"], raw_pos_at_reset, r["enu_m"])

    def _on_imu(self, r):
        if self._gyro_cursor_t is None:
            return
        dt = r["t"] - self._gyro_cursor_t
        if dt <= 0:
            return
        self.attitude.integrate_gyro(r["gyro_rad_s"], dt)
        self._gyro_cursor_t = r["t"]

    def _advance_gyro_to(self, t, latest_gyro):
        if self._gyro_cursor_t is None or latest_gyro is None:
            return
        dt = t - self._gyro_cursor_t
        if dt > 0:
            self.attitude.integrate_gyro(latest_gyro, dt)
            self._gyro_cursor_t = t

    def _confidence_at(self, t, age):
        if self._reset is None:
            return 0.0
        base = self._reset.confidence
        if age > self.cfg.degraded_after_s:
            span = self.cfg.lost_after_s - self.cfg.degraded_after_s
            dropout_factor = max(0.0, 1.0 - (age - self.cfg.degraded_after_s) / span)
        else:
            dropout_factor = 1.0
        warmup_elapsed = t - self._session_start_t if self._session_start_t is not None else 0.0
        warmup_factor = min(1.0, max(0.0, warmup_elapsed / self.cfg.startup_warmup_s))
        return max(0.0, min(1.0, base * dropout_factor * warmup_factor))

    def _state_at(self, age):
        if age <= self.cfg.degraded_after_s:
            return STATE_TRACKING
        if age <= self.cfg.lost_after_s:
            return STATE_DEGRADED
        return STATE_LOST

    def output_at(self, t, latest_gyro=None):
        """Compute one contract-conforming output record for time t. Caller
        must have already fed all pose_source/rtk/imu events with
        timestamp <= t via on_event() first."""
        self._advance_gyro_to(t, latest_gyro)

        if self._reset is None:
            pos_source_frame = np.zeros(3)
            quat_wxyz = np.array([1.0, 0.0, 0.0, 0.0])
            age = 0.0
            state = STATE_LOST
            confidence = 0.0
        else:
            age = t - self._reset.t_source
            v = self.vel_est.estimate()
            pos_source_frame = coast_position(self._reset.pos_corrected, v, max(age, 0.0), self.cfg.decay_tau_s)
            quat_wxyz = self.attitude.as_quat_wxyz()
            state = self._state_at(age)
            confidence = self._confidence_at(t, age)

        if self.transformer is not None:
            pos_target = self.transformer.transform_position(pos_source_frame)
            quat_target = self.transformer.transform_quaternion(quat_wxyz)
        else:
            pos_target = pos_source_frame
            quat_target = np.array([0.0, 0.0, 0.0, 1.0])

        source_age_s = (t - self._reset.t_captured) if self._reset is not None else 0.0

        record = {
            "seq": self._out_seq,
            "t_source": t,
            "pos_target": [float(x) for x in pos_target],
            "quat_target": [float(x) for x in quat_target],
            "confidence": float(confidence),
            "source_age_s": float(source_age_s),
            "state": state,
        }
        self._out_seq += 1
        return record


def run_service(streams, cfg):
    """Run the full service over a loaded dev/eval log's streams dict.
    Returns (outputs, rejected, accepted_pose_source_count, svc, latency_trace).

    Per-tick processing latency (event draining + output_at) is timed on
    every call, dev or eval alike - the same code path runs either way, so
    timing it doesn't change any output value, only adds a measurement
    alongside it.
    """
    import time

    accepted_ps, rejected = validate_pose_source(streams["pose_source"])
    rtk = streams["rtk"]
    imu = streams["imu"]

    PRIORITY = {"ps": 0, "rtk": 1, "imu": 2}
    events = []
    events.extend((r["t_source"], "ps", r) for r in accepted_ps)
    events.extend((r["t"], "rtk", r) for r in rtk)
    events.extend((r["t"], "imu", r) for r in imu)
    events.sort(key=lambda e: (e[0], PRIORITY[e[1]]))

    svc = PoseStreamService(cfg)

    t_start = events[0][0] if events else 0.0
    t_end = max(e[0] for e in events) if events else 0.0
    n_ticks = int((t_end - t_start) * cfg.output_rate_hz) + 1

    evt_i = 0
    latest_gyro = None
    outputs = []
    latency_trace = []
    for k in range(n_ticks):
        t = t_start + k / cfg.output_rate_hz
        tick_start = time.perf_counter()
        while evt_i < len(events) and events[evt_i][0] <= t:
            _, kind, r = events[evt_i]
            if kind == "ps":
                svc._on_pose_source(r)
            elif kind == "rtk":
                svc._on_rtk(r)
            elif kind == "imu":
                svc._on_imu(r)
                latest_gyro = r["gyro_rad_s"]
            evt_i += 1
        record = svc.output_at(t, latest_gyro)
        latency_s = time.perf_counter() - tick_start
        outputs.append(record)
        latency_trace.append({"seq": record["seq"], "t_source": record["t_source"], "latency_s": latency_s})

    return outputs, rejected, len(accepted_ps), svc, latency_trace
