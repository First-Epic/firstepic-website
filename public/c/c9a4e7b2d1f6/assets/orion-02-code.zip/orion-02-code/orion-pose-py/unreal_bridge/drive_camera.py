"""
BONUS (optional, not required to pass): drives a CineCameraActor in the
current Unreal level from the Part 1 pose stream, and logs a render-space
readback every so often so you can see Unreal's own actor transform after
each set -- proving the round trip actually landed the camera where the
pose stream intended, not just that a value was assigned.

HONESTY NOTE: I (the AI assistant) wrote this against Unreal's documented
Python API but have no Unreal Editor available to run it against. The
coordinate math (orion/unreal_frame.py) IS tested and verified -- see
tests/test_unreal_frame.py, all passing, including a check that this
script's simplified quaternion shortcut (cycle x,y,z, keep w) is
numerically identical to the full change-of-basis derivation. The Unreal
API CALLS below (unreal.CineCameraActor, register_slate_post_tick_callback,
etc.) are standard/documented for UE5, but untested end-to-end. Treat this
as a strong first draft -- see "Troubleshooting" at the bottom.

HOW TO RUN (Unreal 5.8):
1. Edit > Plugins -> enable "Python Editor Script Plugin" if not already on
   (requires an editor restart the first time).
2. Open any level (an empty default level is fine).
3. Window > Output Log -- this is where readback lines print.
4. Window > Developer Tools > Python (or use Output Log's own command bar
   with a "py " prefix) to get a Python input.
5. Run:
       exec(open(r"D:/ML/FirstEpicChallenge/orion-pose-py/unreal_bridge/drive_camera.py").read())
6. Make sure the viewport is in "Realtime" mode (clock icon, top-left of
   the viewport toolbar) so you actually see the camera move.
7. It stops automatically at the end of the stream, or call stop_driving()
   in the Python console to stop early / re-run start_driving() again.
"""

import json

import unreal

# ---- config ---------------------------------------------------------------
JSONL_PATH = r"D:/ML/FirstEpicChallenge/orion-pose-py/deliverables/orion-eval-output.jsonl"
PLAYBACK_SPEED = 1.0  # 1.0 = real time, matched to the stream's own t_source deltas
PRINT_EVERY_N_RECORDS = 24  # readback log cadence (~every 0.5s at the stream's 48Hz)

# ---- target-frame (contract) -> Unreal-frame axis remap -------------------
# Target: x=East, y=Up, z=North (left-handed, cm, quat xyzw).
# Unreal:  X=Forward, Y=Right, Z=Up (left-handed, cm, FQuat xyzw).
# This duplicates orion/unreal_frame.py in plain Python so the script has no
# dependency on the orion package being importable from inside Unreal's
# embedded interpreter. The full derivation lives there and is unit-tested;
# this is the numerically-verified shortcut for this specific permutation
# (a pure axis 3-cycle, no reflection -- see the module docstring there for
# why the quaternion vector part can be permuted the same simple way as the
# position, confirmed to match the full R'=P R P^T derivation to 1e-16).


def _permute_position(pos_target_cm):
    x, y, z = pos_target_cm  # target: x=East, y=Up, z=North
    return z, x, y  # UE: Forward<-North, Right<-East, Up<-Up


def _permute_orientation_xyzw(quat_target_xyzw):
    x, y, z, w = quat_target_xyzw
    return z, x, y, w


# ---- load the stream --------------------------------------------------------
def _load_records(path):
    records = []
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


# ---- driving state -------------------------------------------------------------
_state = {
    "records": None,
    "index": 0,
    "elapsed": 0.0,
    "t0": None,
    "camera": None,
    "tick_handle": None,
}


def _get_or_spawn_camera():
    actor_subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    for actor in actor_subsystem.get_all_level_actors():
        if isinstance(actor, unreal.CineCameraActor):
            unreal.log(f"[orion] using existing CineCameraActor: {actor.get_name()}")
            return actor
    camera = actor_subsystem.spawn_actor_from_class(
        unreal.CineCameraActor, unreal.Vector(0.0, 0.0, 0.0), unreal.Rotator(0.0, 0.0, 0.0)
    )
    unreal.log(f"[orion] spawned new CineCameraActor: {camera.get_name()}")
    return camera


def _on_tick(delta_seconds):
    st = _state
    if st["records"] is None or st["index"] >= len(st["records"]):
        stop_driving()
        return

    st["elapsed"] += delta_seconds * PLAYBACK_SPEED
    if st["t0"] is None:
        st["t0"] = st["records"][0]["t_source"]

    while (
        st["index"] < len(st["records"])
        and (st["records"][st["index"]]["t_source"] - st["t0"]) <= st["elapsed"]
    ):
        rec = st["records"][st["index"]]
        pos_ue = _permute_position(rec["pos_target"])
        quat_ue = _permute_orientation_xyzw(rec["quat_target"])

        location = unreal.Vector(*pos_ue)
        quat = unreal.Quat(x=quat_ue[0], y=quat_ue[1], z=quat_ue[2], w=quat_ue[3])
        rotator = quat.rotator()

        st["camera"].set_actor_location_and_rotation(location, rotator, False, False)

        if st["index"] % PRINT_EVERY_N_RECORDS == 0:
            rb_loc = st["camera"].get_actor_location()
            rb_rot = st["camera"].get_actor_rotation()
            unreal.log(
                f"[orion] seq={rec['seq']} state={rec['state']} "
                f"intended_loc=({pos_ue[0]:.1f},{pos_ue[1]:.1f},{pos_ue[2]:.1f}) "
                f"readback_loc=({rb_loc.x:.1f},{rb_loc.y:.1f},{rb_loc.z:.1f}) "
                f"readback_rot=({rb_rot.roll:.2f},{rb_rot.pitch:.2f},{rb_rot.yaw:.2f})"
            )

        st["index"] += 1


def start_driving(path=JSONL_PATH):
    stop_driving()
    records = _load_records(path)
    if not records:
        unreal.log_error(f"[orion] no records loaded from {path}")
        return

    _state["records"] = records
    _state["index"] = 0
    _state["elapsed"] = 0.0
    _state["t0"] = None
    _state["camera"] = _get_or_spawn_camera()
    _state["tick_handle"] = unreal.register_slate_post_tick_callback(_on_tick)
    unreal.log(
        f"[orion] driving {len(records)} records from {path} -- call stop_driving() to stop early"
    )


def stop_driving():
    if _state["tick_handle"] is not None:
        unreal.unregister_slate_post_tick_callback(_state["tick_handle"])
        _state["tick_handle"] = None
        unreal.log("[orion] stopped driving")


start_driving()

# ---- Troubleshooting --------------------------------------------------------
# - "AttributeError: module 'unreal' has no attribute 'EditorActorSubsystem'"
#   or similar: older/newer UE Python API surface differs slightly by minor
#   version. Try unreal.EditorLevelLibrary.get_all_level_actors() /
#   .spawn_actor_from_class() as a fallback (deprecated but often still
#   present).
# - "TypeError" from unreal.Quat(...) or .rotator(): some UE Python builds
#   expose Quat as positional-only; try
#   unreal.Quat(quat_ue[0], quat_ue[1], quat_ue[2], quat_ue[3]).
# - Camera doesn't visibly move: check the viewport is set to Realtime, and
#   that you're looking at/through the CineCameraActor (select it, then
#   View > "Pilot Actor", or press the camera icon in the World Outliner
#   row for that actor).
# - Nothing prints in Output Log: confirm the log category filter isn't
#   hiding LogPython messages.
