// BONUS (optional, not required to pass).
//
// HONESTY NOTE: I (the AI assistant) wrote this against documented UE5 C++
// APIs (AActor, ACineCameraActor, FFileHelper, FCString, GEngine debug
// messages) but have no Unreal project available to compile/run it against.
// The COORDINATE MATH (PermutePosition/PermuteOrientation below) IS
// verified: it matches orion/unreal_frame.py exactly, which has a passing
// unit test suite (tests/test_unreal_frame.py) that checks the change-of-
// basis derivation directly, and separately confirms this "cycle x,y,z,
// keep w" quaternion shortcut is numerically identical (to 1e-16) to the
// full R' = P R P^T derivation for this specific permutation. The UE API
// CALLS are standard/well-documented but untested end-to-end -- see the
// setup notes at the bottom of the header, and expect to fix small things
// (e.g. an #include path) on first compile.
//
// SETUP:
// 1. In the Unreal Editor: Tools > New C++ Class > Actor, name it
//    "OrionCameraDriver". This scaffolds the module/Build.cs plumbing and
//    opens the generated .h/.cpp in your IDE.
// 2. Replace the generated OrionCameraDriver.h and .cpp with these two
//    files' contents (keep them in the path the wizard created).
// 3. Open <YourProject>/Source/<YourProject>/<YourProject>.Build.cs and
//    add "CinematicCamera" to PublicDependencyModuleNames (needed for
//    ACineCameraActor) -- it's the one dependency this needs beyond a
//    default project template.
// 4. Compile (Build in your IDE, or "Live Coding" / Ctrl+Alt+F11 in editor).
// 5. Drag an OrionCameraDriver into your level, hit Play.
// 6. Readback prints to Output Log AND on-screen (top-left of the Play
//    viewport) every ~0.5s.

#include "OrionCameraDriver.h"
#include "CineCameraActor.h"
#include "Misc/FileHelper.h"
#include "Engine/Engine.h"

AOrionCameraDriver::AOrionCameraDriver()
{
	PrimaryActorTick.bCanEverTick = true;
}

void AOrionCameraDriver::BeginPlay()
{
	Super::BeginPlay();

	LoadCsv();

	if (!TargetCamera)
	{
		FActorSpawnParameters Params;
		TargetCamera = GetWorld()->SpawnActor<ACineCameraActor>(FVector::ZeroVector, FRotator::ZeroRotator, Params);
		UE_LOG(LogTemp, Log, TEXT("[Orion] spawned a CineCameraActor"));
	}

	if (Records.Num() == 0)
	{
		UE_LOG(LogTemp, Error, TEXT("[Orion] no records loaded from %s"), *CsvPath);
	}
	else
	{
		UE_LOG(LogTemp, Log, TEXT("[Orion] loaded %d records from %s"), Records.Num(), *CsvPath);
	}
}

void AOrionCameraDriver::LoadCsv()
{
	TArray<FString> Lines;
	if (!FFileHelper::LoadFileToStringArray(Lines, *CsvPath))
	{
		UE_LOG(LogTemp, Error, TEXT("[Orion] failed to read %s"), *CsvPath);
		return;
	}

	for (int32 i = 1; i < Lines.Num(); ++i) // row 0 is the CSV header
	{
		FString Line = Lines[i];
		Line.TrimStartAndEndInline();
		if (Line.IsEmpty())
		{
			continue;
		}

		TArray<FString> Cols;
		Line.ParseIntoArray(Cols, TEXT(","), false);
		if (Cols.Num() < 12)
		{
			continue;
		}

		FOrionPoseRecord Rec;
		Rec.Seq = FCString::Atoi(*Cols[0]);
		Rec.TSource = FCString::Atod(*Cols[1]);
		Rec.PosTarget = FVector(FCString::Atod(*Cols[2]), FCString::Atod(*Cols[3]), FCString::Atod(*Cols[4]));
		Rec.QuatTarget = FQuat(FCString::Atod(*Cols[5]), FCString::Atod(*Cols[6]), FCString::Atod(*Cols[7]), FCString::Atod(*Cols[8]));
		Rec.Confidence = FCString::Atod(*Cols[9]);
		Rec.SourceAgeS = FCString::Atod(*Cols[10]);
		Rec.State = Cols[11];

		Records.Add(Rec);
	}
}

FVector AOrionCameraDriver::PermutePosition(const FVector& PosTargetCm)
{
	// contract target: X=East, Y=Up, Z=North
	// Unreal native:   X=Forward(<-North), Y=Right(<-East), Z=Up(<-Up)
	return FVector(PosTargetCm.Z, PosTargetCm.X, PosTargetCm.Y);
}

FQuat AOrionCameraDriver::PermuteOrientation(const FQuat& QuatTarget)
{
	// Same axis 3-cycle applied to the quaternion's vector part; scalar (W)
	// is unchanged. See the header/file-top note: verified equivalent to
	// the full change-of-basis derivation in the tested Python reference.
	return FQuat(QuatTarget.Z, QuatTarget.X, QuatTarget.Y, QuatTarget.W);
}

void AOrionCameraDriver::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!TargetCamera || Records.Num() == 0 || CurrentIndex >= Records.Num())
	{
		return;
	}

	Elapsed += DeltaTime * PlaybackSpeed;
	if (!bT0Set)
	{
		T0 = Records[0].TSource;
		bT0Set = true;
	}

	while (CurrentIndex < Records.Num() && (Records[CurrentIndex].TSource - T0) <= Elapsed)
	{
		const FOrionPoseRecord& Rec = Records[CurrentIndex];

		const FVector LocationUE = PermutePosition(Rec.PosTarget);
		const FQuat QuatUE = PermuteOrientation(Rec.QuatTarget);

		TargetCamera->SetActorLocationAndRotation(LocationUE, QuatUE, false, nullptr, ETeleportType::TeleportPhysics);

		if (CurrentIndex % PrintEveryNRecords == 0)
		{
			const FVector ReadbackLoc = TargetCamera->GetActorLocation();
			const FRotator ReadbackRot = TargetCamera->GetActorRotation();
			const FString Msg = FString::Printf(
				TEXT("[Orion] seq=%d state=%s intended=(%.1f,%.1f,%.1f) readback_loc=(%.1f,%.1f,%.1f) readback_rot=(%.2f,%.2f,%.2f)"),
				Rec.Seq, *Rec.State,
				LocationUE.X, LocationUE.Y, LocationUE.Z,
				ReadbackLoc.X, ReadbackLoc.Y, ReadbackLoc.Z,
				ReadbackRot.Roll, ReadbackRot.Pitch, ReadbackRot.Yaw);

			UE_LOG(LogTemp, Log, TEXT("%s"), *Msg);
			if (GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1, 2.0f, FColor::Green, Msg);
			}
		}

		++CurrentIndex;
	}
}
