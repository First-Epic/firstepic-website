// BONUS (optional, not required to pass). See OrionCameraDriver.cpp for
// the honesty note: this is written against standard UE5 C++ APIs but has
// not been compiled/run against a live Unreal project.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "OrionCameraDriver.generated.h"

class ACineCameraActor;

// One row of the Part 1 output stream, in the CONTRACT's target frame:
// X=East, Y=Up, Z=North, left-handed, centimeters, quat stored [x,y,z,w].
USTRUCT()
struct FOrionPoseRecord
{
	GENERATED_BODY()

	int32 Seq = 0;
	double TSource = 0.0;
	FVector PosTarget = FVector::ZeroVector;
	FQuat QuatTarget = FQuat::Identity;
	double Confidence = 0.0;
	double SourceAgeS = 0.0;
	FString State;
};

/**
 * Drives a CineCameraActor from the Part 1 pose stream (exported as CSV,
 * still in the contract's target frame), converting into Unreal's native
 * frame (X=Forward, Y=Right, Z=Up) and logging a render-space readback
 * periodically -- both to the log and on-screen via
 * GEngine->AddOnScreenDebugMessage, so the readback is literally visible
 * in the rendered viewport, not just a log line.
 *
 * Setup: place this actor in a level, set CsvPath if it differs from the
 * default, leave TargetCamera empty to have it spawn its own camera, then
 * Play.
 */
UCLASS()
class AOrionCameraDriver : public AActor
{
	GENERATED_BODY()

public:
	AOrionCameraDriver();

	UPROPERTY(EditAnywhere, Category = "Orion")
	FString CsvPath = TEXT("D:/ML/FirstEpicChallenge/orion-pose-py/unreal_bridge/orion-eval-output.csv");

	// Leave empty to auto-spawn a CineCameraActor at BeginPlay.
	UPROPERTY(EditAnywhere, Category = "Orion")
	ACineCameraActor* TargetCamera = nullptr;

	// 1.0 = playback paced to the stream's own t_source deltas (real time).
	UPROPERTY(EditAnywhere, Category = "Orion")
	double PlaybackSpeed = 1.0;

	// Readback cadence in records (stream runs at 48 records/sec).
	UPROPERTY(EditAnywhere, Category = "Orion")
	int32 PrintEveryNRecords = 24;

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

private:
	void LoadCsv();
	static FVector PermutePosition(const FVector& PosTargetCm);
	static FQuat PermuteOrientation(const FQuat& QuatTarget);

	TArray<FOrionPoseRecord> Records;
	int32 CurrentIndex = 0;
	double Elapsed = 0.0;
	double T0 = 0.0;
	bool bT0Set = false;
};
