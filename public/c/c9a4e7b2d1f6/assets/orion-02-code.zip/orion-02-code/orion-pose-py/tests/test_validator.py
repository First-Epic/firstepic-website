import numpy as np

from orion.json_io import load_sensor_log
from orion.types import PoseSourceSample
from orion.validator import validate_pose_source


def _sample(seq, t_source, t_captured, pos=(0.0, 0.0, 0.0)):
    return PoseSourceSample(
        seq=seq,
        t_source=t_source,
        t_captured=t_captured,
        pos_m=np.array(pos, dtype=float),
        quat_wxyz=np.array([1.0, 0.0, 0.0, 0.0]),
        confidence=0.95,
        state="tracking",
    )


def test_clean_monotonic_stream_all_accepted():
    samples = [_sample(i, 1000.0 + i * 0.01, 1000.0 + i * 0.01 - 0.002) for i in range(10)]
    accepted, rejected = validate_pose_source(samples)
    assert len(accepted) == 10
    assert len(rejected) == 0


def test_exact_duplicate_rejected():
    s0 = _sample(0, 1000.0, 999.998, pos=(1.0, 2.0, 3.0))
    s1 = _sample(0, 1000.0, 999.998, pos=(1.0, 2.0, 3.0))  # exact repeat
    s2 = _sample(1, 1000.01, 1000.008)
    accepted, rejected = validate_pose_source([s0, s1, s2])
    assert [a.seq for a in accepted] == [0, 1]
    assert len(rejected) == 1
    assert rejected[0].reason == "duplicate"


def test_reused_seq_pointing_later_rejected_non_monotonic():
    s0 = _sample(5, 1000.0, 999.998)
    s1 = _sample(6, 1000.01, 1000.008)
    s2 = _sample(5, 1000.02, 1000.018)  # seq reused, different time -> not an exact dup
    accepted, rejected = validate_pose_source([s0, s1, s2])
    assert [a.seq for a in accepted] == [5, 6]
    assert len(rejected) == 1
    assert rejected[0].reason == "non_monotonic_seq"


def test_out_of_order_t_source_rejected():
    s0 = _sample(0, 1000.0, 999.998)
    s1 = _sample(1, 999.5, 999.498)  # seq increases but time goes backward
    accepted, rejected = validate_pose_source([s0, s1])
    assert [a.seq for a in accepted] == [0]
    assert rejected[0].reason == "out_of_order_t_source"


def test_capture_after_source_time_rejected():
    s0 = _sample(0, 1000.0, 1002.0)  # t_captured after t_source: impossible
    accepted, rejected = validate_pose_source([s0])
    assert accepted == []
    assert rejected[0].reason == "capture_after_source_time"


def test_dev_log_catches_all_three_known_faults():
    log = load_sensor_log("../orion-dev-log.json")
    accepted, rejected = validate_pose_source(log.pose_source)

    assert len(log.pose_source) == 3243
    assert len(accepted) + len(rejected) == 3243
    assert len(rejected) == 3

    reasons = {r.seq: r.reason for r in rejected}
    assert reasons.get(200) == "duplicate"
    assert reasons.get(500) == "non_monotonic_seq"
    assert reasons.get(3240) == "capture_after_source_time"
