import numpy as np

from orion import quat as q
from orion import unreal_frame as uf


def test_permutation_is_handedness_preserving():
    # both frames are left-handed, so this remap must NOT flip handedness
    P = uf.axis_permutation_matrix()
    assert np.isclose(np.linalg.det(P), 1.0)


def test_position_permutation_concrete_axes():
    # 5cm East, 7cm Up, 11cm North -> UE Forward=North, Right=East, Up=Up
    pos_target = np.array([5.0, 7.0, 11.0])
    pos_ue = uf.permute_position(pos_target)
    assert np.allclose(pos_ue, np.array([11.0, 5.0, 7.0]))


def test_quaternion_change_of_basis_is_self_consistent_for_point_transform():
    """Same property as transform.py's equivalent test: rotate-then-permute
    must equal permute-then-rotate-with-the-transformed-quaternion."""
    rng = np.random.default_rng(7)
    for _ in range(20):
        q_wxyz = q.normalize(rng.normal(size=4))
        q_xyzw = np.array([q_wxyz[1], q_wxyz[2], q_wxyz[3], q_wxyz[0]])
        v = rng.normal(size=3)

        v_rotated = q.rotate_vector(q_wxyz, v)
        v_ue_rotated_direct = uf.permute_position(v_rotated)

        q_ue_xyzw = uf.permute_orientation_xyzw(q_xyzw)
        q_ue_wxyz = np.array([q_ue_xyzw[3], q_ue_xyzw[0], q_ue_xyzw[1], q_ue_xyzw[2]])
        v_ue = uf.permute_position(v)
        v_ue_rotated_via_q = q.rotate_vector(q_ue_wxyz, v_ue)

        assert np.allclose(v_ue_rotated_direct, v_ue_rotated_via_q, atol=1e-9)


def test_identity_rotation_stays_identity():
    q_identity_xyzw = np.array([0.0, 0.0, 0.0, 1.0])
    q_ue = uf.permute_orientation_xyzw(q_identity_xyzw)
    assert np.allclose(q_ue, q_identity_xyzw)
