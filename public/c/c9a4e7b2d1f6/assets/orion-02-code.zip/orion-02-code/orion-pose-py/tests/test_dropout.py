import numpy as np

from orion.dropout import DropoutConfig, DropoutTracker


def _pose(x):
    return np.array([x, 0.0, 0.0]), np.array([0.0, 0.0, 0.0, 1.0]), 0.95


def test_tracking_passes_through_fresh_pose_and_ages_normally():
    tr = DropoutTracker(DropoutConfig(degraded_threshold_s=0.35, lost_threshold_s=0.9))
    tr.on_pose_source_accepted(t_source=1000.0, t_captured=999.99)

    pos, quat, conf, state, age = tr.publish_state(1000.01, *_pose(1.0))
    assert state == "tracking"
    assert np.allclose(pos, [1.0, 0.0, 0.0])
    assert abs(age - (1000.01 - 999.99)) < 1e-9


def test_degraded_then_lost_holds_last_good_pose_and_grows_source_age():
    tr = DropoutTracker(DropoutConfig(degraded_threshold_s=0.35, lost_threshold_s=0.9))
    tr.on_pose_source_accepted(t_source=1000.0, t_captured=999.99)
    # last tick while still tracking -- this is the value that should get held
    tr.publish_state(1000.0, *_pose(5.0))

    # 0.4s later, still no new correction -> degraded, holds pos=5.0
    pos, quat, conf, state, age1 = tr.publish_state(1000.4, *_pose(999.0))
    assert state == "degraded"
    assert np.allclose(pos, [5.0, 0.0, 0.0])  # held, NOT the fresh 999.0
    assert age1 > 0

    # 1.0s later -> lost, still holding, source_age_s has grown further
    pos2, quat2, conf2, state2, age2 = tr.publish_state(1001.0, *_pose(999.0))
    assert state2 == "lost"
    assert np.allclose(pos2, [5.0, 0.0, 0.0])
    assert age2 > age1


def test_resync_is_a_hard_cut_to_fresh_value_not_a_blend():
    tr = DropoutTracker(DropoutConfig(degraded_threshold_s=0.35, lost_threshold_s=0.9))
    tr.on_pose_source_accepted(t_source=1000.0, t_captured=999.99)
    tr.publish_state(1000.0, *_pose(5.0))

    # dropout
    tr.publish_state(1001.0, *_pose(999.0))

    # pose_source resumes
    tr.on_pose_source_accepted(t_source=1001.5, t_captured=1001.49)
    pos, quat, conf, state, age = tr.publish_state(1001.5, *_pose(42.0))
    assert state == "tracking"
    assert np.allclose(pos, [42.0, 0.0, 0.0])  # jumps straight to fresh, no interpolation
