import numpy as np

from orion import quat as q
from orion import transform


def test_axis_permutation_determinant_flips_handedness():
    P = transform.axis_permutation_matrix()
    assert np.isclose(np.linalg.det(P), -1.0)
    # and it's an involution (its own inverse) since it's a single swap
    assert np.allclose(P @ P, np.eye(3))


def test_position_permutation_maps_enu_to_e_up_north():
    # source ENU: East=1, North=2, Up=3
    pos_enu = np.array([1.0, 2.0, 3.0])
    pos_target_order = transform.permute_position(pos_enu)
    # target order is (East, Up, North) -> (1, 3, 2)
    assert np.allclose(pos_target_order, np.array([1.0, 3.0, 2.0]))


def test_quaternion_change_of_basis_is_self_consistent_for_point_transform():
    """The contract specifies a 'point transform'. The defining correctness
    property of a point transform under a change of basis P is:

        P(R @ v) == R'(P @ v)   for all v

    i.e. rotate-then-permute must equal permute-then-rotate-with-the-
    transformed-quaternion. This is the concrete, unambiguous test for the
    highest-risk bug in the whole transform: a silent quaternion
    component-relabeling mistake would satisfy neither a determinant check
    nor a round-trip check, but WOULD break this identity.
    """
    rng = np.random.default_rng(42)
    for _ in range(20):
        q_src = q.normalize(rng.normal(size=4))
        v_src = rng.normal(size=3)

        v_src_rotated = q.rotate_vector(q_src, v_src)
        v_tgt_rotated_direct = transform.permute_position(v_src_rotated)

        q_tgt = transform.permute_orientation(q_src)
        v_tgt = transform.permute_position(v_src)
        v_tgt_rotated_via_q = q.rotate_vector(q_tgt, v_tgt)

        assert np.allclose(v_tgt_rotated_direct, v_tgt_rotated_via_q, atol=1e-9)


def test_quaternion_change_of_basis_concrete_90deg_about_up():
    # 90 degrees about the source Up axis (Z): body x-axis (East) -> North.
    q_src = q.from_axis_angle(np.array([0.0, 0.0, np.pi / 2]))
    east = np.array([1.0, 0.0, 0.0])
    rotated_src = q.rotate_vector(q_src, east)
    assert np.allclose(rotated_src, np.array([0.0, 1.0, 0.0]), atol=1e-9)  # -> North

    q_tgt = transform.permute_orientation(q_src)
    east_tgt = transform.permute_position(east)  # East axis unchanged: (1,0,0)
    rotated_tgt = q.rotate_vector(q_tgt, east_tgt)
    expected_tgt = transform.permute_position(rotated_src)  # North -> target Z: (0,0,1)
    assert np.allclose(rotated_tgt, expected_tgt, atol=1e-9)
    assert np.allclose(expected_tgt, np.array([0.0, 0.0, 1.0]), atol=1e-9)


def test_apply_sets_origin_to_zero_for_first_sample():
    t = transform.TargetTransform()
    pos0 = np.array([0.018569, 1.054026, 1.533675])
    quat0 = np.array([0.9968075, 0.06209953, 0.05008713, -0.00312035])
    t.set_origin_from_first_sample(pos0)
    pos_cm, quat_xyzw = t.apply(pos0, quat0)
    assert np.allclose(pos_cm, np.zeros(3), atol=1e-9)
    assert np.isclose(np.linalg.norm(quat_xyzw), 1.0)


def test_apply_scales_meters_to_centimeters():
    t = transform.TargetTransform()
    origin = np.array([0.0, 0.0, 0.0])
    t.set_origin_from_first_sample(origin)
    quat_identity = np.array([1.0, 0.0, 0.0, 0.0])
    # 1m East, 0, 0 -> should be 100cm on target X (East)
    pos_cm, _ = t.apply(np.array([1.0, 0.0, 0.0]), quat_identity)
    assert np.allclose(pos_cm, np.array([100.0, 0.0, 0.0]))


def test_quat_reorder_wxyz_to_xyzw():
    t = transform.TargetTransform()
    origin = np.zeros(3)
    t.set_origin_from_first_sample(origin)
    quat_identity_wxyz = np.array([1.0, 0.0, 0.0, 0.0])
    _, quat_xyzw = t.apply(origin, quat_identity_wxyz)
    assert np.allclose(quat_xyzw, np.array([0.0, 0.0, 0.0, 1.0]))
