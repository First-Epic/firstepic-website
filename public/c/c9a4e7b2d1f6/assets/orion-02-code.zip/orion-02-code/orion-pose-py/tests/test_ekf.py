import numpy as np

from orion import ekf


def test_stationary_imu_keeps_state_still():
    config = ekf.EKFConfig()
    q0 = np.array([1.0, 0.0, 0.0, 0.0])
    p0 = np.array([1.0, 2.0, 3.0])
    state = ekf.init_state(p0, q0, config)

    gyro = np.zeros(3)
    accel = np.array([0.0, 0.0, 9.80665])  # at rest: specific force = +g up

    for _ in range(400):  # 2s at dt=0.005
        state = ekf.predict(state, gyro, accel, 0.005, config)

    assert np.allclose(state.p, p0, atol=1e-6)
    assert np.allclose(state.v, np.zeros(3), atol=1e-6)
    assert np.allclose(state.q, q0, atol=1e-6)


def test_pose_source_correction_pulls_p_plus_bp_toward_measurement():
    # pose_source's position model is z = p + bp + noise, so the correction
    # should pull (p + bp) toward the measurement, not necessarily p alone --
    # the bp state absorbs slowly-varying pose_source bias by design.
    config = ekf.EKFConfig()
    q0 = np.array([1.0, 0.0, 0.0, 0.0])
    p0 = np.array([0.0, 0.0, 0.0])
    state = ekf.init_state(p0, q0, config)

    pos_meas = np.array([0.1, 0.0, 0.0])
    state2 = ekf.correct_pose_source(state, pos_meas, q0, confidence=0.95, config=config)

    combined = state2.p[0] + state2.bp[0]
    assert 0.0 < combined < 0.1  # pulled toward but not fully snapped (Kalman gain < 1)


def test_rtk_correction_pulls_p_only_not_bp():
    config = ekf.EKFConfig()
    q0 = np.array([1.0, 0.0, 0.0, 0.0])
    p0 = np.array([0.0, 0.0, 0.0])
    state = ekf.init_state(p0, q0, config)

    rtk_meas = np.array([0.1, 0.0, 0.0])
    state2 = ekf.correct_rtk(state, rtk_meas, "rtk_fixed", config)

    assert 0.0 < state2.p[0] < 0.1
    assert state2.bp[0] == 0.0  # RTK's H has no bp column -- bp is untouched


def test_gyro_integration_rotates_orientation():
    config = ekf.EKFConfig()
    state = ekf.init_state(np.zeros(3), np.array([1.0, 0.0, 0.0, 0.0]), config)
    gyro = np.array([0.0, 0.0, np.pi / 2])  # 90deg/s about Up
    accel = np.array([0.0, 0.0, 9.80665])
    for _ in range(200):  # 1s at dt=0.005 -> 90 degrees total
        state = ekf.predict(state, gyro, accel, 0.005, config)

    from orion import quat

    east = np.array([1.0, 0.0, 0.0])
    rotated = quat.rotate_vector(state.q, east)
    assert np.allclose(rotated, np.array([0.0, 1.0, 0.0]), atol=1e-3)
