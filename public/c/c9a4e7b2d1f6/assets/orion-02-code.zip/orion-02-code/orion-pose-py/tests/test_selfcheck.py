"""The go/no-go gate: fused (pre-target-transform) pose at the self-check's
10 sparse keyframe timestamps must fall inside its tolerance bands. This is
the only accuracy ground truth available before submission."""

import numpy as np

from orion import ekf, quat
from orion.fusion import run_fusion, state_at_or_before
from orion.json_io import load_self_check, load_sensor_log
from orion.validator import validate_pose_source


def test_fused_pose_within_selfcheck_bands():
    log = load_sensor_log("../orion-dev-log.json")
    self_check = load_self_check("../orion-dev-selfcheck.json")

    accepted, _rejected = validate_pose_source(log.pose_source)
    config = ekf.EKFConfig()
    trace = run_fusion(accepted, log.imu, log.rtk, config)

    pos_errors_m = []
    ori_errors_deg = []
    for kf in self_check.keyframes:
        entry = state_at_or_before(trace, kf.t)
        assert entry is not None, f"no trace entry at/before t={kf.t}"
        assert abs(entry.t - kf.t) < 0.02, f"nearest trace entry too far from keyframe t={kf.t}"

        pos_err = np.linalg.norm(entry.state.p - kf.pos_m)
        pos_errors_m.append(pos_err)

        ang_err_rad = np.linalg.norm(quat.local_angular_error(entry.state.q, kf.quat_wxyz))
        ori_errors_deg.append(np.degrees(ang_err_rad))

    pos_errors_m = np.array(pos_errors_m)
    ori_errors_deg = np.array(ori_errors_deg)

    print(f"\nposition errors (m): {np.round(pos_errors_m, 4)}")
    print(f"orientation errors (deg): {np.round(ori_errors_deg, 4)}")
    print(f"position median={np.median(pos_errors_m):.4f} p95={np.percentile(pos_errors_m, 95):.4f}")
    print(f"orientation median={np.median(ori_errors_deg):.4f} p95={np.percentile(ori_errors_deg, 95):.4f}")

    assert np.median(pos_errors_m) <= self_check.bands.position_median_m
    assert np.percentile(pos_errors_m, 95) <= self_check.bands.position_p95_m
    assert np.median(ori_errors_deg) <= self_check.bands.orientation_median_deg
    assert np.percentile(ori_errors_deg, 95) <= self_check.bands.orientation_p95_deg
