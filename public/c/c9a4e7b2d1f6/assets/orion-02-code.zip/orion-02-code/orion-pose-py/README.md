# ORION Pose Stream Service (Part 1)

Fuses `pose_source` + `imu` + `rtk` into a contract-conforming pose stream at
>=24 Hz, per `orion-pose-contract-v2.json`.

## Setup

```
python -m venv venv
.\venv\Scripts\Activate.ps1      # PowerShell; use venv/bin/activate on Linux/macOS
pip install -r requirements.txt
```

Tested with Python 3.12, numpy 2.5, pytest 9.1 (requirements.txt pins minimum versions, not exact
ones — any reasonably recent numpy/pytest works).

## Run

From this directory (`orion-pose-py/`), against a sensor log two levels up:

```
python main.py \
  --log ../orion-eval-log.json \
  --config config/config_v1.json \
  --out deliverables/orion-eval-output.jsonl \
  --rejected-out deliverables/rejected-observations.jsonl \
  --latency-out deliverables/latency-trace.jsonl
```

Swap `--log` to `../orion-dev-log.json` to reproduce the dev run. The command
is deterministic: identical input log + config always produces identical
output (no randomness anywhere in the pipeline).

`config/config_v1.json` is the versioned, explicit configuration: EKF noise
parameters, dropout thresholds, and publish rate. All values and their
reasoning are documented in `orion/ekf.py`'s `EKFConfig` and
`orion/dropout.py`'s module docstring.

## Tests

```
pytest tests/ -v
```

`tests/test_selfcheck.py` is the accuracy go/no-go gate: it runs the fusion
core on the dev log and asserts the fused (pre-transform) pose at the
self-check's 10 keyframes falls inside `orion-dev-selfcheck.json`'s
tolerance bands.

## Project layout

```
orion/
  types.py        # data model
  json_io.py       # load logs/self-check, write output/rejected/latency
  quat.py           # quaternion math ([w,x,y,z] convention throughout)
  transform.py       # target-frame transform (pure functions)
  unreal_frame.py      # bonus only: target frame -> Unreal's native frame
  validator.py           # fault rejection (duplicate/out-of-order/stale)
  ekf.py                   # error-state EKF fusion core
  fusion.py                  # merges imu/pose/rtk into a time-ordered EKF run
  dropout.py                   # output-side hold/degraded/lost state machine
  pipeline.py                    # wires it all together + publisher + latency trace
  config_io.py                     # load/save versioned PipelineConfig
tests/                              # pytest suite (25 tests), including the self-check gate
config/config_v1.json                # versioned config used for the submitted run
deliverables/                          # eval run outputs (see report.md)
main.py                                  # CLI entry point
report.md                                  # measured report
unreal_bridge/                               # bonus only, see below
```

## Bonus (optional — see report.md section 9)

`unreal_bridge/` drives a `CineCameraActor` in Unreal Engine from the eval output stream, converting
from the contract's target frame into Unreal's native frame (`orion/unreal_frame.py`, unit-tested in
`tests/test_unreal_frame.py`). Two implementations are provided since Unreal setups vary:

- `OrionCameraDriver.h`/`.cpp` — a C++ actor (no Python plugin required). Reads
  `orion-eval-output.csv` (a plain CSV export of the eval output, also in this folder) and logs a
  render-space readback each frame.
- `drive_camera.py` — an equivalent Editor-Python version, for setups with the Python plugin enabled.
- `unreal-readback-log.json` — a captured run's actual output (readback exactly matches intended
  position across all logged samples), since this was run and verified on a separate machine.

## Design notes (see the plan for full detail)

- **Fusion**: 15-dim error-state EKF (position, velocity, orientation,
  accelerometer bias, and a `pose_source` position-bias state). The bias
  state exists because `pose_source`'s position drifts/biases while its
  orientation does not (confirmed directly against the dev log/self-check);
  RTK is the only source that disambiguates true position from that bias.
- **Target transform**: composed from the contract's stated conventions (no
  literal matrix given) — axis permutation (East,North,Up)->(East,Up,North),
  a similarity-transform quaternion change of basis, m->cm scale, origin
  translated to the fused position at the first published sample.
- **Dropout handling**: output-side state machine, independent of the EKF's
  internals. Degraded at 0.35s / lost at 0.9s without a `pose_source`
  correction (both comfortably under the ~1.0s shortest real dropout).
  Position/orientation held at the last known-good value during a hold;
  resync on `pose_source` resumption is a hard cut to the fresh value, not a
  blend (produces a documented one-sample discontinuity).
- **Publish clock**: fixed 48 Hz, decoupled from input jitter.
