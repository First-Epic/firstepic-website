# Part 1 — Measured Report

Config used for both runs: `config/config_v1.json` (`config_version: v1`), unmodified between the
dev run and the eval run. Full reasoning behind every parameter is documented in
`orion/ekf.py` (`EKFConfig`) and `orion/dropout.py`.

## 1. Pose rate held

Both runs publish on a fixed 48 Hz output clock (contract floor: 24 Hz), decoupled from input
jitter.

| Run  | records | duration | dt (constant)     | rate     |
|------|---------|----------|--------------------|----------|
| dev  | 1440    | 30.0 s   | 0.0208333 s        | 48.00 Hz |
| eval | 1440    | 30.0 s   | 0.0208333 s        | 48.00 Hz |

`dt` has zero jitter (min == max in both runs) because publish ticks are generated on their own
fixed schedule, independent of when sensor samples happen to arrive.

## 2. Source-age behavior across the drop-outs

Both logs contain the same two dropout spans (same fixture generation pattern): the tracker's
state transitions land at identical timestamps in both runs.

| event                         | t_source   | source_age_s |
|--------------------------------|-----------|---------------|
| tracking (normal)              | 1000.000  | ~0.012        |
| -> degraded (span 1)           | 1011.354  | 0.3745        |
| -> lost (span 1)               | 1011.896  | 0.9162        |
| -> tracking (span 1 ends)      | 1013.000  | 0.012         |
| -> degraded (span 2)           | 1021.854  | 0.3745        |
| -> lost (span 2)               | 1022.396  | 0.9162        |
| -> tracking (span 2 ends)      | 1022.500  | 0.012         |

`source_age_s` grows monotonically through every hold and resets on resync, in both runs.
Position and orientation are frozen at the last known-good value for the full duration of each
hold (verified in `tests/test_dropout.py` and by direct inspection of both output files: no
sample-to-sample change in `pos_target`/`quat_target` while `state != tracking`). State counts:
1330 tracking / 52 degraded / 58 lost, identical in both runs.

Thresholds (0.35 s degraded / 0.9 s lost) were set conservatively below the ~1.0 s shortest real
dropout so genuine faults always trip the state machine while ordinary single-sample rejections
(a few ms apart) never do — confirmed by dropout timestamps landing well after each span's actual
start and returning to `tracking` at exactly the moment `pose_source` data resumes.

## 3. Coordinate-conversion correctness

The contract gives conventions, not a literal matrix (source: ENU right-handed meters, quat
`[w,x,y,z]`; target: left-handed centimeters, X=East/Y=Up/Z=North, quat `[x,y,z,w]`, origin at the
first published sample). Verified two ways:

- **Unit tests** (`tests/test_transform.py`, 7/7 passing): axis-permutation determinant flips sign
  (handedness check), a known ENU vector maps to the expected East/Up/North order, m->cm scaling,
  quaternion reorder. The highest-priority test checks the defining correctness property of a
  *point transform* under a change of basis directly: `permute(R @ v) == R'(permute(v))` for
  random rotations/vectors, plus a hand-computed concrete 90 degree case — this is what would catch
  a silent quaternion-component-relabeling bug that a determinant or round-trip check would miss.
- **Runtime confirmation**: first published sample in both runs is exactly `[0.0, 0.0, 0.0]` cm
  (origin correctly anchored), and the self-check gate (below) validates the pre-transform fusion
  independently confirms handedness/scale/quaternion-order sanity per the challenge's stated
  purpose for the self-check.

## 4. Self-check gate (dev log only — this is the only ground truth available)

`tests/test_selfcheck.py`, run on the pre-transform fused pose against `orion-dev-selfcheck.json`'s
10 keyframes:

| metric                | measured | band  | result |
|------------------------|---------|-------|--------|
| position median (m)     | 0.0267  | 0.03  | PASS   |
| position p95 (m)        | 0.0682  | 0.08  | PASS   |
| orientation median (deg) | 0.0067  | 0.8   | PASS   |
| orientation p95 (deg)    | 0.3779  | 2.5   | PASS   |

The worst single point (0.090 m position / 0.68 deg orientation) falls exactly at t=1012.0, inside
dropout span 1 (1010.99-1013.00) where `pose_source` has no data at all — the EKF is running on
IMU+RTK alone there, so this is the expected accuracy floor for that specific gap, not a general
fusion error. All other 9 points are well inside both bands.

No self-check exists for the eval log by design (held-out truth). Confidence that the eval run is
correct rests on: the pipeline and config are byte-for-byte identical between the two runs, the
eval log's fault/dropout pattern matches the dev log's exactly (confirming it's the same fixture
generation, not a different scenario), and the self-check gate above already passed *before* the
eval log was touched.

## 5. End-to-end replay latency (p50 / p95)

**Pacing disclosure**: replay is unthrottled (as-fast-as-possible) batch processing, not simulated
real-time playback with artificial pacing to match the log's 30 s nominal duration. The measured
latency is genuine ingest-to-publish wall-clock time in this implementation (Python/numpy
processing time per event), not a simulation of real 24-72h field latency. This tradeoff is
disclosed rather than spending real wall-clock time sleeping to imitate 30 s of live playback.

| Run  | p50       | p95       | max       |
|------|-----------|-----------|-----------|
| dev  | 0.080 ms  | 0.090 ms  | 0.478 ms  |
| eval | 0.074 ms  | 0.083 ms  | 0.329 ms  |

## 6. Rejected observations

Both logs reject exactly 3 `pose_source` packets, with identical seq numbers and reasons (same
fixture-seeded faults in both):

| seq  | t_source    | reason                     |
|------|-------------|-----------------------------|
| 200  | 1001.666667 | duplicate                   |
| 3240 | 1002.0      | capture_after_source_time   |
| 500  | 1007.5      | non_monotonic_seq           |

Full lists: `deliverables/rejected-observations.jsonl` (eval), `out_dev/rejected.jsonl` (dev).

## 7. Disclosures (stated explicitly, not buried)

- **No timecode stream exists** in either log, despite the PDF's introductory text mentioning one.
  The contract's own `output_stream_fields` also has no timecode field. Nothing was decoded because
  there is nothing to decode — this is a discrepancy between the intro prose and the actual fixture
  contract, not an omission on our part.
- **The hard-reset resync policy causes a visible one-sample discontinuity** at the end of every
  hold (t=1013.000 and t=1022.500 in both runs): the published pose jumps directly from the held
  value to the EKF's current fused estimate, with no interpolation. This is deliberate — smoothing
  it away would risk quietly presenting part of an actual dropout as continuously tracked when it
  wasn't.
- **Origin** is the pipeline's own fused position estimate at the first published sample
  (t_source=1000.0), which already reflects a same-instant RTK correction — not the raw
  `pose_source` reading, and not the self-check keyframe's ground-truth value (the eval log has no
  self-check to anchor to, so the origin has to come from the pipeline's own output to stay
  consistent across both runs).
- **Fusion fidelity actually shipped**: the full 15-dim error-state EKF (position, velocity,
  orientation, accelerometer bias, and a `pose_source` position-bias state) — no fallback to a
  simpler filter was needed. The bias state was *not* part of the original plan; it was added
  mid-build after an initial 12-dim version passed orientation but failed the self-check on
  position (see `orion/ekf.py`'s module docstring for the full diagnosis: raw `pose_source`
  orientation matches self-check truth to floating-point precision everywhere outside the dropout,
  while its position error grows over the run and RTK's doesn't — a single scalar measurement-noise
  weight can't represent "trust this sensor locally but not for absolute position," so it became an
  explicit state instead).
- **Noise parameter selection**: most values come directly from documented/observed sensor
  characteristics (pose_source orientation trusted tightly since it doesn't drift; RTK fixed trusted
  more than float). The IMU process-noise inflation term (`sigma_accel`) was set by checking a small
  number of order-of-magnitude values against the self-check bands, which is what the self-check is
  stated to be for — not an automated fit, and it was fixed before the eval log was ever run.

## 8. Known limitations and assumptions

- **The accelerometer bias state (`ba`) was not observable on this trajectory.** Its filter
  uncertainty (`trace(P_ba)`) does not shrink from its initial value over either run (0.0003 ->
  0.000387 on both dev and eval) — the state stays near zero because nothing pulls it away, not
  because it's being confidently estimated. Contrast with the `pose_source` position-bias state
  `bp`, whose uncertainty collapses 0.12 -> 0.0002. `ba` is currently harmless (it never grows
  large) but it isn't earning its place in the state vector on this data.
- **Only `pose_source` packets are validated.** `imu` and `rtk` are trusted unconditionally with no
  rejection path — the contract's "reject invalid observations" rule was implemented for
  `pose_source` only, where the actual injected faults were found. Both streams were independently
  checked for duplicates/non-monotonic timestamps/non-finite values in both logs and came back clean,
  so this doesn't affect the current submission, but the code has no structural defense if either
  stream carried a fault.
- **East/North axis order is taken from the contract's "ENU" naming, not an explicit mapping.** The
  contract spells out the target axes literally (`"X=East, Y=Up, Z=North"`) but never does the same
  for the source — only the acronym "ENU" is given. Up is independently confirmed (gravity dominates
  the 3rd `accel_m_s2` component at rest), but East vs. North (indices 0 vs. 1) rests entirely on the
  acronym. The self-check cannot catch a swap here: it compares fused position/orientation against
  truth in raw array order, pre-transform, so it's blind to any error introduced by `transform.py`'s
  axis assignment specifically.
- **`source_age_s`'s "now" is the replay timeline (`t_source`), not wall-clock time.** The contract
  defines it only as `"now - t_captured"`. Wall-clock time would be meaningless for a batch replay
  (it would just measure processing speed); the output's own advancing `t_source` is the only
  reading that keeps `source_age_s` meaningful during a hold, but it's an interpretive choice, not
  a literal restatement of the contract.
- **Confidence is held constant during a pose hold**, not decayed. The rule allows the held pose
  itself to use "a disclosed decay" instead of a flat hold; this implementation reads that as
  applying to position/orientation and freezes confidence alongside them rather than decaying it
  toward zero as `source_age_s` grows. A stricter reading could expect confidence itself to decay.

## 9. Bonus — Unreal Engine live verification (optional)

Not required to pass, done because Unreal was available. The eval output (`unreal_bridge/orion-eval-output.csv`,
a direct export of `deliverables/orion-eval-output.jsonl`) was fed into a `CineCameraActor` in Unreal
Engine 5.6 via a small C++ actor (`unreal_bridge/OrionCameraDriver.h/.cpp`) that applies one further
axis remap — the contract's target frame (X=East, Y=Up, Z=North) into Unreal's native frame
(X=Forward, Y=Right, Z=Up) — and logs a render-space readback (both to the log and on-screen) of the
actor's actual transform after each set, so the check is against what Unreal itself holds, not just
what was requested.

Run live in the editor, this passed cleanly, with the log itself as evidence:

- **Origin**: `seq=0` gives `intended=(0,0,0)` and `readback_loc=(0,0,0)` — matches Part 1's origin
  definition (first published sample = zero) after the extra Unreal-frame conversion too.
- **Round-trip fidelity**: `readback_loc` matched `intended` exactly on every logged line across the
  full 1440-record run — `SetActorLocationAndRotation` introduced no discrepancy between the intended
  and actual Unreal transform.
- **Dropout hold and resync, confirmed inside the engine**: at `seq=552/576/600` (`degraded`/`lost`/
  `lost`) the logged position is identical across all three — `(-26.6,-32.6,-62.2)` — then jumps to a
  new value the instant `seq=624` returns to `tracking`. Converting those sequence numbers back to
  source time (`t = 1000 + seq/48`) lands at `t≈1011.5→1013.0`, matching dropout span 1 as measured
  independently in section 2 of this report. This is the same dropout-hold-then-hard-cut-resync
  behavior verified three separate times now: in the Python EKF/dropout unit tests, in the coordinate
  math's own unit tests (`tests/test_unreal_frame.py`), and now rendering live inside Unreal.

One honesty note: the C++ side of this (the actual Unreal API calls, as opposed to the coordinate
math, which was unit-tested beforehand) was written without a live Unreal project available to test
against, and is confirmed working here only because it was run for real afterward — it was not a sure
thing going in.
