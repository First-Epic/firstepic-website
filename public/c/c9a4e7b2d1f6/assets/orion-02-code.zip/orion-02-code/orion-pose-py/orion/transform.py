"""Target-frame transform: source (ENU right-handed meters, quat wxyz
body->world) -> target (X=East,Y=Up,Z=North left-handed, centimeters,
quat xyzw), origin translated to the first published sample.

No literal matrix is given by the contract; this is composed from the
stated conventions. See the plan's "Target transform derivation" section
for the reasoning.
"""

import numpy as np

from orion import quat as q

METERS_TO_CM = 100.0

# Source basis order is (East, North, Up). Target basis order is
# (East, Up, North) -- i.e. swap the North and Up components. As a matrix
# acting on a column vector [E,N,U]^T -> [E,U,N]^T:
#   target_x = source_x (East)
#   target_y = source_z (Up)
#   target_z = source_y (North)
# This is a permutation with one transposition (odd), so det(P) = -1,
# correctly flipping handedness right -> left.
_P = np.array(
    [
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        [0.0, 1.0, 0.0],
    ]
)


def axis_permutation_matrix() -> np.ndarray:
    return _P.copy()


def permute_position(pos_enu_m: np.ndarray) -> np.ndarray:
    """ENU meters -> (East,Up,North) meters, no scale/origin applied yet."""
    return _P @ pos_enu_m


def permute_orientation(quat_wxyz_body_to_world: np.ndarray) -> np.ndarray:
    """Re-express a body->world rotation in the permuted (East,Up,North)
    world basis via a similarity transform R' = P R P^T (P is its own
    inverse: it's an orthogonal involution). This is the correct way to
    carry a rotation across a change of basis -- NOT a component relabel."""
    R = q.to_rotmat(quat_wxyz_body_to_world)
    R_prime = _P @ R @ _P.T
    return q.rotmat_to_quat(R_prime)


class TargetTransform:
    """Stateful only in that it remembers the origin (target-frame,
    centimeters, permuted+scaled) established from the first published
    sample. Everything else is a pure function of its inputs."""

    def __init__(self) -> None:
        self._origin_cm: np.ndarray | None = None

    @property
    def has_origin(self) -> bool:
        return self._origin_cm is not None

    def set_origin_from_first_sample(self, pos_enu_m: np.ndarray) -> None:
        self._origin_cm = permute_position(pos_enu_m) * METERS_TO_CM

    def apply(self, pos_enu_m: np.ndarray, quat_wxyz_body_to_world: np.ndarray):
        """Returns (pos_target_cm, quat_target_xyzw)."""
        if self._origin_cm is None:
            raise RuntimeError("origin not set; call set_origin_from_first_sample first")

        pos_cm = permute_position(pos_enu_m) * METERS_TO_CM - self._origin_cm
        quat_wxyz_target = permute_orientation(quat_wxyz_body_to_world)
        # reorder [w,x,y,z] -> [x,y,z,w]
        quat_xyzw_target = np.array(
            [quat_wxyz_target[1], quat_wxyz_target[2], quat_wxyz_target[3], quat_wxyz_target[0]]
        )
        return pos_cm, quat_xyzw_target
