"""Validates the pose_source stream in ingestion (array) order, rejecting
duplicate / stale / out-of-order packets with a disclosed reason. Checks run
in a specific, deliberate order so each fault is classified by its most
specific cause rather than falling through to a generic catch-all:

  1. t_captured after t_source (physically impossible) or an implausible
     source-to-capture lag -> "capture_after_source_time" / "implausible_capture_lag"
  2. exact duplicate of the last accepted sample -> "duplicate"
  3. seq not strictly greater than the last accepted seq -> "non_monotonic_seq"
  4. t_source not strictly greater than the last accepted t_source -> "out_of_order_t_source"

This ordering was derived from three concrete faults found in the dev log
(see the plan): an exact duplicate packet, a reused seq number pointing to a
later time, and an out-of-order injected record with a future t_captured.
"""

from dataclasses import dataclass

import numpy as np

from orion.types import PoseSourceSample, RejectedObservation


@dataclass
class ValidatorConfig:
    max_capture_lag_s: float = 1.0  # max plausible (t_source - t_captured)


def validate_pose_source(
    samples: list, config: ValidatorConfig | None = None
) -> tuple[list, list]:
    if config is None:
        config = ValidatorConfig()

    accepted: list[PoseSourceSample] = []
    rejected: list[RejectedObservation] = []

    last_seq = None
    last_t_source = None
    last_t_captured = None
    last_pos = None

    for s in samples:
        lag = s.t_source - s.t_captured

        if lag < 0:
            rejected.append(RejectedObservation(s.seq, s.t_source, "capture_after_source_time"))
            continue
        if lag > config.max_capture_lag_s:
            rejected.append(RejectedObservation(s.seq, s.t_source, "implausible_capture_lag"))
            continue

        if (
            last_seq is not None
            and s.seq == last_seq
            and s.t_source == last_t_source
            and s.t_captured == last_t_captured
            and np.array_equal(s.pos_m, last_pos)
        ):
            rejected.append(RejectedObservation(s.seq, s.t_source, "duplicate"))
            continue

        if last_seq is not None and s.seq <= last_seq:
            rejected.append(RejectedObservation(s.seq, s.t_source, "non_monotonic_seq"))
            continue

        if last_t_source is not None and s.t_source <= last_t_source:
            rejected.append(RejectedObservation(s.seq, s.t_source, "out_of_order_t_source"))
            continue

        accepted.append(s)
        last_seq = s.seq
        last_t_source = s.t_source
        last_t_captured = s.t_captured
        last_pos = s.pos_m

    return accepted, rejected
