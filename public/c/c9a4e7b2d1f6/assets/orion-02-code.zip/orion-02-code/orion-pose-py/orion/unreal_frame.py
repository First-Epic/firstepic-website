"""Bonus only: target frame (X=East, Y=Up, Z=North, left-handed, cm,
quat [x,y,z,w]) -> Unreal's native world frame (X=Forward, Y=Right, Z=Up,
left-handed, cm, FQuat stored as (X,Y,Z,W)).

Units and quaternion storage order already match the contract's target
frame, so this is ONLY an axis permutation -- same technique as
transform.py, just a different remap. "Forward"/"Right" have no inherent
meaning in an empty Unreal level, so North->Forward, East->Right is an
arbitrary but consistent choice; swap it if your level has a different
idea of forward.

Unlike the East<->Up swap in transform.py (a single transposition, det=-1,
which is what flips right-handed source into left-handed target), this
remap is a 3-cycle (E,U,N) -> (N,E,U), an EVEN permutation, det=+1 --
expected, since both the contract's target frame and Unreal's world frame
are already left-handed. No handedness flip should occur here, which is
itself a check worth keeping an eye on (see test_unreal_frame.py).
"""

import numpy as np

from orion import quat as q

# rows: UE_X (Forward) <- target Z (North)
#       UE_Y (Right)   <- target X (East)
#       UE_Z (Up)      <- target Y (Up)
_P2 = np.array(
    [
        [0.0, 0.0, 1.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
    ]
)


def axis_permutation_matrix() -> np.ndarray:
    return _P2.copy()


def permute_position(pos_target_cm: np.ndarray) -> np.ndarray:
    return _P2 @ pos_target_cm


def permute_orientation_xyzw(quat_target_xyzw: np.ndarray) -> np.ndarray:
    """Takes and returns [x,y,z,w] (the storage order both the contract's
    target frame and Unreal's FQuat use) -- converts to [w,x,y,z]
    internally for quat.py's math, then back."""
    x, y, z, w = quat_target_xyzw
    q_wxyz = np.array([w, x, y, z])
    R = q.to_rotmat(q_wxyz)
    R_prime = _P2 @ R @ _P2.T
    w2, x2, y2, z2 = q.rotmat_to_quat(R_prime)
    return np.array([x2, y2, z2, w2])


def to_unreal(pos_target_cm: np.ndarray, quat_target_xyzw: np.ndarray):
    """Returns (pos_ue_cm, quat_ue_xyzw). No origin offset applied here --
    the caller decides where the stream's own origin (0,0,0 in target
    frame, per Part 1) should sit in the level, e.g. by placing an anchor
    actor or just using world origin."""
    return permute_position(pos_target_cm), permute_orientation_xyzw(quat_target_xyzw)
