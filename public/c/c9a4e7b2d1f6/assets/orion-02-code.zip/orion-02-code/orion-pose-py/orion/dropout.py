"""Output-side dropout/state-machine gate. Purely decides what gets
PUBLISHED, decoupled from the EKF's internals: the EKF keeps fusing IMU
(+RTK when available) through a pose_source gap regardless (that's what
"fuse, don't republish" requires), but the contract explicitly forbids
presenting that continued internal estimate as fresh "tracking" once
pose_source has actually dropped -- the publisher must hold the last known
-good pose and mark degraded/lost instead.

Thresholds (0.35s degraded / 0.9s lost) are set conservatively below the
shortest real dropout in the log (~1.0s) so the two genuine multi-second
gaps are always caught, while ordinary single-sample rejections (duplicate/
out-of-order packets a few ms apart) never trip the state machine.

Resync policy on pose_source resumption is a hard cut, not a blend: the very
next publish tick after a correction lands shows the EKF's current fused
estimate directly, with no interpolation from the held value. This produces
a visible one-sample discontinuity by design -- documented in the report
rather than hidden, since smoothing it away would risk quietly presenting
part of the gap as smoothly tracked when it wasn't.
"""

from dataclasses import dataclass

import numpy as np


@dataclass
class DropoutConfig:
    degraded_threshold_s: float = 0.35
    lost_threshold_s: float = 0.9


@dataclass
class HeldPose:
    pos_target: np.ndarray
    quat_target: np.ndarray
    confidence: float


class DropoutTracker:
    def __init__(self, config: DropoutConfig | None = None):
        self.config = config or DropoutConfig()
        self._last_accepted_t_source: float | None = None
        self._last_accepted_t_captured: float | None = None
        self._held: HeldPose | None = None

    def on_pose_source_accepted(self, t_source: float, t_captured: float) -> None:
        self._last_accepted_t_source = t_source
        self._last_accepted_t_captured = t_captured

    def publish_state(
        self,
        now_t_source: float,
        fresh_pos_target: np.ndarray,
        fresh_quat_target: np.ndarray,
        fresh_confidence: float,
    ):
        """Returns (pos_target, quat_target, confidence, state, source_age_s)."""
        if self._last_accepted_t_source is None:
            # no pose_source correction has landed yet; nothing to hold or age
            return fresh_pos_target, fresh_quat_target, fresh_confidence, "tracking", 0.0

        elapsed = now_t_source - self._last_accepted_t_source
        source_age_s = now_t_source - self._last_accepted_t_captured

        if elapsed < self.config.degraded_threshold_s:
            # still tracking normally; keep the held snapshot fresh in case
            # a dropout starts on the very next tick
            self._held = HeldPose(fresh_pos_target, fresh_quat_target, fresh_confidence)
            return fresh_pos_target, fresh_quat_target, fresh_confidence, "tracking", source_age_s

        state = "degraded" if elapsed < self.config.lost_threshold_s else "lost"
        held = self._held
        assert held is not None, "dropout began before any pose_source correction was ever held"
        return held.pos_target, held.quat_target, held.confidence, state, source_age_s
