import json

import numpy as np

from orion.types import (
    ImuSample,
    LatencySample,
    OutputRecord,
    PoseSourceSample,
    RejectedObservation,
    RtkSample,
    SelfCheck,
    SelfCheckBands,
    SelfCheckKeyframe,
    SensorLog,
)


def load_sensor_log(path: str) -> SensorLog:
    with open(path, "r") as f:
        raw = json.load(f)

    meta = raw["meta"]
    streams = raw["streams"]

    pose_source = [
        PoseSourceSample(
            seq=r["seq"],
            t_source=r["t_source"],
            t_captured=r["t_captured"],
            pos_m=np.array(r["pos_m"], dtype=float),
            quat_wxyz=np.array(r["quat_wxyz"], dtype=float),
            confidence=r["confidence"],
            state=r["state"],
        )
        for r in streams["pose_source"]
    ]
    imu = [
        ImuSample(
            t=r["t"],
            gyro_rad_s=np.array(r["gyro_rad_s"], dtype=float),
            accel_m_s2=np.array(r["accel_m_s2"], dtype=float),
        )
        for r in streams["imu"]
    ]
    rtk = [
        RtkSample(t=r["t"], enu_m=np.array(r["enu_m"], dtype=float), fix=r["fix"])
        for r in streams["rtk"]
    ]

    return SensorLog(
        fixture=meta.get("fixture", ""),
        duration_s=meta.get("duration_s", 0.0),
        pose_source=pose_source,
        imu=imu,
        rtk=rtk,
    )


def load_self_check(path: str) -> SelfCheck:
    with open(path, "r") as f:
        raw = json.load(f)

    keyframes = [
        SelfCheckKeyframe(
            t=k["t"],
            pos_m=np.array(k["pos_m"], dtype=float),
            quat_wxyz=np.array(k["quat_wxyz"], dtype=float),
        )
        for k in raw["keyframes"]
    ]
    b = raw["bands"]
    bands = SelfCheckBands(
        position_median_m=b["position_median_m"],
        position_p95_m=b["position_p95_m"],
        orientation_median_deg=b["orientation_median_deg"],
        orientation_p95_deg=b["orientation_p95_deg"],
        publish_rate_hz_min=b["publish_rate_hz_min"],
    )
    return SelfCheck(keyframes=keyframes, bands=bands)


def _output_record_to_dict(r: OutputRecord) -> dict:
    return {
        "seq": r.seq,
        "t_source": r.t_source,
        "pos_target": [float(x) for x in r.pos_target],
        "quat_target": [float(x) for x in r.quat_target],
        "confidence": float(r.confidence),
        "source_age_s": float(r.source_age_s),
        "state": r.state,
    }


def write_output_jsonl(path: str, records: list) -> None:
    with open(path, "w") as f:
        for r in records:
            f.write(json.dumps(_output_record_to_dict(r)))
            f.write("\n")


def write_rejected_log(path: str, rejected: list) -> None:
    with open(path, "w") as f:
        for r in rejected:
            f.write(json.dumps({"seq": r.seq, "t_source": r.t_source, "reason": r.reason}))
            f.write("\n")


def write_latency_trace(path: str, samples: list) -> None:
    with open(path, "w") as f:
        for s in samples:
            f.write(
                json.dumps(
                    {
                        "seq": s.seq,
                        "ingest_wall_s": s.ingest_wall_s,
                        "publish_wall_s": s.publish_wall_s,
                        "latency_s": s.latency_s,
                    }
                )
            )
            f.write("\n")
