"""Quaternion helpers. Convention throughout: q = [w, x, y, z], body->world
(v_world = R(q) @ v_body), matching the source log's stated convention."""

import numpy as np


def normalize(q: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(q)
    if n < 1e-12:
        return np.array([1.0, 0.0, 0.0, 0.0])
    return q / n


def multiply(q1: np.ndarray, q2: np.ndarray) -> np.ndarray:
    """Hamilton product q1 * q2 (apply q2 first, then q1's rotation, i.e.
    R(q1*q2) = R(q1) @ R(q2))."""
    w1, x1, y1, z1 = q1
    w2, x2, y2, z2 = q2
    return np.array([
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
    ])


def conjugate(q: np.ndarray) -> np.ndarray:
    return np.array([q[0], -q[1], -q[2], -q[3]])


def to_rotmat(q: np.ndarray) -> np.ndarray:
    w, x, y, z = normalize(q)
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def rotmat_to_quat(R: np.ndarray) -> np.ndarray:
    """Shepperd's method — numerically robust for any proper rotation matrix."""
    m00, m01, m02 = R[0]
    m10, m11, m12 = R[1]
    m20, m21, m22 = R[2]
    trace = m00 + m11 + m22
    if trace > 0:
        s = 0.5 / np.sqrt(trace + 1.0)
        w = 0.25 / s
        x = (m21 - m12) * s
        y = (m02 - m20) * s
        z = (m10 - m01) * s
    elif m00 > m11 and m00 > m22:
        s = 2.0 * np.sqrt(1.0 + m00 - m11 - m22)
        w = (m21 - m12) / s
        x = 0.25 * s
        y = (m01 + m10) / s
        z = (m02 + m20) / s
    elif m11 > m22:
        s = 2.0 * np.sqrt(1.0 + m11 - m00 - m22)
        w = (m02 - m20) / s
        x = (m01 + m10) / s
        y = 0.25 * s
        z = (m12 + m21) / s
    else:
        s = 2.0 * np.sqrt(1.0 + m22 - m00 - m11)
        w = (m10 - m01) / s
        x = (m02 + m20) / s
        y = (m12 + m21) / s
        z = 0.25 * s
    return normalize(np.array([w, x, y, z]))


def rotate_vector(q: np.ndarray, v: np.ndarray) -> np.ndarray:
    return to_rotmat(q) @ v


def from_axis_angle(axis_angle: np.ndarray) -> np.ndarray:
    """Exact exponential map: axis_angle = axis * angle (rad)."""
    angle = np.linalg.norm(axis_angle)
    if angle < 1e-12:
        return np.array([1.0, *(0.5 * axis_angle)])
    axis = axis_angle / angle
    half = 0.5 * angle
    return np.array([np.cos(half), *(axis * np.sin(half))])


def small_angle_quat(delta_theta: np.ndarray) -> np.ndarray:
    """First-order approximation used to inject a small error-state rotation
    back into the nominal quaternion (standard error-state EKF convention)."""
    return normalize(np.array([1.0, *(0.5 * delta_theta)]))


def local_angular_error(q_pred: np.ndarray, q_meas: np.ndarray) -> np.ndarray:
    """Small-angle rotation vector delta_theta, expressed in the BODY frame,
    such that q_meas ~= q_pred (x) exp(delta_theta / 2). This matches the
    right-multiplicative (local/body-frame) error-state convention used by
    the EKF's process model (q_new = q (x) delta_q from gyro integration),
    so the measurement Jacobian for this residual is simply H_theta = I.
    Sign-corrected for the shortest-path rotation."""
    dq = multiply(conjugate(q_pred), q_meas)
    if dq[0] < 0:
        dq = -dq
    return 2.0 * dq[1:]
