"""Data model for input streams, self-check, and output records.

Quaternions are numpy arrays [w, x, y, z] (source convention) internally;
only the final output record stores the target [x, y, z, w] order the
contract requires.
"""

from dataclasses import dataclass, field

import numpy as np


@dataclass
class PoseSourceSample:
    seq: int
    t_source: float
    t_captured: float
    pos_m: np.ndarray  # ENU meters, shape (3,)
    quat_wxyz: np.ndarray  # shape (4,)
    confidence: float
    state: str


@dataclass
class ImuSample:
    t: float
    gyro_rad_s: np.ndarray
    accel_m_s2: np.ndarray


@dataclass
class RtkSample:
    t: float
    enu_m: np.ndarray
    fix: str


@dataclass
class SensorLog:
    fixture: str
    duration_s: float
    pose_source: list = field(default_factory=list)
    imu: list = field(default_factory=list)
    rtk: list = field(default_factory=list)


@dataclass
class SelfCheckKeyframe:
    t: float
    pos_m: np.ndarray
    quat_wxyz: np.ndarray


@dataclass
class SelfCheckBands:
    position_median_m: float
    position_p95_m: float
    orientation_median_deg: float
    orientation_p95_deg: float
    publish_rate_hz_min: float


@dataclass
class SelfCheck:
    keyframes: list
    bands: SelfCheckBands


@dataclass
class RejectedObservation:
    seq: int
    t_source: float
    reason: str


@dataclass
class OutputRecord:
    seq: int
    t_source: float
    pos_target: np.ndarray  # cm, shape (3,)
    quat_target: np.ndarray  # [x, y, z, w]
    confidence: float
    source_age_s: float
    state: str  # tracking | degraded | lost


@dataclass
class LatencySample:
    seq: int
    ingest_wall_s: float
    publish_wall_s: float
    latency_s: float
