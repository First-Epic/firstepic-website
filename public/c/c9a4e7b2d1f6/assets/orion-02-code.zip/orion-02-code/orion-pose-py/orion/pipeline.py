"""Wires validator -> EKF fusion -> dropout gate -> target transform ->
publisher into the actual service. Publishes on a FIXED output clock
(independent of input jitter/rate), decoupled from how densely pose_source
happens to sample -- this is what guarantees the >=24 Hz floor regardless of
input irregularities.

Replay/latency pacing: UNTHROTTLED (as-fast-as-possible) batch replay, not
simulated real-time playback with artificial sleeps to match the log's
30s wall-clock duration. Disclosed explicitly because the plan requires it:
the p50/p95 "end-to-end replay latency" reported here is genuine measured
ingest-to-publish wall-clock latency in THIS implementation (numpy/Python
per-event processing time), not a simulation of real 24-72h field latency.
"""

import time
from dataclasses import dataclass

from orion import ekf
from orion.dropout import DropoutConfig, DropoutTracker
from orion.transform import TargetTransform
from orion.types import LatencySample, OutputRecord, PoseSourceSample, RtkSample
from orion.validator import ValidatorConfig, validate_pose_source

_PRIORITY = {"pose": 0, "rtk": 1, "imu": 2, "publish": 3}


@dataclass
class PipelineConfig:
    config_version: str = "v1"
    publish_rate_hz: float = 48.0
    ekf_config: "ekf.EKFConfig" = None
    validator_config: ValidatorConfig = None
    dropout_config: DropoutConfig = None

    def __post_init__(self):
        if self.ekf_config is None:
            self.ekf_config = ekf.EKFConfig()
        if self.validator_config is None:
            self.validator_config = ValidatorConfig()
        if self.dropout_config is None:
            self.dropout_config = DropoutConfig()


@dataclass
class PipelineResult:
    outputs: list
    rejected: list
    latency_samples: list


def _build_events(pose_source_accepted, imu_samples, rtk_samples, publish_rate_hz):
    events = []
    events += [(s.t_source, "pose", s) for s in pose_source_accepted]
    events += [(s.t, "rtk", s) for s in rtk_samples]
    events += [(s.t, "imu", s) for s in imu_samples]

    if pose_source_accepted:
        t0 = pose_source_accepted[0].t_source
        t_end = max(
            [s.t_source for s in pose_source_accepted]
            + [s.t for s in imu_samples]
            + [s.t for s in rtk_samples]
        )
        dt = 1.0 / publish_rate_hz
        n_ticks = int((t_end - t0) / dt) + 1
        events += [(t0 + i * dt, "publish", None) for i in range(n_ticks)]

    events.sort(key=lambda e: (e[0], _PRIORITY[e[1]]))
    return events


def run_pipeline(log, config: PipelineConfig) -> PipelineResult:
    accepted, rejected = validate_pose_source(log.pose_source, config.validator_config)
    events = _build_events(accepted, log.imu, log.rtk, config.publish_rate_hz)

    state = None
    last_state_t = None
    last_imu = None
    last_pose_confidence = 1.0
    transform = TargetTransform()
    dropout_tracker = DropoutTracker(config.dropout_config)

    outputs: list[OutputRecord] = []
    latency_samples: list[LatencySample] = []
    last_ingest_wall_s = time.perf_counter()
    seq_out = 0

    for t, kind, payload in events:
        if state is None:
            if kind != "pose":
                continue
            s: PoseSourceSample = payload
            state = ekf.init_state(s.pos_m, s.quat_wxyz, config.ekf_config)
            dropout_tracker.on_pose_source_accepted(s.t_source, s.t_captured)
            last_pose_confidence = s.confidence
            last_state_t = t
            last_ingest_wall_s = time.perf_counter()
            continue

        dt = t - last_state_t
        if dt > 0 and last_imu is not None:
            state = ekf.predict(state, last_imu.gyro_rad_s, last_imu.accel_m_s2, dt, config.ekf_config)
            last_state_t = t

        if kind == "imu":
            last_imu = payload
            last_ingest_wall_s = time.perf_counter()
        elif kind == "pose":
            s: PoseSourceSample = payload
            state = ekf.correct_pose_source(state, s.pos_m, s.quat_wxyz, s.confidence, config.ekf_config)
            dropout_tracker.on_pose_source_accepted(s.t_source, s.t_captured)
            last_pose_confidence = s.confidence
            last_ingest_wall_s = time.perf_counter()
        elif kind == "rtk":
            r: RtkSample = payload
            state = ekf.correct_rtk(state, r.enu_m, r.fix, config.ekf_config)
            last_ingest_wall_s = time.perf_counter()
        elif kind == "publish":
            if not transform.has_origin:
                # origin = the pipeline's own fused position estimate at the
                # first published sample (may already reflect a same-instant
                # RTK correction) -- not the raw pose_source reading.
                transform.set_origin_from_first_sample(state.p)
            pos_target, quat_target = transform.apply(state.p, state.q)
            pos_out, quat_out, conf_out, pub_state, source_age_s = dropout_tracker.publish_state(
                t, pos_target, quat_target, last_pose_confidence
            )
            record = OutputRecord(
                seq=seq_out,
                t_source=t,
                pos_target=pos_out,
                quat_target=quat_out,
                confidence=conf_out,
                source_age_s=source_age_s,
                state=pub_state,
            )
            outputs.append(record)
            publish_wall_s = time.perf_counter()
            latency_samples.append(
                LatencySample(
                    seq=seq_out,
                    ingest_wall_s=last_ingest_wall_s,
                    publish_wall_s=publish_wall_s,
                    latency_s=publish_wall_s - last_ingest_wall_s,
                )
            )
            seq_out += 1

    return PipelineResult(outputs=outputs, rejected=rejected, latency_samples=latency_samples)
