"""Drives the EKF over the merged, time-ordered IMU / pose_source / RTK
event stream. Shared by the self-check validation run and the real
pipeline. Deliberately separate from dropout/publish/transform concerns --
this module only answers "what does the fused state look like over time,"
given an already-validated (accepted) pose_source list.
"""

from dataclasses import dataclass

import numpy as np

from orion import ekf
from orion.types import ImuSample, PoseSourceSample, RtkSample

_PRIORITY = {"pose": 0, "rtk": 1, "imu": 2}


@dataclass
class FusionEvent:
    t: float
    kind: str  # "pose" | "rtk" | "imu"
    payload: object


@dataclass
class TraceEntry:
    t: float
    state: ekf.EKFState
    event_kind: str
    pose_source_seq: int | None = None  # set on "pose" events, for dropout tracking downstream


def build_event_stream(
    pose_source_accepted: list, imu_samples: list, rtk_samples: list
) -> list:
    events = []
    events += [FusionEvent(s.t_source, "pose", s) for s in pose_source_accepted]
    events += [FusionEvent(s.t, "rtk", s) for s in rtk_samples]
    events += [FusionEvent(s.t, "imu", s) for s in imu_samples]
    events.sort(key=lambda e: (e.t, _PRIORITY[e.kind]))
    return events


def run_fusion(
    pose_source_accepted: list, imu_samples: list, rtk_samples: list, config: ekf.EKFConfig
) -> list:
    """Returns a trace: list[TraceEntry], one entry per processed event,
    covering the whole log duration."""
    events = build_event_stream(pose_source_accepted, imu_samples, rtk_samples)

    state = None
    last_state_t = None
    last_imu: ImuSample | None = None
    trace: list[TraceEntry] = []

    for e in events:
        if state is None:
            if e.kind != "pose":
                # can't initialize from IMU/RTK alone; wait for the first pose_source fix
                continue
            s: PoseSourceSample = e.payload
            state = ekf.init_state(s.pos_m, s.quat_wxyz, config)
            last_state_t = e.t
            trace.append(TraceEntry(e.t, state, "pose", s.seq))
            continue

        dt = e.t - last_state_t
        if dt > 0 and last_imu is not None:
            state = ekf.predict(state, last_imu.gyro_rad_s, last_imu.accel_m_s2, dt, config)
            last_state_t = e.t

        if e.kind == "imu":
            last_imu = e.payload
            trace.append(TraceEntry(e.t, state, "imu", None))
        elif e.kind == "pose":
            s: PoseSourceSample = e.payload
            state = ekf.correct_pose_source(state, s.pos_m, s.quat_wxyz, s.confidence, config)
            trace.append(TraceEntry(e.t, state, "pose", s.seq))
        elif e.kind == "rtk":
            r: RtkSample = e.payload
            state = ekf.correct_rtk(state, r.enu_m, r.fix, config)
            trace.append(TraceEntry(e.t, state, "rtk", None))

    return trace


def state_at_or_before(trace: list, t: float):
    """Nearest trace entry at or before time t (linear scan is fine at this
    scale -- callers use it sparingly, e.g. 10 self-check keyframes)."""
    best = None
    for entry in trace:
        if entry.t <= t + 1e-9:
            best = entry
        else:
            break
    return best
