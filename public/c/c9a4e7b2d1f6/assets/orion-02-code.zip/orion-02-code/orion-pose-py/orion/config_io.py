import json
from dataclasses import asdict

from orion import ekf
from orion.dropout import DropoutConfig
from orion.pipeline import PipelineConfig
from orion.validator import ValidatorConfig


def default_pipeline_config() -> PipelineConfig:
    return PipelineConfig()


def save_pipeline_config(config: PipelineConfig, path: str) -> None:
    payload = {
        "config_version": config.config_version,
        "publish_rate_hz": config.publish_rate_hz,
        "ekf": asdict(config.ekf_config),
        "validator": asdict(config.validator_config),
        "dropout": asdict(config.dropout_config),
    }
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)


def load_pipeline_config(path: str) -> PipelineConfig:
    with open(path, "r") as f:
        raw = json.load(f)
    return PipelineConfig(
        config_version=raw["config_version"],
        publish_rate_hz=raw["publish_rate_hz"],
        ekf_config=ekf.EKFConfig(**raw["ekf"]),
        validator_config=ValidatorConfig(**raw["validator"]),
        dropout_config=DropoutConfig(**raw["dropout"]),
    )
