#!/usr/bin/env python3
"""ORION Part 1 pose stream service.

Usage:
  python main.py --log orion-eval-log.json --config config/config_v1.json \
      --out orion-eval-output.jsonl --rejected-out rejected.jsonl \
      --latency-out latency.jsonl
"""

import argparse
import sys

from orion.config_io import load_pipeline_config
from orion.json_io import load_sensor_log, write_latency_trace, write_output_jsonl, write_rejected_log
from orion.pipeline import run_pipeline


def main() -> int:
    parser = argparse.ArgumentParser(description="ORION pose stream service")
    parser.add_argument("--log", required=True, help="path to sensor log JSON (dev or eval)")
    parser.add_argument("--config", required=True, help="path to versioned pipeline config JSON")
    parser.add_argument("--out", required=True, help="path to write output pose stream (JSONL)")
    parser.add_argument("--rejected-out", required=True, help="path to write rejected-observation log (JSONL)")
    parser.add_argument("--latency-out", required=True, help="path to write latency trace (JSONL)")
    args = parser.parse_args()

    log = load_sensor_log(args.log)
    config = load_pipeline_config(args.config)

    result = run_pipeline(log, config)

    write_output_jsonl(args.out, result.outputs)
    write_rejected_log(args.rejected_out, result.rejected)
    write_latency_trace(args.latency_out, result.latency_samples)

    print(f"published {len(result.outputs)} records, rejected {len(result.rejected)} observations", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
