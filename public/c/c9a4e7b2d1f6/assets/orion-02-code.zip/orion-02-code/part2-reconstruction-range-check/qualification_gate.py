#!/usr/bin/env python3
"""The qualification gate that should have run before
`sfm_solve.qualification.qualified` could be set true for
FIXTURE-orion-reconstruction-artifact (and any solve like it).

Read-and-reason artifact per the challenge -- no COLMAP/solver run here.
This is a standalone, runnable check: point it at the artifact JSON and it
reports pass/fail with reasons, using only data already present in the file.

Usage:
    python qualification_gate.py path/to/orion-reconstruction-artifact.json
"""

import json
import sys
from dataclasses import dataclass


@dataclass
class GateThresholds:
    # Scale: mean absolute deviation of reconstructed/reference baseline
    # ratios from 1.0. RTK survey baselines are the ground truth here, so
    # this is a hard, falsifiable check, not a heuristic.
    max_scale_error_fraction: float = 0.02  # 2%
    # Consistency across baselines: if the ratios disagree with each other
    # by more than this, it's not a clean uniform scale bug -- something
    # else (e.g. non-rigid distortion) is wrong and needs a human, not just
    # a scale correction.
    max_scale_ratio_spread: float = 0.01  # 1%
    # The pipeline's own claimed correction factor must match what the
    # baseline data actually implies, within this tolerance. This is what
    # catches "reported_scale_factor: 1.000" being wrong/unapplied even
    # when someone did compute a metric_scale block at all.
    max_reported_vs_measured_scale_disagreement: float = 0.02  # 2%

    min_registration_retention: float = 0.85
    max_reprojection_p95_px: float = 2.0
    max_reprojection_max_px: float = 10.0
    min_inlier_ratio: float = 0.70


def check_scale(sfm: dict, thresholds: GateThresholds) -> list[str]:
    failures = []
    baseline_check = sfm.get("metric_scale", {}).get("rtk_baseline_check")
    if not baseline_check or not baseline_check.get("measured_vs_reference_m"):
        failures.append(
            "no RTK baseline cross-check present -- cannot verify metric scale at all; "
            "qualification cannot be granted without one"
        )
        return failures

    pairs = baseline_check["measured_vs_reference_m"]
    ratios = []
    for p in pairs:
        ref, recon = p["reference_m"], p["reconstructed_m"]
        if ref <= 0:
            failures.append(f"baseline {p['pair']}: non-positive reference distance {ref}")
            continue
        ratios.append(recon / ref)

    if not ratios:
        failures.append("all baseline pairs invalid; cannot verify scale")
        return failures

    mean_ratio = sum(ratios) / len(ratios)
    spread = max(ratios) - min(ratios)
    scale_error_fraction = abs(mean_ratio - 1.0)

    if scale_error_fraction > thresholds.max_scale_error_fraction:
        failures.append(
            f"metric scale is off by {scale_error_fraction * 100:.1f}% "
            f"(mean reconstructed/reference ratio = {mean_ratio:.4f} across "
            f"{len(ratios)} RTK baselines; per-pair: "
            f"{[f'{r:.4f}' for r in ratios]}), exceeds the "
            f"{thresholds.max_scale_error_fraction * 100:.0f}% tolerance"
        )

    if spread > thresholds.max_scale_ratio_spread:
        failures.append(
            f"baseline ratios disagree with each other by {spread * 100:.1f}% "
            f"(expected a single uniform scale factor if this is a plain scale bug); "
            f"exceeds {thresholds.max_scale_ratio_spread * 100:.0f}% spread tolerance -- "
            f"investigate for non-uniform distortion, not just a scale correction"
        )

    reported = sfm["metric_scale"].get("reported_scale_factor")
    if reported is not None:
        measured_needed = 1.0 / mean_ratio
        disagreement = abs(reported - measured_needed) / measured_needed
        if disagreement > thresholds.max_reported_vs_measured_scale_disagreement:
            failures.append(
                f"reported_scale_factor={reported} does not match what the baseline data "
                f"actually implies (measured correction needed = {measured_needed:.4f}, "
                f"{disagreement * 100:.1f}% disagreement) -- the scale correction was either "
                f"never applied or computed incorrectly despite the baseline evidence being "
                f"present in this same artifact"
            )

    return failures


def check_solve_quality(sfm: dict, capture: dict, thresholds: GateThresholds) -> list[str]:
    failures = []

    retention = sfm.get("registration_retention")
    if retention is not None and retention < thresholds.min_registration_retention:
        failures.append(
            f"registration_retention={retention:.3f} below minimum "
            f"{thresholds.min_registration_retention} "
            f"({capture.get('images_registered')}/{capture.get('images_total')} images registered)"
        )

    reproj = sfm.get("reprojection_error_px", {})
    if reproj.get("p95", 0) > thresholds.max_reprojection_p95_px:
        failures.append(
            f"reprojection_error_px.p95={reproj.get('p95')} exceeds "
            f"{thresholds.max_reprojection_p95_px}px"
        )
    if reproj.get("max", 0) > thresholds.max_reprojection_max_px:
        failures.append(
            f"reprojection_error_px.max={reproj.get('max')} exceeds "
            f"{thresholds.max_reprojection_max_px}px"
        )

    inliers = sfm.get("inlier_ratio")
    if inliers is not None and inliers < thresholds.min_inlier_ratio:
        failures.append(f"inlier_ratio={inliers} below minimum {thresholds.min_inlier_ratio}")

    return failures


def run_gate(artifact: dict, thresholds: GateThresholds | None = None) -> tuple[bool, list[str]]:
    thresholds = thresholds or GateThresholds()
    sfm = artifact["sfm_solve"]
    capture = artifact["capture"]

    failures = check_scale(sfm, thresholds) + check_solve_quality(sfm, capture, thresholds)
    return (len(failures) == 0), failures


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 1

    with open(sys.argv[1]) as f:
        artifact = json.load(f)

    passed, failures = run_gate(artifact)

    claimed = artifact["sfm_solve"]["qualification"]["qualified"]
    print(f"artifact: {artifact.get('fixture')}")
    print(f"pipeline's own qualification.qualified: {claimed} "
          f"(gate_version={artifact['sfm_solve']['qualification'].get('gate_version')}, "
          f"reviewed_by={artifact['sfm_solve']['qualification'].get('reviewed_by')})")
    print(f"this gate's verdict: {'PASS' if passed else 'FAIL'}")
    for f_ in failures:
        print(f"  - {f_}")

    if not passed and claimed:
        print(
            "\n>>> This artifact was marked qualified=true and sent to splat_training "
            "(input_gate: solve.qualification.qualified == true) despite failing a real "
            "qualification check. This gate would have blocked it before training."
        )

    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
