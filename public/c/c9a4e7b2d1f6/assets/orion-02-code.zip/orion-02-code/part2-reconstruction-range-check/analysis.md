# Part 2 — The Reconstruction Range-Check

Artifact reviewed: `orion-reconstruction-artifact.json` (`FIXTURE-orion-reconstruction-artifact`).
Read-and-reason only, per the challenge — no COLMAP or solver run. `qualification_gate.py` in this
folder is a standalone, runnable check against the artifact's own JSON that demonstrates the finding
below concretely (run it: `python qualification_gate.py ../orion-reconstruction-artifact.json`).

## (a) The defect, and how to verify it

**The reconstruction's metric scale is wrong by ~14.3%, and the artifact's own scale-correction
field falsely claims no correction was needed.**

The artifact includes an RTK baseline cross-check — three surveyed reference distances compared
against the corresponding distances in the reconstruction:

| pair | reference (m) | reconstructed (m) | reconstructed / reference |
|------|---------------|--------------------|-----------------------------|
| b1   | 12.40         | 10.63              | 0.8573                      |
| b2   | 8.10          | 6.94               | 0.8568                      |
| b3   | 20.05         | 17.19              | 0.8574                      |

All three ratios agree to within 0.03% of each other (mean 0.8571, i.e. almost exactly 6/7),
despite spanning baselines from 8m to 20m in different parts of the site. That tightness is the
signature of a single uniform multiplicative scale error, not per-point reprojection noise — noise
would scatter the ratios; a scale bug reproduces the same ratio everywhere.

Yet `sfm_solve.metric_scale.reported_scale_factor` is recorded as `1.000` — the field meant to
record what correction the pipeline applied says "none was needed," while the baseline data sitting
in the same object shows a correction of ~1.167x was actually required. Either the scale-estimation
step (`method: estimated_from_rtk_baselines`) silently failed and left the default identity value in
place, or it computed the factor and never applied it. Either way, every downstream consumer
inherits a scene that is uniformly ~14% undersized in real-world terms: the delivered "neutral
master" and both creative derivatives will be measurably wrong wherever absolute scale matters —
placing the splat in an Unreal scene at 1:1, compositing a real object or actor into it, physics/
collision against it, or matching it to any other metric asset will all be off by the same ~14%.

**How to verify it** (from the artifact alone, no solver needed):
1. Compute `reconstructed_m / reference_m` for each baseline pair — done above; the three values
   agree to ~0.03%, confirming a uniform scale error rather than noise.
2. Compare that measured ratio against `reported_scale_factor`. They should be reciprocal
   (`reported_scale_factor ≈ 1 / mean_ratio`) if the correction was computed and applied correctly.
   Here `reported_scale_factor = 1.000` while the data implies `1.167` was needed — a direct,
   falsifiable contradiction within the artifact itself, not a judgment call.
3. (If the delivered scene were available to inspect, as a second independent check): measure the
   same six RTK-surveyed points in the delivered splat/Unreal import and confirm the ~14% undersize
   propagated all the way through training, not just present in the intermediate SfM solve.

Two secondary, corroborating quality signals in the same artifact (not the primary defect, but
worth noting as further evidence this solve should never have qualified): `registration_retention`
is only 0.752 (611/812 images registered), and `reprojection_error_px` is elevated (median 2.94px,
p95 11.7px, max 41.2px) with `inlier_ratio` at 0.61. None of these alone proves the scene is
*wrong* the way the scale contradiction does — a solve can have moderate reprojection error and
still be metrically correct — but they're additional, already-computed signals that a real gate
should also have caught.

## (b) The qualification gate that should have caught it

The artifact's own `qualification` block shows why this shipped: `"qualified": true`,
`"gate_version": "none"`, `"reviewed_by": "auto"` — there was no real gate, just an automatic
rubber stamp, even though the RTK cross-check data needed to catch this was already sitting in the
same file. `splat_training.input_gate` (`"solve.qualification.qualified == true"`) then trusted
that stamp blindly.

The gate that should have run instead, before `qualified` can ever be set `true`
(implemented and demonstrated in `qualification_gate.py`):

1. **Scale check (hard block).** For every RTK baseline pair, compute
   `ratio = reconstructed_m / reference_m`. Fail if `|mean(ratio) - 1.0|` exceeds a tolerance
   (2% here, informed by expected RTK survey precision) — this is a hard, falsifiable numeric
   check, not a heuristic, because the ground truth is already in the artifact.
2. **Scale self-consistency check (hard block).** Fail if `reported_scale_factor` disagrees with
   `1 / mean(ratio)` by more than a small tolerance (2%). This is the specific check that catches
   *this* defect: it doesn't just verify the scale is right, it verifies the pipeline's own claim
   about what it did matches the evidence, which is what was actually broken here.
3. **Ratio-spread check.** Fail if the per-pair ratios disagree with each other by more than ~1% —
   that would indicate non-uniform distortion rather than a clean scale bug, and needs a human, not
   just a scale correction.
4. **Solve-quality floor (soft/secondary block).** Minimum `registration_retention` (e.g. ≥0.85),
   maximum `reprojection_error_px.p95`/`.max` (e.g. ≤2px / ≤10px), minimum `inlier_ratio`
   (e.g. ≥0.70). Every one of these is already computed and present in the artifact — the gate just
   has to actually read them instead of auto-approving.
5. **No RTK data, no qualification.** If a solve has no baseline cross-check available at all,
   qualification should fail closed (cannot verify scale), not default to `true`.

Running this gate against the actual artifact produces:

```
this gate's verdict: FAIL
  - metric scale is off by 14.3% (mean reconstructed/reference ratio = 0.8571 ...)
  - reported_scale_factor=1.0 does not match what the baseline data actually implies ...
  - registration_retention=0.752 below minimum 0.85 (611/812 images registered)
  - reprojection_error_px.p95=11.7 exceeds 2.0px
  - reprojection_error_px.max=41.2 exceeds 10.0px
  - inlier_ratio=0.61 below minimum 0.7
```

Wired in as `splat_training.input_gate`'s actual precondition (replacing the current
`gate_version: none` / `reviewed_by: auto` stamp), this would have blocked training entirely instead
of shipping a scene that's silently ~14% off scale.
